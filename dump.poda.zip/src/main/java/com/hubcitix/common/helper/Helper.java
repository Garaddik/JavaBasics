package com.hubcitix.common.helper;







public interface Helper {
	public String getUserUniqueId(String idtoken) throws RuntimeException;

	public String getUserMailId(String idtoken) throws RuntimeException;
}
