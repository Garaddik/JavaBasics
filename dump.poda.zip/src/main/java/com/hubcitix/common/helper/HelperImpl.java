package com.hubcitix.common.helper;

import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;

public class HelperImpl implements Helper {

	private static HelperImpl instance = null;

	@Override
	public String getUserUniqueId(String idtoken) throws RuntimeException {

		DecodedJWT jwt = null;
		String userUniqueId = null;
		try {
			jwt = JWT.decode(idtoken);
			userUniqueId = jwt.getClaim("sub").asString();
		} catch (JWTDecodeException exception) {
			throw new RuntimeException(exception.getMessage());
		}
		return userUniqueId;
	}

	@Override
	public String getUserMailId(String idtoken) throws RuntimeException {

		DecodedJWT jwt = null;
		String userEmailId = null;
		try {
			jwt = JWT.decode(idtoken);
			if (null != jwt) {
				userEmailId = jwt.getClaim("email").asString();
			}
		} catch (JWTDecodeException exception) {
			throw new RuntimeException(exception.getMessage());
		}
		return userEmailId;
	}

	public static Helper getInstance() {
		if (instance == null) {
			instance = new HelperImpl();
		}
		return instance;
	}
}
