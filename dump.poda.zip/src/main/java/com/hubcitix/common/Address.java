/*
 * Copyright 2010-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.hubcitix.common;

import java.util.*;

public class Address {
    
    private List<String> addressLines = null;
   
    private String sublocality = null;
   
    private String city = null;
  
    private String postalcode = null;
   
    private String state = null;
  
    private String country = null;

    /**
     * Gets addressLines
     *
     * @return addressLines
     **/
    public List<String> getAddressLines() {
        return addressLines;
    }

    /**
     * Sets the value of addressLines.
     *
     * @param addressLines the new value
     */
    public void setAddressLines(List<String> addressLines) {
        this.addressLines = addressLines;
    }

    /**
     * Gets sublocality
     *
     * @return sublocality
     **/
    public String getSublocality() {
        return sublocality;
    }

    /**
     * Sets the value of sublocality.
     *
     * @param sublocality the new value
     */
    public void setSublocality(String sublocality) {
        this.sublocality = sublocality;
    }

    /**
     * Gets city
     *
     * @return city
     **/
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of city.
     *
     * @param city the new value
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Gets postalcode
     *
     * @return postalcode
     **/
    public String getPostalcode() {
        return postalcode;
    }

    /**
     * Sets the value of postalcode.
     *
     * @param postalcode the new value
     */
    public void setPostalcode(String postalcode) {
        this.postalcode = postalcode;
    }

    /**
     * Gets state
     *
     * @return state
     **/
    public String getState() {
        return state;
    }

    /**
     * Sets the value of state.
     *
     * @param state the new value
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * Gets country
     *
     * @return country
     **/
    public String getCountry() {
        return country;
    }

    /**
     * Sets the value of country.
     *
     * @param country the new value
     */
    public void setCountry(String country) {
        this.country = country;
    }

}
