package com.hubcitix.common.model;

import com.fasterxml.jackson.annotation.JsonIgnore;


public class SearchResult {
	
	private BusinessTextResult fields;
	
	@JsonIgnore
	private String id;

	public BusinessTextResult getFields() {
		return fields;
	}

	public void setFields(BusinessTextResult fields) {
		this.fields = fields;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}




	 
}
