package com.hubcitix.common.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class BusinessSearchResult {

	
		private int found;
		@JsonIgnore
		private String start;
	 
	  private ArrayList<SearchResult> hit;


	public int getFound() {
		return found;
	}


	public void setFound(int found) {
		this.found = found;
	}


	public ArrayList<SearchResult> getHit() {
		return hit;
	}


	public void setHit(ArrayList<SearchResult> hit) {
		this.hit = hit;
	}


	public String getStart() {
		return start;
	}


	public void setStart(String start) {
		this.start = start;
	}

	  
}
