package com.hubcitix.common.model;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "User")
public class User {

	@DynamoDBHashKey(attributeName = "email")
	private String email;
	private UserPreferences UserPreferences;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public UserPreferences getUserPreferences() {
		return UserPreferences;
	}

	public void setUserPreferences(UserPreferences userPreferences) {
		UserPreferences = userPreferences;
	}

}
