package com.hubcitix.common.model;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;

@DynamoDBDocument
public class UserPreferences {

	private List<String> disabledNewsCategories;
	
	private List<String> disabledEventCategories;

	public List<String> getDisabledNewsCategories() {
		return disabledNewsCategories;
	}

	public void setDisabledNewsCategories(List<String> disabledNewsCategories) {
		this.disabledNewsCategories = disabledNewsCategories;
	}

	public List<String> getDisabledEventCategories() {
		return disabledEventCategories;
	}

	public void setDisabledEventCategories(List<String> disabledEventCategories) {
		this.disabledEventCategories = disabledEventCategories;
	}

}
