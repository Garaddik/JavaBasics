package com.hubcitix.common.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;


public class BusinessSearchResponse {
	
	private BusinessSearchResult hits;

	@JsonIgnore
	private String status;
	public BusinessSearchResult getHits() {
		return hits;
	}

	public void setHits(BusinessSearchResult hits) {
		this.hits = hits;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	

	
	
}
