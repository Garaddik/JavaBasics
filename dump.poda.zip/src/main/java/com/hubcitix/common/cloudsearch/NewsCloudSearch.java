package com.hubcitix.common.cloudsearch;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.fluent.Request;
import org.apache.http.client.fluent.Response;
import org.apache.http.entity.ContentType;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.model.BusinessSearchResponse;
import com.hubcitix.common.model.SearchResult;
import com.hubcitix.news.model.NewsItem;

public class NewsCloudSearch {

	@SuppressWarnings("null")
	public static List<NewsItem> getNewsSearchResult(String searchKey) throws RuntimeException{
	String responseBody = null;
	
	Response response;
	ArrayList<SearchResult> searchResultList = null;
	List<NewsItem> newsItems = null;
	NewsItem newItem = null;
		try {
			
	//https://search-searchnewsdomain-ctvsfibxfi7tuyahvwlg3h3r5y.us-west-2.cloudsearch.amazonaws.com/2013-01-01/search?q=austin
			//&q.parser=lucene&sort=pubdate%20desc&q.options={fields:%20[%27title^5%27,%27description%27]}		
			
			
			String finalSearchURL = ApplicationConstants.NEWSSEARCHENDPOINT+"q="+URLEncoder.encode(searchKey, "UTF-8")+"&q.parser=lucene&sort="+URLEncoder.encode("pubdate desc", "UTF-8")+"&q.options="+URLEncoder.encode("{fields: ['title','description']}", "UTF-8");
			System.out.println("News Cloud Search URL is -->"+finalSearchURL);
			
			
		response = Request
				.Get(finalSearchURL)
				.useExpectContinue()
				.version(HttpVersion.HTTP_1_1)
				.addHeader("Content-Type", "application/json")
				.addHeader("Content-Type",
						ContentType.APPLICATION_JSON.getMimeType())
				.addHeader("Accept", "application/json").execute();

		HttpResponse resp = response.returnResponse();
		responseBody = inputStreamToString(resp.getEntity().getContent());
		JSONObject json = new JSONObject(responseBody); // convert it to
														// JSON object
		responseBody = json.toString(4); // format the json response
		int statusCode = resp.getStatusLine().getStatusCode();

		ObjectMapper mapper = new ObjectMapper();

		 searchResultList = mapper
				.readValue(responseBody, BusinessSearchResponse.class)
				.getHits().getHit();

		if(null != searchResultList && !searchResultList.isEmpty()){
			
			newsItems=new ArrayList<NewsItem>();
			for (SearchResult searchResult : searchResultList) {
				
				if(null != searchResult && null != searchResult.getFields())
				{
					
					newItem = new NewsItem();
					newItem.setAuthor(searchResult.getFields().getAuthor());
					newItem.setCategory(searchResult.getFields().getCategory());
					newItem.setDescription(searchResult.getFields().getDescription());
					newItem.setGuid(searchResult.getFields().getGuid());
					newItem.setImageUrl(searchResult.getFields().getImageUrl());
					newItem.setLink(searchResult.getFields().getLink());
					newItem.setPubDate(searchResult.getFields().getPubdate());
					newItem.setTitle(searchResult.getFields().getTitle());
					newsItems.add(newItem);
				}
				
				
				
			}
		}
		 

		if (statusCode >= 400 && statusCode < 500) {
			throw new Exception();
		} else if (statusCode >= 500 && statusCode < 600) {
			throw new Exception(
					"Internal Server Error. Please try again as this might be a transient error condition.");
		}

		
	} catch (Exception e) {
		System.out.println(e.getMessage());
		throw new RuntimeException(e.getMessage());
		
	}
	return newsItems;
}

	
	private static String inputStreamToString(InputStream in)
			throws IOException {
		StringWriter output = new StringWriter();
		InputStreamReader input = new InputStreamReader(in);
		char[] buffer = new char[1024 * 4];
		int n = 0;
		while (-1 != (n = input.read(buffer))) {
			output.write(buffer, 0, n);
		}
		return output.toString();
	}
	
	
	public static void main(String a[])
	{
		getNewsSearchResult("austin");
		
		
		
	}
}
