package com.hubcitix.common;

import com.hubcitix.business.dao.EventDao;
import com.hubcitix.business.dao.EventDaoImpl;
import com.hubcitix.business.dao.HubCitiDao;
import com.hubcitix.business.dao.HubCitiDaoImpl;
import com.hubcitix.calendar.dao.CalendarDao;
import com.hubcitix.calendar.dao.CalendarDaoImpl;
import com.hubcitix.news.dao.NewsDao;
import com.hubcitix.news.dao.NewsDaoImpl;
import com.hubcitix.products.dao.ProductDao;
import com.hubcitix.products.dao.ProductDaoImpl;
import com.hubcitix.project.dao.ProjectDAO;
import com.hubcitix.project.dao.ProjectDAOImpl;
import com.hubcitix.user.dao.UserDao;
import com.hubcitix.user.dao.UserDaoImpl;

/**
 * 
 * @author kirankumar.garaddi
 *
 */
public class DAOFactory {
	/**
	 * Contains the implementations of the DAO objects. By default we only have
	 * a DynamoDB implementation
	 */
	public enum DAOType {
		DynamoDB
	}

	/**
	 * Returns the default PetDAO implementation
	 *
	 * @return The DynamoDB PetDAO implementation
	 */
	public static HubCitiDao getHubCitiDao() {
		return getHubCitiDao(DAOType.DynamoDB);
	}

	/**
	 * Returns a PetDAO implementation
	 *
	 * @param daoType
	 *            The implementation type
	 * @return The requested DAO implementation
	 */
	public static HubCitiDao getHubCitiDao(DAOType daoType) {
		HubCitiDao dao = null;
		switch (daoType) {
		case DynamoDB:
			dao = HubCitiDaoImpl.getInstance();
			break;
		}

		return dao;
	}

	public static CalendarDao getCalendarDao() {
		return getCalendarDao(DAOType.DynamoDB);
	}

	public static CalendarDao getCalendarDao(DAOType daoType) {
		CalendarDao dao = null;
		switch (daoType) {
		case DynamoDB:
			dao = CalendarDaoImpl.getInstance();
			break;
		}

		return dao;
	}

	public static NewsDao getNewsDao() {
		return getNewsDao(DAOType.DynamoDB);
	}

	public static NewsDao getNewsDao(DAOType daoType) {
		NewsDao dao = null;
		switch (daoType) {
		case DynamoDB:
			dao = NewsDaoImpl.getInstance();
			break;
		}

		return dao;
	}

	public static EventDao getEventDao() {

		return getEventDao(DAOType.DynamoDB);
	}

	public static EventDao getEventDao(DAOType daoType) {
		EventDao dao = null;
		switch (daoType) {
		case DynamoDB:
			dao = EventDaoImpl.getInstance();
			break;
		}

		return dao;
	}

	public static UserDao getUserDao() {

		return getUserDao(DAOType.DynamoDB);
	}

	public static UserDao getUserDao(DAOType daoType) {
		UserDao dao = null;
		switch (daoType) {
		case DynamoDB:
			dao = UserDaoImpl.getInstance();
			break;
		}

		return dao;
	}

	public static ProjectDAO getProjectDao() {

		return getProjectDao(DAOType.DynamoDB);
	}

	public static ProjectDAO getProjectDao(DAOType daoType) {
		ProjectDAO dao = null;
		switch (daoType) {
		case DynamoDB:
			dao = ProjectDAOImpl.getInstance();
			break;

		}

		return dao;
	}

	public static ProductDao getProductDao() {

		return getProductDao(DAOType.DynamoDB);
	}

	public static ProductDao getProductDao(DAOType daoType) {
		ProductDao dao = null;
		switch (daoType) {
		case DynamoDB:
			dao = ProductDaoImpl.getInstance();

			break;
		}

		return dao;
	}
}
