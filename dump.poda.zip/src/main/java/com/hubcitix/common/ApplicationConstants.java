package com.hubcitix.common;

public class ApplicationConstants {

	/**
	 * MethodStart declared as String for logger messages.
	 */
	public static final String METHODSTART = "In side method >>> ";
	/**
	 * MethodEnd declared as String for logger messages.
	 */
	public static final String METHODEND = " Exiting method >>> ";

	/**
	 * ExceptionOccurred declared as String for logger messages.
	 */
	public static final String EXCEPTIONOCCURRED = "Exception Occurred in  >>> ";

	public static final Integer SCAN_LIMIT = 1;
	

	public static final Integer BUSINESSCREATIONSUCCESSCODE = 201;

	public static final Integer SUCCESSSTATUSCODE = 200;

	public static final Integer FAILURECODE = 404;
	
	public static final String ERROROCCURED ="Error occured.";
	
	public static final String PRIMARY = "primary";
	
	public static final String CLOUDSEARCHENDPOINT = "https://search-businesssearchdomain-axofspng4vv75m2go6j4iteodm.us-west-2.cloudsearch.amazonaws.com/2013-01-01/search?";
	
	public static final String PRODUCTIONAWSS3BUCKETPATH ="https://s3-us-west-2.amazonaws.com/hcxbusinessimages/";
	
	public static final String PROFILEPHOTO="profilephoto";
	
	public static final String FILESEPERATOR="/";
	
	public static final String QAAWSS3BUCKETPATH ="https://s3-us-west-2.amazonaws.com/hcx.server.examples/qatempbusinesslocation/";
	
	public static final Integer CREATIONSUCCESSCODE = 201;
	
	public static final String PRODUCTSEARCHENDPOINT = "https://search-productdomainsearch-r2acazjftsbwrgh45ufy7l2jja.us-west-2.cloudsearch.amazonaws.com/2013-01-01/search?";
	
	public static final String PRODUCTS3BUCKETPATH ="/hcxproducts/product-images";
	
	public static final String PROJECTS3BUCKETPATH ="/hcxproducts/project-images";
	
	public static final String OFFERS3BUCKETPATH ="/hcxproducts/offer-images";
	
	public static final String AWSS3IMAGEPATH ="https://s3-us-west-2.amazonaws.com";
	
	public static final String NEWSSEARCHENDPOINT = "https://search-searchnewsdomain-ctvsfibxfi7tuyahvwlg3h3r5y.us-west-2.cloudsearch.amazonaws.com/2013-01-01/search?";
	
	public static final String AWSACCESSKEY="AKIAJM4WSJKQ6YWP33SQ";
	
	public static final String AWSSECRETACCESSKEY="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";
	
	
}
