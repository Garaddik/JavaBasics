package com.hubcitix.common;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;

public class DBConnection {

	public static DynamoDBMapper getDynamoConnection() {
		AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().build();
		return new DynamoDBMapper(client);
	}
}
