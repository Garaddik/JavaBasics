/*
 *  Copyright hubcitix.com to Present
 *  All right reserved
 */

package com.hubcitix.common;

public class TableNames {

	public static String ACTIVITY = "Activity";

	public static String BUSINESSACCOUNT = "BusinessAccount";

	public static String BUSINESSCATEGORY = "BusinessCategory";

	public static String BUSINESSLOCATION = "BusinessLocation";

	public static String NEWSCATEGORY = "NewsCategory";

	public static String NEWSITEM = "NewsItem";

	public static String PUBLICEVENT = "PublicEvent";

	public static String USER = "User";

	public static String PROJECT = "Project";

	public static String NONPROFITACCOUNT = "NonprofitAccount";

	public static String PROJECTCATEGORY = "ProjectCategory";
	
	public static String PRODUCTCATEGORY = "ProductCategory";
	
	public static String PRODUCT = "Product";
	
	public static String PRODUCTOFFER = "ProductOffer";

}
