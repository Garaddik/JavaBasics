package com.hubcitix.common;


public class HubCitiServiceException extends Exception{

}
