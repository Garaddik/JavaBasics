package com.hubcitix.common;

import com.hubcitix.common.helper.Helper;
import com.hubcitix.common.helper.HelperImpl;

public class HelperFactory {
	public enum HelperType {
		HELPER
	}

	public static Helper getNewsHelper() {
		return getNewsHelperImpl(HelperType.HELPER);
	}

	public static Helper getNewsHelperImpl(HelperType helperType) {
		Helper helper = null;
		switch (helperType) {
		case HELPER:
			helper = HelperImpl.getInstance();
			break;
		}
		return helper;
	}
}
