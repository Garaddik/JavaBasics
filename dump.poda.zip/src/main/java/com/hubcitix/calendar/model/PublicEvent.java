/*
 *  Copyright hubcitix.com to Present
 *  All right reserved
 */
package com.hubcitix.calendar.model;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

/**
 * {PublicEvent} A public event
 **/
@DynamoDBTable(tableName = "PublicEvent")
public class PublicEvent {

	@DynamoDBHashKey(attributeName = "eventId")
	private String eventId = null;
	/**
	 * {Business id}
	 */
	// @DynamoDBRangeKey(attributeName = "accountId")
	private String accountId = null;
	/**
	 * {Multipart Text of the event. This may have HTML including hyperlinks.}
	 */
	private String summary = null;
	/**
	 * Event description
	 */
	private String description = null;
	/**
	 * Event starting time,rfc5545 format 20170115T010120Z
	 */
	private String dtStart = null;
	/**
	 * Event ending time,rfc5545 format 20170115T010120Z
	 */
	private String dtEnd = null;
	/**
	 * Categories that this event belongs to
	 */
	private List<String> categories = null;
	/**
	 * Event image url
	 */
	private String imageUrl = null;

	private LatLng geo;

	private String activityType = null;

	public String getActivityType() {
		return activityType;
	}

	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}

	public LatLng getGeo() {
		return geo;
	}

	public void setGeo(LatLng geo) {
		this.geo = geo;
	}

	/**
	 * {eventId} ID of the event
	 *
	 * @return eventId
	 **/
	public String getEventId() {
		return eventId;
	}

	/**
	 * Sets the value of eventId.
	 *
	 * @param eventId
	 *            the new value
	 */
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	/**
	 * {Business id}
	 *
	 * @return accountId
	 **/
	public String getAccountId() {
		return accountId;
	}

	/**
	 * Sets the value of accountId.
	 *
	 * @param accountId
	 *            the new value
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	/**
	 * {Multipart Text of the event. This may have HTML including hyperlinks.}
	 *
	 * @return summary
	 **/
	public String getSummary() {
		return summary;
	}

	/**
	 * Sets the value of summary.
	 *
	 * @param summary
	 *            the new value
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}

	/**
	 * Event description
	 *
	 * @return description
	 **/
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the value of description.
	 *
	 * @param description
	 *            the new value
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Event starting time,rfc5545 format 20170115T010120Z
	 *
	 * @return dtStart
	 **/
	public String getDtStart() {
		return dtStart;
	}

	/**
	 * Sets the value of dtStart.
	 *
	 * @param dtStart
	 *            the new value
	 */
	public void setDtStart(String dtStart) {
		this.dtStart = dtStart;
	}

	/**
	 * Event ending time,rfc5545 format 20170115T010120Z
	 *
	 * @return dtEnd
	 **/
	public String getDtEnd() {
		return dtEnd;
	}

	/**
	 * Sets the value of dtEnd.
	 *
	 * @param dtEnd
	 *            the new value
	 */
	public void setDtEnd(String dtEnd) {
		this.dtEnd = dtEnd;
	}

	/**
	 * Categories that this event belongs to
	 *
	 * @return categories
	 **/
	public List<String> getCategories() {
		return categories;
	}

	/**
	 * Sets the value of categories.
	 *
	 * @param categories
	 *            the new value
	 */
	public void setCategories(List<String> categories) {
		this.categories = categories;
	}

	/**
	 * Event image URL
	 *
	 * @return imageUrl
	 **/
	public String getImageUrl() {
		return imageUrl;
	}

	/**
	 * Sets the value of imageUrl.
	 *
	 * @param imageUrl
	 *            the new value
	 */
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

}
