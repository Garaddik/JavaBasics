/*
 * Copyright 2010-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.hubcitix.calendar.model;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "PersonalEvent")
public class CalendarEvent {

	private String uid = null;

	private String action = null;

	private String account = null;

	@DynamoDBHashKey(attributeName = "email")
	private String email = null;

	private String calendarType = null;

	@DynamoDBRangeKey(attributeName = "eventId")
	private String eventId = null;

	private String userID = null;

	private String status = null;

	private String created = null;

	private String lastModified = null;

	private String summary = null;

	private String linkedSummary = null;

	private String description = null;

	private String location = null;

	private LatLng geo = null;

	private String calendarId = null;

	/**
	 * Event starting time
	 */

	private String dtStart = null;
	/**
	 * Event ending time
	 */

	private String dtEnd = null;

	public String getCalendarId() {
		return calendarId;
	}

	public void setCalendarId(String calendarId) {
		this.calendarId = calendarId;
	}

	private String category = null;

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * Gets email
	 *
	 * @return email
	 **/
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the value of email.
	 *
	 * @param email
	 *            the new value
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gets calendarType
	 *
	 * @return calendarType
	 **/
	public String getCalendarType() {
		return calendarType;
	}

	/**
	 * Sets the value of calendarType.
	 *
	 * @param calendarType
	 *            the new value
	 */
	public void setCalendarType(String calendarType) {
		this.calendarType = calendarType;
	}

	/**
	 * Gets userID
	 *
	 * @return userID
	 **/
	public String getUserID() {
		return userID;
	}

	/**
	 * Sets the value of userID.
	 *
	 * @param userID
	 *            the new value
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	/**
	 * Gets status
	 *
	 * @return status
	 **/
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the value of status.
	 *
	 * @param status
	 *            the new value
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets created
	 *
	 * @return created
	 **/
	public String getCreated() {
		return created;
	}

	/**
	 * Sets the value of created.
	 *
	 * @param created
	 *            the new value
	 */
	public void setCreated(String created) {
		this.created = created;
	}

	/**
	 * Gets lastModified
	 *
	 * @return lastModified
	 **/
	public String getLastModified() {
		return lastModified;
	}

	/**
	 * Sets the value of lastModified.
	 *
	 * @param lastModified
	 *            the new value
	 */
	public void setLastModified(String lastModified) {
		this.lastModified = lastModified;
	}

	/**
	 * Gets summary
	 *
	 * @return summary
	 **/
	public String getSummary() {
		return summary;
	}

	/**
	 * Sets the value of summary.
	 *
	 * @param summary
	 *            the new value
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}

	/**
	 * Gets linkedSummary
	 *
	 * @return linkedSummary
	 **/
	public String getLinkedSummary() {
		return linkedSummary;
	}

	/**
	 * Sets the value of linkedSummary.
	 *
	 * @param linkedSummary
	 *            the new value
	 */
	public void setLinkedSummary(String linkedSummary) {
		this.linkedSummary = linkedSummary;
	}

	/**
	 * Gets description
	 *
	 * @return description
	 **/
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the value of description.
	 *
	 * @param description
	 *            the new value
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Gets location
	 *
	 * @return location
	 **/
	public String getLocation() {
		return location;
	}

	/**
	 * Sets the value of location.
	 *
	 * @param location
	 *            the new value
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * Gets geo
	 *
	 * @return geo
	 **/
	public LatLng getGeo() {
		return geo;
	}

	/**
	 * Sets the value of geo.
	 *
	 * @param geo
	 *            the new value
	 */
	public void setGeo(LatLng geo) {
		this.geo = geo;
	}

	/**
	 * Event starting time
	 *
	 * @return dtStart
	 **/
	public String getDtStart() {
		return dtStart;
	}

	/**
	 * Sets the value of dtStart.
	 *
	 * @param dtStart
	 *            the new value
	 */
	public void setDtStart(String dtStart) {
		this.dtStart = dtStart;
	}

	/**
	 * Event ending time
	 *
	 * @return dtEnd
	 **/
	public String getDtEnd() {
		return dtEnd;
	}

	/**
	 * Sets the value of dtEnd.
	 *
	 * @param dtEnd
	 *            the new value
	 */
	public void setDtEnd(String dtEnd) {
		this.dtEnd = dtEnd;
	}

	/**
	 * Gets category
	 *
	 * @return category
	 **/
	public String getCategory() {
		return category;
	}

	/**
	 * Sets the value of category.
	 *
	 * @param category
	 *            the new value
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

}
