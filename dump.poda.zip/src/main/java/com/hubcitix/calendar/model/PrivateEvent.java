package com.hubcitix.calendar.model;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "PrivateEvent")
public class PrivateEvent {
	
	@DynamoDBHashKey(attributeName = "email")
	private String email;
	@DynamoDBRangeKey(attributeName="publicUid")
	private String publicUid;
	
	private String status;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPublicUid() {
		return publicUid;
	}
	public void setPublicUid(String publicUid) {
		this.publicUid = publicUid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	

}
