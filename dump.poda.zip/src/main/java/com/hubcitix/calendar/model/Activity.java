package com.hubcitix.calendar.model;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "Activity")
public class Activity implements Comparable<Activity> {

	@DynamoDBHashKey(attributeName = "userId")
	private String userId;

	@DynamoDBRangeKey(attributeName = "activityId")
	private String activityId;

	private String calendarType;
	private String calendarId;
	private String status;
	private String created;
	private String lastMod;
	private String summary;
	private String description;
	private String location;
	private String dtStart;
	private String dtEnd;
	private LatLng geo;
	private List<AssociatedEvent> associatedEvents;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getCalendarType() {
		return calendarType;
	}

	public void setCalendarType(String calendarType) {
		this.calendarType = calendarType;
	}

	public String getCalendarId() {
		return calendarId;
	}

	public void setCalendarId(String calendarId) {
		this.calendarId = calendarId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public LatLng getGeo() {
		return geo;
	}

	public void setGeo(LatLng geo) {
		this.geo = geo;
	}

	public List<AssociatedEvent> getAssociatedEvents() {
		return associatedEvents;
	}

	public void setAssociatedEvents(List<AssociatedEvent> associatedEvents) {
		this.associatedEvents = associatedEvents;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public String getLastMod() {
		return lastMod;
	}

	public void setLastMod(String lastMod) {
		this.lastMod = lastMod;
	}

	public String getDtStart() {
		return dtStart;
	}

	public void setDtStart(String dtStart) {
		this.dtStart = dtStart;
	}

	public String getDtEnd() {
		return dtEnd;
	}

	public void setDtEnd(String dtEnd) {
		this.dtEnd = dtEnd;
	}

	@Override
	public int compareTo(Activity activity) {
		return this.getDtStart().compareTo(activity.getDtStart());
	}

}
