/*
 *  Copyright hubcitix.com to Present
 *  All right reserved
 */

package com.hubcitix.calendar.model;

import java.math.BigDecimal;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;

@DynamoDBDocument
public class LatLng {

	private double latitude;

	private double longitude;

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public static void main(String[] args) {
		BigDecimal bigdecimal = new BigDecimal(12.123456789023452345345000023452345234534532453453245324523452345);
		System.out.println("BigDecimal : " + bigdecimal);
		double d = bigdecimal.doubleValue();
		System.out.println("Double: " + d);

	}
}
