package com.hubcitix.calendar.model;

public class CalendarRequest {

	private String idtoken;
	private String action;
	private String dtStart;
	private String dtEnd;
	private CalendarEvent calendarEvent = null;
	private String account;
	private AuthconfigRequest authConfig = null;

	public String getDtStart() {
		return dtStart;
	}

	public void setDtStart(String dtStart) {
		this.dtStart = dtStart;
	}

	public String getDtEnd() {
		return dtEnd;
	}

	public void setDtEnd(String dtEnd) {
		this.dtEnd = dtEnd;
	}

	public AuthconfigRequest getAuthConfig() {
		return authConfig;
	}

	public void setAuthConfig(AuthconfigRequest authConfig) {
		this.authConfig = authConfig;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public CalendarEvent getCalendarEvent() {
		return calendarEvent;
	}

	public void setCalendarEvent(CalendarEvent calendarEvent) {
		this.calendarEvent = calendarEvent;
	}

	public String getIdtoken() {
		return idtoken;
	}

	public void setIdtoken(String idtoken) {
		this.idtoken = idtoken;
	}

}
