package com.hubcitix.calendar.model;

/**
 * 
 * @author kirankumar.garaddi
 *
 */

public class AuthconfigRequest {

	private String idToken = null;

	private String emailId = null;

	private String authCode = null;

	private String userid;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getIdToken() {
		return idToken;
	}

	public void setIdToken(String idToken) {
		this.idToken = idToken;
	}

	/**
	 * Gets emailId
	 *
	 * @return emailId
	 **/
	public String getEmailId() {
		return emailId;
	}

	/**
	 * Sets the value of emailId.
	 *
	 * @param emailId
	 *            the new value
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * Gets authCode
	 *
	 * @return authCode
	 **/
	public String getAuthCode() {
		return authCode;
	}

	/**
	 * Sets the value of authCode.
	 *
	 * @param authCode
	 *            the new value
	 */
	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}

}
