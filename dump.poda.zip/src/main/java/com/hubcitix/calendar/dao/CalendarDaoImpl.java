package com.hubcitix.calendar.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.InternalServerErrorException;
import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.calendar.model.Activity;
import com.hubcitix.calendar.model.PublicEvent;
import com.hubcitix.common.DBConnection;
import com.hubcitix.common.TableNames;
import com.hubcitix.common.Utility;
import com.hubcitix.common.model.BusinessCategory;

public class CalendarDaoImpl implements CalendarDao {

	private static DynamoDBMapper dynamoDBMapper;

	private static CalendarDaoImpl instance = null;

	public static CalendarDao getInstance() {
		if (instance == null) {
			instance = new CalendarDaoImpl();
		}
		return instance;
	}

	@Override
	public List<Activity> getCalenderEvents(String dtStart, String dtEnd, String userId) throws RuntimeException {

		List<Activity> activities = null;

		try {

			dynamoDBMapper = DBConnection.getDynamoConnection();
			Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
			eav.put(":userId", new AttributeValue().withS(userId));
			eav.put(":dtStart", new AttributeValue().withS(dtStart));
			eav.put(":dtEnd", new AttributeValue().withS(dtEnd));

			DynamoDBQueryExpression<Activity> queryExpression = new DynamoDBQueryExpression<Activity>().withConsistentRead(false).withKeyConditionExpression("userId = :userId")
					.withFilterExpression("dtStart between :dtStart and :dtEnd or :dtStart between dtStart and dtEnd").withExpressionAttributeValues(eav);

			activities = dynamoDBMapper.query(Activity.class, queryExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.ACTIVITY).config());

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return activities;
	}

	@Override
	public boolean savePrimaryCalendarActivitys(String emailId, List<Activity> primarycalendarActivityList, Context context) throws RuntimeException {

		boolean status = false;

		try {

			dynamoDBMapper = DBConnection.getDynamoConnection();
			dynamoDBMapper.batchWrite(primarycalendarActivityList, new ArrayList<Activity>(),
					new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.ACTIVITY).config());
			status = true;

		} catch (BadRequestException exception) {

			System.err.println(emailId + "\t" + exception.getMessage() + "\t" + exception.getStatusCode() + "\t" + exception.getErrorCode() + "\t" + exception.getErrorType()
					+ "\t" + exception.getRequestId());

			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException isexception) {

			System.err.println(emailId + "\t" + isexception.getMessage() + "\t" + isexception.getStatusCode() + "\t" + isexception.getErrorCode() + "\t"
					+ isexception.getErrorType() + "\t" + isexception.getRequestId());

			throw new RuntimeException(isexception.getMessage());
		} catch (AmazonServiceException asexception) {

			System.err.println(emailId + "\t" + asexception.getMessage() + "\t" + asexception.getStatusCode() + "\t" + asexception.getErrorCode() + "\t"
					+ asexception.getErrorType() + "\t" + asexception.getRequestId());

			throw new RuntimeException(asexception.getMessage());
		} catch (AmazonClientException asexception) {

			System.err.println(emailId + "\t" + asexception.getMessage());

			throw new RuntimeException(asexception.getMessage());
		}
		return status;
	}

	@Override
	public List<PublicEvent> getDefaultCalenderEvents(String dtStart, String dtEnd) throws RuntimeException {

		List<PublicEvent> publicEvents = null;
		try {

			dynamoDBMapper = DBConnection.getDynamoConnection();
			Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
			eav.put(":dtStart", new AttributeValue().withS(dtStart));
			eav.put(":dtEnd", new AttributeValue().withS(dtEnd));

			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression().withFilterExpression("dtStart between :dtStart and :dtEnd or :dtStart between dtStart and dtEnd")
					.withExpressionAttributeValues(eav);

			publicEvents = dynamoDBMapper.scan(PublicEvent.class, scanExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PUBLICEVENT).config());

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return publicEvents;
	}

	@Override
	public List<BusinessCategory> getAllBusinessCategories() {

		List<BusinessCategory> businessCategoryLst = null;

		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
			businessCategoryLst = dynamoDBMapper.scan(BusinessCategory.class, scanExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE
					+ TableNames.BUSINESSCATEGORY).config());

		} catch (BadRequestException exception) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}

		return businessCategoryLst;

	}
}