package com.hubcitix.calendar.dao;

import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.calendar.model.Activity;
import com.hubcitix.calendar.model.PublicEvent;
import com.hubcitix.common.model.BusinessCategory;

public interface CalendarDao {

	public List<Activity> getCalenderEvents(String dtstart, String dtEnd, String userId) throws RuntimeException;

	public boolean savePrimaryCalendarActivitys(String emailId, List<Activity> primarycalendarActivityList, Context context) throws RuntimeException;

	public List<PublicEvent> getDefaultCalenderEvents(String dtStart, String dtEnd) throws RuntimeException;

	public List<BusinessCategory> getAllBusinessCategories() throws RuntimeException;

}
