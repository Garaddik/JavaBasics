package com.hubcitix.calendar.action;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.calendar.dao.CalendarDao;
import com.hubcitix.calendar.model.Activity;
import com.hubcitix.calendar.model.AssociatedEvent;
import com.hubcitix.calendar.model.CalendarRequest;
import com.hubcitix.calendar.model.CalendarResponse;
import com.hubcitix.calendar.model.PublicEvent;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.Utility;
import com.hubcitix.common.helper.Helper;
import com.hubcitix.common.model.BusinessCategory;
import com.hubcitix.common.model.User;
import com.hubcitix.user.dao.UserDao;

public class FetchCalendarEvent implements CalendarAction {

	String[] activity_Types = { "EAT", "LIVE", "WORK", "PLAY", "SHOP", "RIDE" };

	@Override
	public CalendarResponse handle(CalendarRequest input, Context context) throws RuntimeException, BadRequestException {
		List<Activity> calendarActivityList = null;
		CalendarResponse calendarResponse = new CalendarResponse();
		List<PublicEvent> events = null;
		List<PublicEvent> filteredEvents = new ArrayList<PublicEvent>();
		try {

			Helper helper = HelperFactory.getNewsHelper();
			String userId = helper.getUserUniqueId(input.getIdtoken());


			CalendarDao calendarDao = DAOFactory.getCalendarDao();
			UserDao userDao = DAOFactory.getUserDao();
			System.out.println("UserId: " + userId);
			if (Utility.IsValid_ISO8601Format(input.getDtStart()) == false || Utility.IsValid_ISO8601Format(input.getDtEnd()) == false) {
				System.err.println("Invalid date Format: " + input.getDtStart() + " or " + input.getDtEnd());
				throw new BadRequestException("Invalid date Format");
			}
			if (input.getDtStart().compareTo(input.getDtEnd()) > 0) {
				System.err.println("StartDate should be less than End Date: input " + input.getDtStart() + " is greater " + input.getDtEnd());
				throw new BadRequestException("StartDate should be greater than End Date!");
			}

			events = calendarDao.getDefaultCalenderEvents(input.getDtStart(), input.getDtEnd());
			events = new ArrayList<PublicEvent>(events);
			calendarActivityList = calendarDao.getCalenderEvents(input.getDtStart(), input.getDtEnd(), userId);
			List<BusinessCategory> businessCategories = calendarDao.getAllBusinessCategories();

			User user = userDao.getUserPreferences(userId);

			if (events != null && !events.isEmpty() && null != user && null != user.getUserPreferences() && null != user.getUserPreferences().getDisabledEventCategories()
					&& !user.getUserPreferences().getDisabledEventCategories().isEmpty()) {
				for (PublicEvent eventObj : events) {
					if (!(null == eventObj.getCategories() || eventObj.getCategories().isEmpty() || user.getUserPreferences().getDisabledEventCategories()
							.containsAll(eventObj.getCategories()))) {
						filteredEvents.add(eventObj);
					}
				}
			} else {
				filteredEvents.addAll(events);
			}

			activityTypeFinder(filteredEvents, businessCategories);

			if (null == calendarActivityList || calendarActivityList.isEmpty()) {
				Random rand = new Random();
				calendarResponse.setIsDefault(true);
				if (null != filteredEvents && !filteredEvents.isEmpty()) {
					calendarActivityList = new ArrayList<Activity>();
					List<AssociatedEvent> associatedEventsList = new ArrayList<AssociatedEvent>();
					Activity activity = new Activity();
					activity.setSummary("default");
					for (PublicEvent event : filteredEvents) {
						int index = rand.nextInt(6);
						AssociatedEvent associatedEvent = new AssociatedEvent();
						associatedEvent.setEventId(event.getEventId());
						associatedEvent.setSummary(event.getSummary());
						associatedEvent.setDescription(event.getDescription());
						associatedEvent.setPrivate(false);
						associatedEvent.setGeo(event.getGeo());
						if (null != event.getActivityType()) {
							associatedEvent.setActivityType(event.getActivityType());
						} else {
							associatedEvent.setActivityType(activity_Types[index]);
						}
						associatedEventsList.add(associatedEvent);
					}
					activity.setAssociatedEvents(associatedEventsList);
					calendarActivityList.add(activity);
				}
			} else {
				calendarActivityList = new ArrayList<Activity>(calendarActivityList);
				Collections.sort(calendarActivityList, new SortCalendarEventByDate());
				if (null != filteredEvents && !filteredEvents.isEmpty())
					calendarActivityList = associateEventsBasedOnKeywordMatch(calendarActivityList, filteredEvents);
			}

			calendarResponse.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
			calendarResponse.setCalendarActivityList(calendarActivityList);
		} catch (RuntimeException exception) {
			throw new RuntimeException(exception.getMessage());
		}
		return calendarResponse;
	}

	private List<Activity> associateEventsBasedOnKeywordMatch(List<Activity> calendarActivityList, List<PublicEvent> filteredEvents) {
		Random rand = new Random();
		List<AssociatedEvent> associatedEventsList = null;
		AssociatedEvent associatedEvent = null;
		for (Activity activity : calendarActivityList) {
			associatedEventsList = new ArrayList<AssociatedEvent>();
			for (PublicEvent event : filteredEvents) {
				if (null != activity.getSummary() && null != event.getSummary() && matchSentence(activity.getSummary().toLowerCase(), event.getSummary().toLowerCase())) {
					associatedEvent = new AssociatedEvent();
					associatedEvent.setEventId(event.getEventId());
					associatedEvent.setSummary(event.getSummary());
					associatedEvent.setDescription(event.getDescription());
					associatedEvent.setPrivate(false);
					associatedEvent.setGeo(event.getGeo());
					int index = rand.nextInt(6);
					if (null != event.getActivityType()) {
						associatedEvent.setActivityType(event.getActivityType());
					} else {
						associatedEvent.setActivityType(activity_Types[index]);
					}
					associatedEventsList.add(associatedEvent);
					activity.setAssociatedEvents(associatedEventsList);
				}
			}
		}
		return calendarActivityList;
	}

	public boolean matchSentence(String activitySummary, String eventSummary) {
		Map<String, Integer> activitykeywords = getTermFrequencyMap(activitySummary.split("\\W++"));
		Map<String, Integer> eventKeywords = getTermFrequencyMap(eventSummary.split("\\W++"));
		HashSet<String> intersection = new HashSet<>(activitykeywords.keySet());
		intersection.retainAll(eventKeywords.keySet());
		return !intersection.isEmpty();
	}

	public Map<String, Integer> getTermFrequencyMap(String[] keywords) {
		Map<String, Integer> termFrequencyMap = new HashMap<>();
		for (String keyword : keywords) {
			if (keyword.length() <= 2)
				continue;
			Integer n = termFrequencyMap.get(keyword);
			n = (n == null) ? 1 : ++n;
			termFrequencyMap.put(keyword, n);
		}
		return termFrequencyMap;
	}

	private void activityTypeFinder(List<PublicEvent> filteredEvents, List<BusinessCategory> categories) {

		for (PublicEvent event : filteredEvents) {
			for (BusinessCategory category : categories) {
				if (null != event.getCategories() && event.getCategories().contains(category.getCategory())) {
					event.setActivityType(category.getType());
				}
			}
		}
	}
}
