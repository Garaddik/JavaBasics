package com.hubcitix.calendar.action;

import java.util.Comparator;

import com.hubcitix.calendar.model.Activity;

public class SortCalendarEventByDate implements Comparator<Activity> {

	@Override
	public int compare(Activity activity1, Activity activity2) {
		try {
			return activity1.getDtStart().compareTo(activity2.getDtStart());
		} catch (RuntimeException exception) {
			return -1;
		}

	}
}
