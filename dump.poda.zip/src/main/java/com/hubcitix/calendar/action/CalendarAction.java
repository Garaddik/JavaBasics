package com.hubcitix.calendar.action;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.calendar.model.CalendarRequest;
import com.hubcitix.calendar.model.CalendarResponse;

public interface CalendarAction {

	public CalendarResponse handle(CalendarRequest input, Context context) throws RuntimeException;

}