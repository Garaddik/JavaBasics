package com.hubcitix.calendar.action;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.auth.oauth2.TokenResponseException;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeTokenRequest;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.auth.oauth2.GoogleRefreshTokenRequest;
import com.google.api.client.googleapis.auth.oauth2.GoogleTokenResponse;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.Events;
import com.hubcitix.calendar.dao.CalendarDao;
import com.hubcitix.calendar.model.Activity;
import com.hubcitix.calendar.model.AssociatedEvent;
import com.hubcitix.calendar.model.CalendarRequest;
import com.hubcitix.calendar.model.CalendarResponse;
import com.hubcitix.calendar.model.LatLng;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.Utility;
import com.hubcitix.common.helper.Helper;

/**
 * 
 * @author kirankumar.garaddi
 * 
 *         Description: Import all Primary Calendar events to HubCitiX Database
 * 
 *         Created Date: 03/15/2017
 *
 */
public class OAuthCnfigurationAction implements CalendarAction {

	/** Global instance of the HTTP transport. */
	private static HttpTransport httpTransport;

	/** Global instance of the JSON factory. */
	private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();

	private static GoogleClientSecrets clientSecrets;

	/**
	 * Handler to Call Google calendar API
	 * 
	 */
	@Override
	public CalendarResponse handle(CalendarRequest userInformation, Context context) throws RuntimeException {

		boolean status = false;

		Helper helper = HelperFactory.getNewsHelper();
		String emailId = helper.getUserMailId(userInformation.getIdtoken());
		String userId = helper.getUserUniqueId(userInformation.getIdtoken());
		userInformation.getAuthConfig().setEmailId(emailId);
		userInformation.getAuthConfig().setUserid(userId);

		System.err.println("OAuth Configuration  Method" + userInformation.getAuthConfig().getEmailId());

		CalendarResponse calendarResponse = new CalendarResponse();
		try {
			com.google.api.services.calendar.Calendar clientObj = getclient(userInformation);
			if (clientObj == null) {
				calendarResponse.setStatusCode(ApplicationConstants.FAILURECODE);
			}
			List<Activity> primarycalendarActivityList = getallevents(userInformation, clientObj, userInformation.getAuthConfig().getEmailId());
			CalendarDao calendarDao = DAOFactory.getCalendarDao();
			status = calendarDao.savePrimaryCalendarActivitys(userInformation.getAuthConfig().getEmailId(), primarycalendarActivityList, context);
			if (status) {
				calendarResponse.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
			} else {
				calendarResponse.setStatusCode(ApplicationConstants.FAILURECODE);
			}
		} catch (RuntimeException e) {
			System.err.println("Error occured " + e.getMessage() + "\t" + userInformation.getAuthConfig().getEmailId());
			throw new RuntimeException(e);
		}
		System.err.println("OAuth Configuration end Method: " + userInformation.getAuthConfig().getEmailId());
		return calendarResponse;
	}

	private List<Activity> getallevents(CalendarRequest userInformation, Calendar clientObj, String calendarId) throws RuntimeException {

		List<Activity> primaryActivityList = null;

		try {

			Events calendarEvents = clientObj.events().list(calendarId).execute();
			if (calendarEvents == null) {
				return primaryActivityList;
			}
			primaryActivityList = new ArrayList<Activity>();

			for (Event calendarEvent : calendarEvents.getItems()) {
				if (null != calendarEvent) {
					Activity activity = new Activity();
					activity.setCalendarId(calendarEvent.getICalUID());
					activity.setActivityId(calendarEvent.getId());
					activity.setCalendarType("Google");
					activity.setDescription(calendarEvent.getDescription());
					activity.setUserId(userInformation.getAuthConfig().getUserid());
					activity.setLocation(calendarEvent.getLocation());
					activity.setStatus(calendarEvent.getStatus());
					activity.setSummary(calendarEvent.getSummary());

					if (null != calendarEvent.getCreated())
						activity.setCreated(Utility.convertStringdateToDynamodFormatLong(calendarEvent.getCreated().getValue()));
					if (null != calendarEvent.getStart() && null != calendarEvent.getStart().getDateTime())
						activity.setDtStart(Utility.convertStringdateToDynamodFormatLong(calendarEvent.getStart().getDateTime().getValue()));
					if (null != calendarEvent.getEnd() && null != calendarEvent.getEnd().getDateTime())
						activity.setDtEnd(Utility.convertStringdateToDynamodFormatLong(calendarEvent.getEnd().getDateTime().getValue()));
					// Storing partition key, ignore naming convention
					if (null != calendarEvent.getUpdated())
						activity.setLastMod(Utility.convertStringdateToDynamodFormatLong(calendarEvent.getUpdated().getValue()));

					// List<AssociatedEvent> associatedEvents =
					// getAssociatedEvents();
					// activity.setAssociatedEvents(associatedEvents);
					primaryActivityList.add(activity);
				}
			}
		} catch (IOException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return primaryActivityList;
	}

	private List<AssociatedEvent> getAssociatedEvents() {
		List<AssociatedEvent> associatedEvents = new ArrayList<AssociatedEvent>();

		AssociatedEvent event = null;
		LatLng geo = new LatLng();
		event = new AssociatedEvent();
		event.setPrivate(true);
		event.setSummary("Lunch at <a href=\"business:accounts/1229/locations/93316\">Roaring Fork</a>");
		event.setViewType("EAT");
		event.setDescription("Wood-fired steaks & slow-roasted pork, plus cocktails & dessert in the InterContinental Hotel.");
		geo.setLatitude(30.2690359);
		geo.setLongitude(-97.7447375);
		event.setGeo(geo);
		associatedEvents.add(event);

		event = new AssociatedEvent();
		geo = new LatLng();
		event.setPrivate(true);
		event.setSummary("Happy hour at <a href=\"business:accounts/12/locations/79983\">Dive Bar and Lounge</a>");
		event.setViewType("EAT");
		event.setDescription("Eclectic watering hole offering old-school cocktails, happy hour specials & Mexican nibbles.");
		geo.setLatitude(30.27992);
		geo.setLongitude(-97.742472);
		event.setGeo(geo);
		associatedEvents.add(event);

		event = new AssociatedEvent();
		geo = new LatLng();
		event.setPrivate(true);
		event.setSummary("<a href=\"news:categories/tyler-top-news/123\">Labor of Love group lends helping hand to Kingdom Life Academy</a>");
		event.setViewType("NEWS");
		event.setDescription("<p>Labor of Love group lends helping hand to Kingdom Life Academy</p>");
		geo.setLatitude(38.0911);
		geo.setLongitude(-98.7485);
		event.setGeo(geo);
		associatedEvents.add(event);

		event = new AssociatedEvent();
		geo = new LatLng();
		event.setPrivate(true);
		event.setSummary("<a href=\"news:categories/austin-local-news/456\">Leander ISD addresses recent student deaths</a>");
		event.setViewType("NEWS");
		event.setDescription("<p>Leander ISD addresses recent student deaths</p>");
		geo.setLatitude(37.0911);
		geo.setLongitude(-94.7485);
		event.setGeo(geo);
		associatedEvents.add(event);

		event = new AssociatedEvent();
		geo = new LatLng();
		event.setPrivate(true);
		event.setSummary("<a href=\"contact:0270101111\">Michal Clark</a> is at Austin Auto show.");
		event.setViewType("NEWS");
		geo.setLatitude(36.98);
		geo.setLongitude(-96.7485);
		event.setGeo(geo);
		associatedEvents.add(event);

		return associatedEvents;
	}

	private com.google.api.services.calendar.Calendar getclient(CalendarRequest input) throws RuntimeException {
		com.google.api.services.calendar.Calendar client = null;

		try {
			clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(OAuthCnfigurationAction.class.getResourceAsStream("/client_secrets.json")));
			httpTransport = GoogleNetHttpTransport.newTrustedTransport();

			GoogleTokenResponse tokenInformation = getAccessTokenInformation(clientSecrets.getDetails().getClientId(), clientSecrets.getDetails().getClientSecret(), input
					.getAuthConfig().getAuthCode());
			if (tokenInformation == null) {
				return client;
			}
			GoogleCredential gcredential = new GoogleCredential().setAccessToken(tokenInformation.getAccessToken());
			client = new com.google.api.services.calendar.Calendar.Builder(httpTransport, JSON_FACTORY, gcredential).setApplicationName("my-project-1488208251980").build();
		} catch (GeneralSecurityException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return client;
	}

	public GoogleTokenResponse getAccessTokenInformation(String clientId, String secretKey, String authCode) throws RuntimeException {
		GoogleTokenResponse tokenResponse = null;
		try {
			tokenResponse = new GoogleAuthorizationCodeTokenRequest(new NetHttpTransport(), JacksonFactory.getDefaultInstance(), "https://www.googleapis.com/oauth2/v4/token",
					clientId, secretKey, authCode, "").execute();
			System.out.println("access Token: " + tokenResponse.getAccessToken());
			System.out.println("ID Token: " + tokenResponse.getIdToken());
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return tokenResponse;
	}

	public GoogleCredential refreshAccessToken(String refreshToken, String clientId, String clientSecret) throws IOException {
		GoogleCredential credentials = null;
		try {
			TokenResponse response = new GoogleRefreshTokenRequest(new NetHttpTransport(), new JacksonFactory(), refreshToken, clientId, clientSecret).execute();
			System.out.println("Access token: " + response.getAccessToken());
			credentials = new GoogleCredential();
			return credentials.setAccessToken(response.getAccessToken());
		} catch (TokenResponseException e) {
			if (e.getDetails() != null) {
				System.err.println("Error: " + e.getDetails().getError());
				if (e.getDetails().getErrorDescription() != null) {
					System.err.println(e.getDetails().getErrorDescription());
				}
				if (e.getDetails().getErrorUri() != null) {
					System.err.println(e.getDetails().getErrorUri());
				}
			} else {
				System.err.println(e.getMessage());
			}
		}
		return credentials;
	}

}
