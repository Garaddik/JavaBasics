package com.hubcitix.calendar.handler;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.hubcitix.calendar.action.CalendarAction;
import com.hubcitix.calendar.action.FetchCalendarEvent;
import com.hubcitix.calendar.action.OAuthCnfigurationAction;
import com.hubcitix.calendar.model.CalendarRequest;
import com.hubcitix.calendar.model.CalendarResponse;
import com.hubcitix.common.Utility;

public class CalendarHandler implements RequestHandler<CalendarRequest, CalendarResponse> {

	/**
	 * This method is used to get calendar events...
	 */
	@Override
	public CalendarResponse handleRequest(CalendarRequest input, Context context) {

		CalendarAction calendarAction = null;
		CalendarResponse calendarResponse = null;
		if (null == context) {
			Utility.STAGE = "Dev_";
		} else {
			Utility.STAGE = Utility.getCurrentStage(context.getInvokedFunctionArn());
		}
		try {
			if (input == null || input.getAction() == null || input.getAction().trim().equals("")) {
				System.err.println("Invalid inputObj, could not find action parameter");
				throw new BadRequestException("Could not find action value in request");
			} else {
				System.err.println("Input: " + input.getAction());
				switch (input.getAction()) {
				case "getallevents":
					calendarAction = new FetchCalendarEvent();
					break;
				case "authconfig":
					calendarAction = new OAuthCnfigurationAction();
					break;
				default:
					System.err.println("Invald inputObj, could not find action parameters");
				}
			}
			calendarResponse = calendarAction.handle(input, context);
		} catch (RuntimeException exception) {
			context.getLogger().log("Error occured while interacting with Calendar APIs!");
			throw new RuntimeException(exception);
		}
		return calendarResponse;
	}
}
