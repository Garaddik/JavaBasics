/*
 *  Copyright � 2017 HubCitiX, Inc. All right reserved.
 */
package com.hubcitix.project.handler;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.hubcitix.common.Utility;
import com.hubcitix.project.action.DeleteProject;
import com.hubcitix.project.action.FetchAllProjects;
import com.hubcitix.project.action.FetchCategories;
import com.hubcitix.project.action.FetchProjectDetails;
import com.hubcitix.project.action.ProjectAction;
import com.hubcitix.project.action.ProjectSearchActionImpl;
import com.hubcitix.project.action.SaveProjectsInfo;
import com.hubcitix.project.action.UpdateProject;
import com.hubcitix.project.model.ProjectRequest;
import com.hubcitix.project.model.ProjectResponse;

/**
 * 
 * Projecthandler is class implementated AWS Lambda request handler to handle
 * all MicroServices
 *
 */
public class ProjectHandler implements RequestHandler<ProjectRequest, ProjectResponse> {

	@Override
	public ProjectResponse handleRequest(ProjectRequest input, Context context) throws RuntimeException {

		ProjectResponse projectResponse = null;
		ProjectAction projectAction = null;

		try {
			if (input == null || input.getAction() == null || input.getAction().trim().equals("")) {

				System.err.println("Invalid inputObj, could not find action parameter");
				throw new BadRequestException("Could not find action value in request");
			}
			System.err.println("Input: " + input.getAction());
			if (null != context) {
				Utility.STAGE = Utility.getCurrentStage(context.getInvokedFunctionArn());
				System.out.println("ARN Value: " + context.getInvokedFunctionArn());
				System.out.println("Stage :" + Utility.STAGE);
			} else {
				Utility.STAGE = "Dev_";
			}
			switch (input.getAction()) {
			case "createproject":
				projectAction = new SaveProjectsInfo();
				break;
			case "getprojects":
				projectAction = new FetchAllProjects();
				break;
			case "getprojectdetails":
				projectAction = new FetchProjectDetails();
				break;
			case "getcategories":
				projectAction = new FetchCategories();
				break;
			case "searchprojects":
				projectAction = new ProjectSearchActionImpl();
				break;
			case "editProject":
				projectAction = new UpdateProject();
				break;
			case "deleteProject":
				projectAction = new DeleteProject();
				break;
			default:
				System.err.println("Invald inputObj, could not find action parameters");
			}
			projectResponse = projectAction.handle(input, context);
		} catch (RuntimeException exception) {
			context.getLogger().log("Error occured while interacting with Project APIs!");
			throw new RuntimeException(exception);
		}
		return projectResponse;
	}
}
