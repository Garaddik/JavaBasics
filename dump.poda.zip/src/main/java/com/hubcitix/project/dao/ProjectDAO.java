/*
 *  Copyright � 2017 HubCitiX, Inc. All right reserved.
 */
package com.hubcitix.project.dao;

import java.util.List;

import com.hubcitix.project.model.Project;
import com.hubcitix.project.model.ProjectCategory;

/**
 * 
 * DAO Layer to Fetch Project and Project Categories Information.
 *
 */
public interface ProjectDAO {

	public Project saveProjectsInfo(Project projectInfo, String userId) throws RuntimeException;

	public List<Project> fetchAccountProjects(String userId) throws RuntimeException;

	public List<Project> fetchAllProjects(String category) throws RuntimeException;

	public Project fetchProjectDetails(String projectId) throws RuntimeException;

	public List<ProjectCategory> fetchAllCategories() throws RuntimeException;
	
	public Project UpdateProject(Project projectInfo) throws RuntimeException;
	
	public Project DeleteProject(String projectId) throws RuntimeException;

	public List<Project> searchProjects(String searchKey) throws RuntimeException;

}
