/*
 *  
 *  Copyright � 2017 HubCitiX, Inc. All right reserved.
 *  
 */
package com.hubcitix.project.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.InternalServerErrorException;
import com.hubcitix.common.DBConnection;
import com.hubcitix.common.TableNames;
import com.hubcitix.common.Utility;
import com.hubcitix.project.model.Address;
import com.hubcitix.project.model.LatLng;
import com.hubcitix.project.model.LocationPhotos;
import com.hubcitix.project.model.NonprofitAccount;
import com.hubcitix.project.model.Project;
import com.hubcitix.project.model.ProjectCategory;
import com.hubcitix.project.model.SocialLinks;

/**
 * 
 * ProjectDAOImpl class to Fetch Project and Categories Information for DynamoDB
 * Tables
 * 
 */
public class ProjectDAOImpl implements ProjectDAO {

	private static DynamoDBMapper dynamoDBMapper;

	private static ProjectDAOImpl instance = null;

	public static ProjectDAO getInstance() {
		if (instance == null) {
			instance = new ProjectDAOImpl();
		}
		return instance;
	}

	@Override
	public Project saveProjectsInfo(Project projectInfo, String userId) throws RuntimeException {

		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			List<NonprofitAccount> nonprofitAccounts = null;
			Map<String, AttributeValue> eav1 = new HashMap<String, AttributeValue>();
			eav1.put(":userId", new AttributeValue().withS(userId));
			DynamoDBScanExpression queryExpression = new DynamoDBScanExpression().withFilterExpression("userId = :userId").withExpressionAttributeValues(eav1);
			nonprofitAccounts = dynamoDBMapper.scan(NonprofitAccount.class, queryExpression,
					new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.NONPROFITACCOUNT).config());

			if (null == nonprofitAccounts || nonprofitAccounts.isEmpty()) {
				NonprofitAccount account = new NonprofitAccount();
				account.setUserId(userId);

				dynamoDBMapper.save(account, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.NONPROFITACCOUNT).config());

				if (null != account) {
					projectInfo.setAccountId(account.getAccountId());
				}
			} else {
				projectInfo.setAccountId(nonprofitAccounts.get(0).getAccountId());
			}
			dynamoDBMapper.save(projectInfo, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PROJECT).config());

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}

		return projectInfo;

	}

	@Override
	public Project fetchProjectDetails(String projectId) throws RuntimeException {
		Project projectDetails = null;

		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();

			if (null != projectId) {
				projectDetails = dynamoDBMapper.load(Project.class, projectId, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PROJECT).config());
			}

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}

		return projectDetails;
	}

	@Override
	public List<Project> fetchAccountProjects(String userId) throws RuntimeException {
		List<Project> projects = null;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();

			List<NonprofitAccount> nonprofitAccounts = null;
			Map<String, AttributeValue> eav1 = new HashMap<String, AttributeValue>();
			eav1.put(":userId", new AttributeValue().withS(userId));
			DynamoDBScanExpression queryExpression = new DynamoDBScanExpression().withFilterExpression("userId = :userId").withExpressionAttributeValues(eav1);

			nonprofitAccounts = dynamoDBMapper.scan(NonprofitAccount.class, queryExpression,
					new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.NONPROFITACCOUNT).config());

			if (null != nonprofitAccounts && !nonprofitAccounts.isEmpty()) {
				Map<String, AttributeValue> eavProject = new HashMap<String, AttributeValue>();
				eavProject.put(":accountId", new AttributeValue().withS(nonprofitAccounts.get(0).getAccountId()));
				DynamoDBScanExpression queryExpressionProject = new DynamoDBScanExpression().withFilterExpression("accountId = :accountId").withExpressionAttributeValues(
						eavProject);
				projects = dynamoDBMapper.scan(Project.class, queryExpressionProject, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PROJECT).config());
			}
		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return projects;
	}

	@Override
	public List<Project> fetchAllProjects(String category) throws RuntimeException {
		List<Project> projects = null;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();

			Map<String, AttributeValue> eav1 = new HashMap<String, AttributeValue>();
			eav1.put(":category", new AttributeValue().withS(category));
			DynamoDBScanExpression queryExpression = new DynamoDBScanExpression().withFilterExpression("category = :category").withExpressionAttributeValues(eav1);
			projects = dynamoDBMapper.scan(Project.class, queryExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PROJECT).config());

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return projects;
	}

	@Override
	public List<ProjectCategory> fetchAllCategories() throws RuntimeException {
		List<ProjectCategory> projectCategory = null;

		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();

			DynamoDBScanExpression queryExpressionCat = new DynamoDBScanExpression();
			projectCategory = dynamoDBMapper.scan(ProjectCategory.class, queryExpressionCat,
					new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PROJECTCATEGORY).config());

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}

		return projectCategory;
	}

	@Override
	public List<Project> searchProjects(String searchKey) throws RuntimeException {

		List<Project> projects = null;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();

			Map<String, AttributeValue> eav1 = new HashMap<String, AttributeValue>();
			eav1.put(":title", new AttributeValue().withS(searchKey));
			DynamoDBScanExpression queryExpression = new DynamoDBScanExpression().withFilterExpression("begins_with(title,:title)").withExpressionAttributeValues(eav1);
			projects = dynamoDBMapper.scan(Project.class, queryExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PROJECT).config());

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return projects;
	}
	@Override
	public Project UpdateProject(Project projectInfo) throws RuntimeException {
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			dynamoDBMapper.save(projectInfo, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PROJECT).config());
	        
		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}

		return projectInfo;

	}

	@Override
	public Project DeleteProject(String projectId) throws RuntimeException {
		
		Project deletedProject = null;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			if (null != projectId) {
				deletedProject = dynamoDBMapper.load(Project.class, projectId, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PROJECT).config());
			}
			
			dynamoDBMapper.delete(deletedProject, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PROJECT).config());
			
		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}

		return deletedProject;

	}
}
