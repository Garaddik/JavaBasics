/*
 *  Copyright � 2017 HubCitiX, Inc. All right reserved.
 */
package com.hubcitix.project.action;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.project.model.ProjectRequest;
import com.hubcitix.project.model.ProjectResponse;

/**
 * 
 * Abstract Behavior to to Handle all Project Operations
 *
 */
public interface ProjectAction {

	public ProjectResponse handle(ProjectRequest input, Context context) throws RuntimeException;

}
