/*
 *  Copyright � 2017 HubCitiX, Inc. All right reserved.
 */
package com.hubcitix.project.action;

import java.util.ArrayList;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.project.dao.ProjectDAO;
import com.hubcitix.project.model.LocationPhotos;
import com.hubcitix.project.model.Project;
import com.hubcitix.project.model.ProjectRequest;
import com.hubcitix.project.model.ProjectResponse;

/**
 * 
 * FetchProjectDetails class to Fetch Particular Project Information.
 *
 */
public class FetchProjectDetails implements ProjectAction {

	@Override
	public ProjectResponse handle(ProjectRequest input, Context context) throws RuntimeException {
		ProjectResponse response = null;
		Project project = null;
		String finalProjectImage= null;
		if (null == input.getProjectId()) {
			System.err.println("Invalid inputObj, could not find action parameter");
			throw new BadRequestException("Insufficient Request!");
		}
		System.out.println("Fetch Project Details ProjectId: " + input.getProjectId());
		ProjectDAO projectDAO = DAOFactory.getProjectDao();
		project = projectDAO.fetchProjectDetails(input.getProjectId());
		if(null != project )
		{
			if(null != project.getPhotos())
			
			finalProjectImage=ApplicationConstants.AWSS3IMAGEPATH +ApplicationConstants.PROJECTS3BUCKETPATH+
					ApplicationConstants.FILESEPERATOR+project.getProjectId()+ApplicationConstants.FILESEPERATOR+"1";
			LocationPhotos photo = new LocationPhotos();
			photo.setProfilePhotoUrl(finalProjectImage);			
			project.setPhotos(photo);
			
			
		}
		
		
		response = new ProjectResponse();
		response.setProject(project);
		response.setStatusCode(200);

		return response;
	}

}
