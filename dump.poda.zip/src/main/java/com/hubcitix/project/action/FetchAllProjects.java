/*
 *  Copyright � 2017 HubCitiX, Inc. All right reserved.
 */
package com.hubcitix.project.action;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.helper.Helper;
import com.hubcitix.products.model.ProductOffer;
import com.hubcitix.project.dao.ProjectDAO;
import com.hubcitix.project.model.LocationPhotos;
import com.hubcitix.project.model.Project;
import com.hubcitix.project.model.ProjectRequest;
import com.hubcitix.project.model.ProjectResponse;

/**
 * FetchAllProjects Represents Listing Projects based on Account or Category.
 *
 */
public class FetchAllProjects implements ProjectAction {

	@Override
	public ProjectResponse handle(ProjectRequest input, Context context) throws RuntimeException {
		ProjectResponse response = null;
		String userId = null;
		List<Project> projects = null;
		String projectImage= null;
		if (null == input.getCategory() && null == input.getIdtoken()) {
			System.err.println("Invalid inputObj, could not find action parameter");
			throw new BadRequestException("Insufficient Request!");
		}
		System.out.println("Fetch Project: Category Name: " + input.getCategory());
		if (null == input.getCategory() || input.getCategory().isEmpty()) {
			Helper helper = HelperFactory.getNewsHelper();
			userId = helper.getUserUniqueId(input.getIdtoken());
		}

		ProjectDAO projectDAO = DAOFactory.getProjectDao();

		if (null == input.getCategory() || input.getCategory().isEmpty()) {
			if (null != userId) {
				projects = projectDAO.fetchAccountProjects(userId);
				
				
				if(null != projects && !projects.isEmpty())
				{
					
				
					for (Project project : projects) {
						
						if(null != project.getPhotos())
						{
							projectImage=ApplicationConstants.AWSS3IMAGEPATH +ApplicationConstants.PROJECTS3BUCKETPATH+
									ApplicationConstants.FILESEPERATOR+project.getProjectId()+ApplicationConstants.FILESEPERATOR+"1";
							System.out.println(projectImage);
							
							LocationPhotos locationPhotos = new LocationPhotos();
							locationPhotos.setProfilePhotoUrl(projectImage);
							project.setPhotos(locationPhotos);
							
							
						}
						
					}
					
				
				
				}
				
			}
		} else {
			projects = projectDAO.fetchAllProjects(input.getCategory());
		
				
				
				if(null != projects && !projects.isEmpty())
				{
					
				
					for (Project project : projects) {
						
						if(null != project.getPhotos())
						{
							projectImage=ApplicationConstants.AWSS3IMAGEPATH +ApplicationConstants.PROJECTS3BUCKETPATH+
									ApplicationConstants.FILESEPERATOR+project.getProjectId()+ApplicationConstants.FILESEPERATOR+"1";
							System.out.println(projectImage);
							
							LocationPhotos locationPhotos = new LocationPhotos();
							locationPhotos.setProfilePhotoUrl(projectImage);
							project.setPhotos(locationPhotos);
							
							
						}
						
					}
					
				
				projects = new ArrayList<Project>(projects);
				Collections.sort(projects);
			}
		}

		response = new ProjectResponse();
		response.setProjects(projects);
		response.setStatusCode(200);
		return response;
	}
	
}
