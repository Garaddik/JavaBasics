/*
 *  Copyright � 2017 HubCitiX, Inc. All right reserved.
 */
package com.hubcitix.project.action;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.project.dao.ProjectDAO;
import com.hubcitix.project.model.ProjectCategory;
import com.hubcitix.project.model.ProjectRequest;
import com.hubcitix.project.model.ProjectResponse;

/**
 * 
 * FetchCategories Action used to Fetch all Project Categories.
 *
 */
public class FetchCategories implements ProjectAction {

	@Override
	public ProjectResponse handle(ProjectRequest input, Context context) throws RuntimeException {
		ProjectResponse response = null;

		System.out.println("Fetch All Projects");

		List<ProjectCategory> projectCategories = null;

		ProjectDAO projectDAO = DAOFactory.getProjectDao();

		projectCategories = projectDAO.fetchAllCategories();
		if (null != projectCategories) {
			projectCategories = new ArrayList<ProjectCategory>(projectCategories);
			Collections.sort(projectCategories);
		}
		response = new ProjectResponse();
		response.setProjectCategories(projectCategories);
		response.setStatusCode(200);

		return response;
	}

}
