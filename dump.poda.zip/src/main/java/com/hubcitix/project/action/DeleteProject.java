package com.hubcitix.project.action;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.project.dao.ProjectDAO;
import com.hubcitix.project.model.Project;
import com.hubcitix.project.model.ProjectRequest;
import com.hubcitix.project.model.ProjectResponse;

public class DeleteProject implements ProjectAction {

	@Override
	public ProjectResponse handle(ProjectRequest input, Context context) throws RuntimeException {

		ProjectResponse response = null;

		if (null == input.getProjectId()) {
			System.err.println("Invalid inputObj, could not find action parameter");
			throw new BadRequestException("Insufficient Request!");
		}
		System.out.println("Delete Project: ProjectId " + input.getProjectId());
		ProjectDAO projectDAO = DAOFactory.getProjectDao();
		Project project = projectDAO.DeleteProject(input.getProjectId());

		response = new ProjectResponse();
		response.setProject(project);
		response.setStatusCode(200);

		return response;
	}
}
