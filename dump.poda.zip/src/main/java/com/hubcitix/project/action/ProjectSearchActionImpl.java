/*
 *  Copyright hubcitix.com to Present
 *  All right reserved
 */

package com.hubcitix.project.action;

import java.util.List;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.project.dao.ProjectDAO;
import com.hubcitix.project.model.Project;
import com.hubcitix.project.model.ProjectRequest;
import com.hubcitix.project.model.ProjectResponse;

public class ProjectSearchActionImpl implements ProjectAction {

	@Override
	public ProjectResponse handle(ProjectRequest input, Context context) throws RuntimeException {

		ProjectResponse response = null;
		List<Project> projects = null;
		if (null == input.getSearchKey()) {
			System.err.println("Invalid inputObj, could not find Search Key parameter");
			throw new BadRequestException("Insufficient Request!");
		}

		ProjectDAO projectDAO = DAOFactory.getProjectDao();

		projects = projectDAO.searchProjects(input.getSearchKey());

		response = new ProjectResponse();
		response.setProjects(projects);
		response.setStatusCode(200);
		return response;

	}

}
