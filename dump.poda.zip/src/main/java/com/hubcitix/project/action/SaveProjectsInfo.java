/*
 *  Copyright � 2017 HubCitiX, Inc. All right reserved.
 */
package com.hubcitix.project.action;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.Utility;
import com.hubcitix.common.helper.Helper;
import com.hubcitix.project.dao.ProjectDAO;
import com.hubcitix.project.model.Project;
import com.hubcitix.project.model.ProjectRequest;
import com.hubcitix.project.model.ProjectResponse;

/**
 * 
 * SaveProjectinfo Used to Create new Project.
 *
 */
public class SaveProjectsInfo implements ProjectAction {

	@Override
	public ProjectResponse handle(ProjectRequest input, Context context) throws RuntimeException {

		ProjectResponse response = null;

		if (null == input.getProject()) {
			System.err.println("Invalid inputObj, could not find action parameter");
			throw new BadRequestException("Insufficient Request!");
		}
		Helper helper = HelperFactory.getNewsHelper();
		String userId = helper.getUserUniqueId(input.getIdtoken());
		if (null == userId) {
			System.err.println("Invalid inputObj, could not find action parameter");
			throw new BadRequestException("Insufficient Request!");
		}
		System.out.println("New Project: UserId" + userId);
		ProjectDAO projectDAO = DAOFactory.getProjectDao();
		Project project = projectDAO.saveProjectsInfo(input.getProject(), userId);
		
		if(null != project )
		{
			if(null != project.getPhotos())
			{
				Utility.getProductimagePath(project.getImageType(), project.getPhotos().getProfilePhotoUrl(),project.getProjectId(),"project");
			}
			
			
		}

		response = new ProjectResponse();
		response.setProject(project);
		response.setStatusCode(201);

		return response;
	}
}
