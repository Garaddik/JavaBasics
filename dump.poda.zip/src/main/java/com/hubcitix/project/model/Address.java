/*
 *  Copyright � 2017 HubCitiX, Inc. All right reserved.
 */

package com.hubcitix.project.model;

/**
 * 
 * @author Shilpashree
 * 
 */
import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;

@DynamoDBDocument
public class Address {

	private List<String> addressLines = null;

	private String subLocality = null;

	private String city = null;

	private String state = null;

	private String postalCode = null;

	private String country = null;

	/**
	 * Gets addressLines
	 *
	 * @return addressLines
	 **/
	public List<String> getAddressLines() {
		return addressLines;
	}

	/**
	 * Sets the value of addressLines.
	 *
	 * @param addressLines
	 *            the new value
	 */
	public void setAddressLines(List<String> addressLines) {
		this.addressLines = addressLines;
	}

	/**
	 * Gets subLocality
	 *
	 * @return subLocality
	 **/
	public String getSubLocality() {
		return subLocality;
	}

	/**
	 * Sets the value of subLocality.
	 *
	 * @param subLocality
	 *            the new value
	 */
	public void setSubLocality(String subLocality) {
		this.subLocality = subLocality;
	}

	/**
	 * Gets city
	 *
	 * @return city
	 **/
	public String getCity() {
		return city;
	}

	/**
	 * Sets the value of city.
	 *
	 * @param city
	 *            the new value
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Gets state
	 *
	 * @return state
	 **/
	public String getState() {
		return state;
	}

	/**
	 * Sets the value of state.
	 *
	 * @param state
	 *            the new value
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Gets postalCode
	 *
	 * @return postalCode
	 **/
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * Sets the value of postalCode.
	 *
	 * @param postalCode
	 *            the new value
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * The [ISO 3166-1](https://www.iso.org/iso-3166-country-codes.html) alpha-2
	 * country code
	 *
	 * @return country
	 **/
	public String getCountry() {
		return country;
	}

	/**
	 * Sets the value of country.
	 *
	 * @param country
	 *            the new value
	 */
	public void setCountry(String country) {
		this.country = country;
	}

}
