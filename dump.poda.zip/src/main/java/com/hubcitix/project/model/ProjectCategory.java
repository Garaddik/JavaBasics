/*
 *  Copyright � 2017 HubCitiX, Inc. All right reserved.
 */
package com.hubcitix.project.model;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBDocument
@DynamoDBTable(tableName = "ProjectCategory")
public class ProjectCategory implements Comparable<ProjectCategory> {

	@DynamoDBHashKey
	private String category;

	private String title;

	private List<String> attributes;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<String> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<String> attributes) {
		this.attributes = attributes;
	}

	@Override
	public int compareTo(ProjectCategory projectCategory) {
		try {
			return this.getTitle().compareTo(projectCategory.getTitle());
		} catch (RuntimeException exception) {
			return -1;
		}
	}
}
