/*
 *  Copyright � 2017 HubCitiX, Inc. All right reserved.
 */

package com.hubcitix.project.model;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;

@DynamoDBDocument
public class LocationPhotos {

	private String profilePhotoUrl = null;

	private String coverPhotoUrl = null;

	/**
	 * Gets profilePhotoUrl
	 *
	 * @return profilePhotoUrl
	 **/
	public String getProfilePhotoUrl() {
		return profilePhotoUrl;
	}

	/**
	 * Sets the value of profilePhotoUrl.
	 *
	 * @param profilePhotoUrl
	 *            the new value
	 */
	public void setProfilePhotoUrl(String profilePhotoUrl) {
		this.profilePhotoUrl = profilePhotoUrl;
	}

	/**
	 * Gets coverPhotoUrl
	 *
	 * @return coverPhotoUrl
	 **/
	public String getCoverPhotoUrl() {
		return coverPhotoUrl;
	}

	/**
	 * Sets the value of coverPhotoUrl.
	 *
	 * @param coverPhotoUrl
	 *            the new value
	 */
	public void setCoverPhotoUrl(String coverPhotoUrl) {
		this.coverPhotoUrl = coverPhotoUrl;
	}

}