/*
 *  Copyright hubcitix.com to Present
 *  All right reserved
 */
package com.hubcitix.media.handler;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.hubcitix.media.action.PlayListItemsAction;
import com.hubcitix.media.action.PlayListItemsActionImpl;
import com.hubcitix.media.model.NewsItemsResponse;
import com.hubcitix.media.model.NewsRequest;

/**
 * 
 * Returns the list of PlaylistItems.
 * 
 * GET https://www.googleapis.com/youtube/v3/playlistItems
 * 
 * @author kirankumar.garaddi
 *
 */
public class MediaHandler implements RequestHandler<NewsRequest, NewsItemsResponse> {

	@Override
	public NewsItemsResponse handleRequest(NewsRequest input, Context context) throws BadRequestException, RuntimeException {

		NewsItemsResponse response = null;
		PlayListItemsAction action = null;
		try {
			if (input == null || input.getAction() == null || input.getAction().trim().equals("")) {
				System.err.println("Invald inputObj, could not find action parameter!");
				throw new BadRequestException("Could not find action value in request");
			} else {
				System.err.println("Input: " + input.getAction());
				switch (input.getAction()) {
				case "playlistitems":
					action = new PlayListItemsActionImpl();
					break;
				}
				response = action.hanlder(input, context);
			}
		} catch (RuntimeException exception) {
			context.getLogger().log("Unable to execute!");
			throw new RuntimeException(exception);
		}
		return response;
	}
}
