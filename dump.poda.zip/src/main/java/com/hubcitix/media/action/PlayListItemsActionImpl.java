/*
 *  Copyright hubcitix.com to Present
 *  All right reserved
 */
package com.hubcitix.media.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.model.PlaylistItem;
import com.google.api.services.youtube.model.PlaylistItemListResponse;
import com.hubcitix.common.Utility;
import com.hubcitix.media.model.NewsItem;
import com.hubcitix.media.model.NewsItemsResponse;
import com.hubcitix.media.model.NewsRequest;

/**
 * Action class used for Consuming google YouTube APIs, Configuring API Key and
 * Mapping YouTube API response to HubCitiX News Model
 * 
 * @author kirankumar.garaddi
 *
 */
public class PlayListItemsActionImpl implements PlayListItemsAction {
	static YouTube.PlaylistItems.List playlistItemRequest = null;

	@Override
	public NewsItemsResponse hanlder(NewsRequest input, Context context) throws BadRequestException, RuntimeException {

		NewsItemsResponse response = null;

		if (null == input.getPlayListId() || input.getPlayListId().isEmpty()) {
			System.err.println("PlayListId should not be empty!");
			throw new BadRequestException("Empty PlayListId");
		}

		List<NewsItem> newsItems = getPlayListItems(input.getPlayListId(), input.getMaxResults());

		response = new NewsItemsResponse();
		response.setStatusCode(200);
		response.setNewsItems(newsItems);

		return response;
	}

	/**
	 * 
	 * @param playListId
	 *            Play list Id which contains list of videos
	 * @param maxResults
	 *            returns specified list of items, default is 5 items
	 * @return
	 * @throws RuntimeException
	 */

	private List<NewsItem> getPlayListItems(String playListId, Long maxResults) throws RuntimeException {

		List<NewsItem> itemList = null;

		YouTube youtube = Utility.getYouTubeInstance();
		Properties property = Utility.getCredentialsPropertyFile();

		if (null == youtube) {
			throw new RuntimeException("Youtube Connection failed");
		}
		try {
			playlistItemRequest = youtube.playlistItems().list("id,snippet,contentDetails");
			playlistItemRequest.setKey(property.getProperty("youtube.apikey"));

			if (null != maxResults && maxResults > 0)
				playlistItemRequest.setMaxResults(maxResults);
			playlistItemRequest
					.setFields("items(snippet/resourceId/videoId,snippet/channelTitle,snippet/description,snippet/thumbnails/default,snippet/title,snippet/publishedAt)");
			playlistItemRequest.setPlaylistId(playListId);

			PlaylistItemListResponse playlistItemResult = playlistItemRequest.execute();

			if (null != playlistItemResult && !playlistItemResult.getItems().isEmpty())
				itemList = new ArrayList<NewsItem>();
			for (PlaylistItem playItem : playlistItemResult.getItems()) {

				NewsItem item = new NewsItem();
				// Mapping Google YouTube Response to HubCitiX Response
				item.setType("youtube");
				item.setDescription(playItem.getSnippet().getDescription());
				item.setTitle(playItem.getSnippet().getTitle());
				item.setImageUrl(playItem.getSnippet().getThumbnails().getDefault().getUrl());
				item.setGuid(playItem.getSnippet().getResourceId().getVideoId());
				item.setPubDate(Utility.convertStringdateToDynamodFormatLong(playItem.getSnippet().getPublishedAt().getValue()));
				item.setChannelTitle(playItem.getSnippet().getChannelTitle());
				itemList.add(item);

			}
		} catch (IOException e) {
			System.out.println("Error occurred while consuming Youtube API : " + e.getMessage());
			throw new RuntimeException(e);
		}
		return itemList;
	}
}
