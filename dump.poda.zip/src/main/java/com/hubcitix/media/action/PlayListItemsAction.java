/*
 *  Copyright hubcitix.com to Present
 *  All right reserved
 */
package com.hubcitix.media.action;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.media.model.NewsItemsResponse;
import com.hubcitix.media.model.NewsRequest;

public interface PlayListItemsAction {

	NewsItemsResponse hanlder(NewsRequest input, Context context);

}
