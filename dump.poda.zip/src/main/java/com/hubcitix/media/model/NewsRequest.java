/*
 *  Copyright hubcitix.com to Present
 *  All right reserved
 */
package com.hubcitix.media.model;

public class NewsRequest {

	private String action;

	private Long maxResults;

	private String playListId;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Long getMaxResults() {
		return maxResults;
	}

	public void setMaxResults(Long maxResults) {
		this.maxResults = maxResults;
	}

	public String getPlayListId() {
		return playListId;
	}

	public void setPlayListId(String playListId) {
		this.playListId = playListId;
	}

}
