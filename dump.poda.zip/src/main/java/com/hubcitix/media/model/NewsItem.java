/*
 *  Copyright hubcitix.com to Present
 *  All right reserved
 */
package com.hubcitix.media.model;

import java.util.List;

/**
 * Represents a single news item
 **/
public class NewsItem {
	/**
	 * A string that uniquely identifies the item, which can be used to
	 * Determine if an item is new.
	 */

	private String guid = null;
	/**
	 * Category to which this item belongs. Same as `NewsCategory.category`.
	 */
	private String category = null;
	/**
	 * type to identify the type of News Items like: YouTube,Article and video
	 * etc.
	 */

	private String type = null;
	/**
	 * Title of the news item
	 */

	private String title = null;
	/**
	 * The URL of the item
	 */

	private String link = null;
	/**
	 * Date indicating when the item was published
	 */

	private String pubDate = null;
	/**
	 * Email address of the author of the item
	 */

	private String author = null;
	/**
	 * The item synopsis
	 */

	private String description = null;
	/**
	 * URL to the first image content that appears in this item. May be used for
	 * the thumbnail of the item.
	 */

	private String imageUrl = null;
	/**
	 * Media content related to the item
	 */

	private List<NewsMedia> media = null;

	private String channelTitle = null;

	public String getChannelTitle() {
		return channelTitle;
	}

	public void setChannelTitle(String channelTitle) {
		this.channelTitle = channelTitle;
	}

	/**
	 * A string that uniquely identifies the item, which can be used to
	 * determine if an item is new.
	 *
	 * @return guid
	 **/
	public String getGuid() {
		return guid;
	}

	/**
	 * Sets the value of guid.
	 *
	 * @param guid
	 *            the new value
	 */
	public void setGuid(String guid) {
		this.guid = guid;
	}

	/**
	 * Category to which this item belongs. Same as `NewsCategory.category`.
	 *
	 * @return category
	 **/
	public String getCategory() {
		return category;
	}

	/**
	 * Sets the value of category.
	 *
	 * @param category
	 *            the new value
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * type to identify the type of News Items like: YouTube,Article and video
	 * etc.
	 *
	 * @return type
	 **/
	public String getType() {
		return type;
	}

	/**
	 * Sets the value of type.
	 *
	 * @param type
	 *            the new value
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Title of the news item
	 *
	 * @return title
	 **/
	public String getTitle() {
		return title;
	}

	/**
	 * Sets the value of title.
	 *
	 * @param title
	 *            the new value
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * The URL of the item
	 *
	 * @return link
	 **/
	public String getLink() {
		return link;
	}

	/**
	 * Sets the value of link.
	 *
	 * @param link
	 *            the new value
	 */
	public void setLink(String link) {
		this.link = link;
	}

	/**
	 * String indicating when the item was published
	 *
	 * @return pubDate
	 **/
	public String getPubDate() {
		return pubDate;
	}

	/**
	 * Sets the value of pubDate.
	 *
	 * @param pubDate
	 *            the new value
	 */
	public void setPubDate(String pubDate) {
		this.pubDate = pubDate;
	}

	/**
	 * Email address of the author of the item
	 *
	 * @return author
	 **/
	public String getAuthor() {
		return author;
	}

	/**
	 * Sets the value of author.
	 *
	 * @param author
	 *            the new value
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	/**
	 * The item synopsis
	 *
	 * @return description
	 **/
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the value of description.
	 *
	 * @param description
	 *            the new value
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * URL to the first image content that appears in this item. May be used for
	 * the thumbnail of the item.
	 *
	 * @return imageUrl
	 **/
	public String getImageUrl() {
		return imageUrl;
	}

	/**
	 * Sets the value of imageUrl.
	 *
	 * @param imageUrl
	 *            the new value
	 */
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	/**
	 * Media content related to the item
	 *
	 * @return media
	 **/
	public List<NewsMedia> getMedia() {
		return media;
	}

	/**
	 * Sets the value of media.
	 *
	 * @param media
	 *            the new value
	 */
	public void setMedia(List<NewsMedia> media) {
		this.media = media;
	}

}
