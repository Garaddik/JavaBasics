/*
 *  Copyright hubcitix.com to Present
 *  All right reserved
 */

package com.hubcitix.media.model;

import java.util.List;

/**
 * Response status code and Item(youtube Video) lists.
 **/
public class NewsItemsResponse {

	private Integer statusCode = null;

	private List<NewsItem> newsItems = null;

	/**
	 * Gets statusCode
	 *
	 * @return statusCode
	 **/
	public Integer getStatusCode() {
		return statusCode;
	}

	/**
	 * Sets the value of statusCode.
	 *
	 * @param statusCode
	 *            the new value
	 */
	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * Gets newsItems
	 *
	 * @return newsItems
	 **/
	public List<NewsItem> getNewsItems() {
		return newsItems;
	}

	/**
	 * Sets the value of newsItems.
	 *
	 * @param newsItems
	 *            the new value
	 */
	public void setNewsItems(List<NewsItem> newsItems) {
		this.newsItems = newsItems;
	}

}
