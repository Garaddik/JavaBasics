/*
 * Copyright 2010-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.hubcitix.media.model;

/**
 * Media content related to a news and Youtube Videos item
 **/
public class NewsMedia {
	/**
	 * type of media ex: thumbnail,images,html
	 */
	private String type = null;
	/**
	 * The URL to the media object
	 */
	private String url = null;
	/**
	 * The height of the media object
	 */
	private Integer height = null;
	/**
	 * The width of the media object
	 */
	private Integer width = null;

	/**
	 * type of media ex: thumbnail,images,html
	 *
	 * @return type
	 **/
	public String getType() {
		return type;
	}

	/**
	 * Sets the value of type.
	 *
	 * @param type
	 *            the new value
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * The URL to the media object
	 *
	 * @return url
	 **/
	public String getUrl() {
		return url;
	}

	/**
	 * Sets the value of url.
	 *
	 * @param url
	 *            the new value
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * The height of the media object minimum: 0.0
	 *
	 * @return height
	 **/
	public Integer getHeight() {
		return height;
	}

	/**
	 * Sets the value of height.
	 *
	 * @param height
	 *            the new value
	 */
	public void setHeight(Integer height) {
		this.height = height;
	}

	/**
	 * The width of the media object minimum: 0.0
	 *
	 * @return width
	 **/
	public Integer getWidth() {
		return width;
	}

	/**
	 * Sets the value of width.
	 *
	 * @param width
	 *            the new value
	 */
	public void setWidth(Integer width) {
		this.width = width;
	}

}
