package com.hubcitix.business.eventaction;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.dao.EventDao;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.business.model.PublicEvent;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.helper.Helper;
/**
 * This class contais event creation methods.
 * @author shyamsundara_hm
 *
 */
public class CreateEvent implements EventAction {

	/**
	 * This method is used to create event.
	 */
	@Override
	public BusinessResponse handle(PublicEvent publicEvent, Context context)
			throws RuntimeException {

		Helper helper = HelperFactory.getNewsHelper();
		String userId = helper.getUserUniqueId(publicEvent.getIdtoken());
		BusinessResponse businessResponse = null;
		try {

			EventDao eventDao = DAOFactory.getEventDao();

			businessResponse = eventDao.createEvent(publicEvent, userId);

			if (null != businessResponse) {
				if (null == businessResponse.getPublicEvent()) {
					businessResponse
							.setResponse(ApplicationConstants.ERROROCCURED);
					businessResponse
							.setStatusCode(ApplicationConstants.FAILURECODE);
				} else {

					businessResponse
							.setStatusCode(ApplicationConstants.BUSINESSCREATIONSUCCESSCODE);
				}
			}

		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
		return businessResponse;
	}

}
