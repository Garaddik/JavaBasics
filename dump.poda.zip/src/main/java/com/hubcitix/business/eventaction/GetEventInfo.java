package com.hubcitix.business.eventaction;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.dao.EventDao;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.business.model.PublicEvent;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;

public class GetEventInfo implements EventAction {

	/**
	 * Below method is used to fetch particular event information from dynamo db.
	 */
	@Override
	public BusinessResponse handle(PublicEvent publicEvent, Context context)
			throws RuntimeException {
		BusinessResponse myBusinessResponse = null;
		try {

			EventDao eventDao = DAOFactory.getEventDao();

			if (null != publicEvent.getAccountId()
					&& publicEvent.getAccountId().equals(
							ApplicationConstants.PRIMARY)) {
				myBusinessResponse = eventDao.GetEventInfo(publicEvent);
			}

			if (null != myBusinessResponse) {
				if (null == myBusinessResponse.getPublicEvent()) {
					myBusinessResponse
							.setResponse(ApplicationConstants.ERROROCCURED);
					myBusinessResponse
							.setStatusCode(ApplicationConstants.FAILURECODE);
				} else {

					myBusinessResponse
							.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
				}
			}

		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
		return myBusinessResponse;
	}
}
