package com.hubcitix.business.eventaction;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.dao.EventDao;
import com.hubcitix.business.model.BusinessAccount;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.business.model.PublicEvent;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.BusinessCloudSearch;
import com.hubcitix.common.DAOFactory;

public class SearchBusinessAction implements EventAction {

	/**
	 * Below method is used fetch business and business location details from dynamodb.
	 */
	@Override
	public BusinessResponse handle(PublicEvent request, Context context)
			throws RuntimeException {
		
		List<BusinessAccount> businessAccountlst = BusinessCloudSearch.getBusinessSearchResult(request.getSearchKey());
		
		BusinessResponse businessResponse = new BusinessResponse();
		BusinessAccount  businessAccount = null;
		List<BusinessLocation> finalbusinessLocationsLst = null;
		List<BusinessAccount> finalbusinessAccountsLst = null;
		EventDao eventDao = DAOFactory.getEventDao();
		if(null != businessAccountlst && !businessAccountlst.isEmpty())
		{
			finalbusinessAccountsLst = new ArrayList<BusinessAccount>();
			for (BusinessAccount businessAccount2 : businessAccountlst) {
				businessAccount= new BusinessAccount();
				businessAccount.setAccountId(businessAccount2.getAccountId());
				businessAccount.setAccountName(businessAccount2.getAccountName());
				finalbusinessLocationsLst = new 	ArrayList<BusinessLocation> ();
				finalbusinessLocationsLst=	eventDao.GetBusinessLocationList(businessAccount2);
				if(null !=finalbusinessLocationsLst && !finalbusinessLocationsLst.isEmpty())
				{
					
					businessAccount.setBusinessLocationList(finalbusinessLocationsLst);
				}
				
				finalbusinessAccountsLst.add(businessAccount);
			}
			
		}
		
		if(null !=finalbusinessAccountsLst &&! finalbusinessAccountsLst.isEmpty())
		{
			businessResponse.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
			businessResponse.setBusinessAccountList(finalbusinessAccountsLst);
		}else{
			businessResponse.setStatusCode(ApplicationConstants.FAILURECODE);
			
		}
		
		
		return businessResponse;
	}

}
