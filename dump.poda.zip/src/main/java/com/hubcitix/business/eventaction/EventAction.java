package com.hubcitix.business.eventaction;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.business.model.PublicEvent;

public interface EventAction {

	public BusinessResponse handle(PublicEvent request, Context context)
			throws RuntimeException;

}
