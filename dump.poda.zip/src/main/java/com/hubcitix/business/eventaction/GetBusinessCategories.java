package com.hubcitix.business.eventaction;

import java.util.Collections;
import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.dao.EventDao;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.business.model.PublicEvent;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.model.BusinessCategory;

/**
 * This method is used to get all business categories..
 * 
 * @author shyamsundara_hm
 *
 */
public class GetBusinessCategories implements EventAction {

	@Override
	public BusinessResponse handle(PublicEvent publicEvent, Context context) throws RuntimeException {
		List<BusinessCategory> businessCategoryList = null;
		BusinessResponse businessResponse = new BusinessResponse();
		EventDao eventDao = DAOFactory.getEventDao();
		businessCategoryList = eventDao.GetBusinessCategories(publicEvent);

		if (null != businessCategoryList && !businessCategoryList.isEmpty()) {
			
			
			
		//	Collections.sort(businessCategoryList, new SortBusinessCategory());
			
			businessResponse.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
			businessResponse.setBusinessCategoryList(businessCategoryList);
		} else {

			businessResponse.setStatusCode(ApplicationConstants.FAILURECODE);
		}

		return businessResponse;
	}

}
