package com.hubcitix.business.eventaction;

import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.dao.EventDao;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.business.model.PublicEvent;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.helper.Helper;

public class GetAllEvents implements EventAction {

	/**
	 * Below method is used to fetch all the events from dynamodb.
	 */
	@Override
	public BusinessResponse handle(PublicEvent publicEvent, Context context)
			throws RuntimeException {
		BusinessResponse myBusinessResponse = null;
		try {

			EventDao eventDao = DAOFactory.getEventDao();
			myBusinessResponse = new BusinessResponse();
			List<PublicEvent> publicEventsList = null;
			Helper helper = HelperFactory.getNewsHelper();
			String userId = helper.getUserUniqueId(publicEvent.getIdtoken());
			if (null != publicEvent) {

				if (null != publicEvent.getAccountId()
						&& publicEvent.getAccountId().equals(
								ApplicationConstants.PRIMARY)) {
					publicEvent.setAccountId(userId);
					publicEventsList = eventDao.GetAllEvents(publicEvent);
				} else {
					publicEventsList = eventDao.GetAllEvents(publicEvent);
				}

			}

			if (null != publicEventsList && !publicEventsList.isEmpty()) {
				myBusinessResponse.setPublicEventsList(publicEventsList);
				myBusinessResponse
						.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
			} else {

				myBusinessResponse
						.setStatusCode(ApplicationConstants.FAILURECODE);
				myBusinessResponse
						.setResponse(ApplicationConstants.ERROROCCURED);
			}

		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
		return myBusinessResponse;
	}

}
