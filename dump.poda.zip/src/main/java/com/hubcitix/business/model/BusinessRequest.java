package com.hubcitix.business.model;

public class BusinessRequest {

	private String action;
	private String idtoken;
	private BusinessLocation businessLocation;
	private String locationId;
	private String accountId;
	private String account;
	private PublicEvent publicEvent;
	private String eventId;
	private String searchKey;
	private String northeast;
	private String southwest;

	public String getNortheast() {
		return northeast;
	}

	public void setNortheast(String northeast) {
		this.northeast = northeast;
	}

	public String getSouthwest() {
		return southwest;
	}

	public void setSouthwest(String southwest) {
		this.southwest = southwest;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public BusinessLocation getBusinessLocation() {
		return businessLocation;
	}

	public void setBusinessLocation(BusinessLocation businessLocation) {
		this.businessLocation = businessLocation;
	}

	public String getIdtoken() {
		return idtoken;
	}

	public void setIdtoken(String idtoken) {
		this.idtoken = idtoken;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public PublicEvent getPublicEvent() {
		return publicEvent;
	}

	public void setPublicEvent(PublicEvent publicEvent) {
		this.publicEvent = publicEvent;
	}

	public String getSearchKey() {
		return searchKey;
	}

	public void setSearchKey(String searchKey) {
		this.searchKey = searchKey;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

}
