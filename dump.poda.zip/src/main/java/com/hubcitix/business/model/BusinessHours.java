package com.hubcitix.business.model;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;

@DynamoDBDocument
public class BusinessHours {

	
	private String openDay;
	private String openTime;
	private String closeDay;
	private String closeTime;
	public String getOpenDay() {
		return openDay;
	}
	public void setOpenDay(String openDay) {
		this.openDay = openDay;
	}
	public String getOpenTime() {
		return openTime;
	}
	public void setOpenTime(String openTime) {
		this.openTime = openTime;
	}
	public String getCloseDay() {
		return closeDay;
	}
	public void setCloseDay(String closeDay) {
		this.closeDay = closeDay;
	}
	public String getCloseTime() {
		return closeTime;
	}
	public void setCloseTime(String closeTime) {
		this.closeTime = closeTime;
	}
	
}
