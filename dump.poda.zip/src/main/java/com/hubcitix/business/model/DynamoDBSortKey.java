package com.hubcitix.business.model;

public @interface DynamoDBSortKey {

}
