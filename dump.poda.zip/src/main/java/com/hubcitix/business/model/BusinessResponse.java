/*
 * Copyright 2010-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.hubcitix.business.model;

import java.util.List;

import com.hubcitix.common.model.BusinessCategory;

public class BusinessResponse {

	private Integer statusCode = null;

	private String response;
	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	private BusinessLocation businessLocation = null;

	private List<BusinessLocation> businessLocationList = null;
	
	private PublicEvent publicEvent = null;
	
	private List<PublicEvent> publicEventsList = null;
	
	private List<BusinessAccount> businessAccountList = null;
	
	private List<BusinessCategory> businessCategoryList = null;
	
	public BusinessLocation getBusinessLocation() {
		return businessLocation;
	}

	public void setBusinessLocation(BusinessLocation businessLocation) {
		this.businessLocation = businessLocation;
	}


	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public List<BusinessLocation> getBusinessLocationList() {
		return businessLocationList;
	}

	public void setBusinessLocationList(List<BusinessLocation> businessLocationList) {
		this.businessLocationList = businessLocationList;
	}

	public PublicEvent getPublicEvent() {
		return publicEvent;
	}

	public void setPublicEvent(PublicEvent publicEvent) {
		this.publicEvent = publicEvent;
	}

	public List<PublicEvent> getPublicEventsList() {
		return publicEventsList;
	}

	public void setPublicEventsList(List<PublicEvent> publicEventsList) {
		this.publicEventsList = publicEventsList;
	}

	public List<BusinessAccount> getBusinessAccountList() {
		return businessAccountList;
	}

	public void setBusinessAccountList(List<BusinessAccount> businessAccountList) {
		this.businessAccountList = businessAccountList;
	}

	public List<BusinessCategory> getBusinessCategoryList() {
		return businessCategoryList;
	}

	public void setBusinessCategoryList(List<BusinessCategory> businessCategoryList) {
		this.businessCategoryList = businessCategoryList;
	}

	/**
	 * Gets business
	 *
	 * @return business
	 **/
	
}
