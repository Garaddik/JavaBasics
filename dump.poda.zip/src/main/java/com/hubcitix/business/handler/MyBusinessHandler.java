package com.hubcitix.business.handler;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.hubcitix.business.action.FetchAllBusiness;
import com.hubcitix.business.action.FetchAllMapLocations;
import com.hubcitix.business.action.FetchBusinessInfo;
import com.hubcitix.business.action.MyBusinessAction;
import com.hubcitix.business.action.SaveBusinessInfoAction;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.business.model.BusinessRequest;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.common.Utility;

public class MyBusinessHandler implements RequestHandler<BusinessRequest, BusinessResponse> {

	@Override
	public BusinessResponse handleRequest(BusinessRequest input, Context context) throws RuntimeException {
		MyBusinessAction myBusinessAction = null;

		BusinessResponse businessResponse = null;
		if (null == context) {
			Utility.STAGE = "Dev_";
		} else {
			Utility.STAGE = Utility.getCurrentStage(context.getInvokedFunctionArn());
		}
		try {
			if (input == null || input.getAction() == null || input.getAction().trim().equals("")) {

				context.getLogger().log("Invald inputObj, could not find action  parameter");
				throw new BadRequestException("Could not find action value in request");
			} else {

				// context.getLogger().log("Input: " + input.getAction());
				switch (input.getAction()) {
				case "createbusiness":
					input.getBusinessLocation().setAccount(input.getAccount());
					input.getBusinessLocation().setIdtoken(input.getIdtoken());
					myBusinessAction = new SaveBusinessInfoAction();
					break;

				case "getbusiness":
					input.getBusinessLocation().setAccountId(input.getAccountId());
					input.getBusinessLocation().setLocationId(input.getLocationId());
					myBusinessAction = new FetchBusinessInfo();
					break;

				case "getallbusiness":
					input.getBusinessLocation().setAccountId(input.getAccountId());
					input.getBusinessLocation().setIdtoken(input.getIdtoken());
					myBusinessAction = new FetchAllBusiness();
					break;
				case "getAllMapLocations":
					FetchAllMapLocations maplocation = new FetchAllMapLocations();
					businessResponse = maplocation.handle(input.getNortheast(), input.getSouthwest(), context);
					return businessResponse;
				default:
					context.getLogger().log("Invald inputObj, could not find action parameters");

				}
			}

			businessResponse = myBusinessAction.handle(input.getBusinessLocation(), context);
		} catch (RuntimeException exception) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			throw new RuntimeException(exception);

		}
		return businessResponse;
	}

	public static void main(String a[]) {
		MyBusinessAction myBusinessAction = new FetchBusinessInfo();
		BusinessLocation l = new BusinessLocation();
		l.setAccountId("primary");
		l.setLocationId("8ae40715-37dd-4530-b7a6-16e781a9859b");
		// l.setIdtoken("8449ed1d-da7c-4769-9a16-5a5d589cbf7f");
		BusinessResponse r = myBusinessAction.handle(l, null);
		System.out.println(r.toString());

	}

}
