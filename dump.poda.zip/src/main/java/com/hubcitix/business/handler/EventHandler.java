package com.hubcitix.business.handler;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.hubcitix.business.eventaction.CreateEvent;
import com.hubcitix.business.eventaction.EventAction;
import com.hubcitix.business.eventaction.GetAllEvents;
import com.hubcitix.business.eventaction.GetBusinessCategories;
import com.hubcitix.business.eventaction.GetEventInfo;
import com.hubcitix.business.eventaction.SearchBusinessAction;
import com.hubcitix.business.model.BusinessRequest;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.common.Utility;

/**
 * This class is used to handle event operations..
 * 
 * @author shyamsundara_hm
 *
 */
public class EventHandler implements RequestHandler<BusinessRequest, BusinessResponse> {
	{

	}

	/**
	 * Below method is used to handle all event actions and naviagate to the
	 * particulcar event action.
	 */
	@Override
	public BusinessResponse handleRequest(BusinessRequest input, Context context) {
		EventAction eventAction = null;

		BusinessResponse businessResponse = null;
		if (null == context) {
			Utility.STAGE = "Dev_";
		} else {
			Utility.STAGE = Utility.getCurrentStage(context.getInvokedFunctionArn());
		}
		try {
			if (input == null || input.getAction() == null || input.getAction().trim().equals("")) {

				context.getLogger().log("Invald inputObj, could not find action parameter");
				throw new BadRequestException("Could not find action value in request");
			} else {

				System.out.println("Input: " + input.getAction());
				switch (input.getAction()) {
				case "createevent":
					input.getPublicEvent().setIdtoken(input.getIdtoken());
					eventAction = new CreateEvent();
					break;

				case "geteventinfo":
					input.getPublicEvent().setAccountId(input.getAccountId());
					input.getPublicEvent().setEventId(input.getEventId());
					eventAction = new GetEventInfo();
					break;

				case "getallevents":
					input.getPublicEvent().setAccountId(input.getAccountId());
					input.getPublicEvent().setIdtoken(input.getIdtoken());
					eventAction = new GetAllEvents();
					break;

				case "searchbusiness":

					if (null == input.getSearchKey()) {
						System.err.println("Invald inputObj, could not find business search key parameter");
						throw new BadRequestException("Could not find action value in request");
					}
					input.getPublicEvent().setSearchKey(input.getSearchKey());
					eventAction = new SearchBusinessAction();
					break;
				case "getcategories":
					input.getPublicEvent().setSearchKey(input.getSearchKey());
					eventAction = new GetBusinessCategories();
					break;
				default:
					context.getLogger().log("Invald inputObj, could not find action parameters");

				}
			}

			businessResponse = eventAction.handle(input.getPublicEvent(), context);
		} catch (RuntimeException exception) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			throw new RuntimeException(exception);

		}
		return businessResponse;

	}

}