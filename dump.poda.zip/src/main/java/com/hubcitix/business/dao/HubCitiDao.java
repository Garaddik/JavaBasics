package com.hubcitix.business.dao;

import java.util.List;

import com.hubcitix.business.model.BusinessAccount;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.business.model.LatLngBounds;
import com.hubcitix.common.model.BusinessCategory;

public interface HubCitiDao {

	public List<BusinessLocation> fetchAllMapLocations(LatLngBounds latlongbounds) throws RuntimeException;

	public List<BusinessCategory> getActivityTypeForCatgry() throws RuntimeException;

	public BusinessResponse saveMyBusinessInfo(BusinessLocation location, BusinessAccount account) throws RuntimeException;

	public BusinessResponse fetchBusinessInfo(BusinessLocation mybusiness) throws RuntimeException;

	public List<BusinessLocation> fetchAllBusiness(String UserId) throws RuntimeException;

	/*
	 * public void saveAllBusinessInfo(List<Business> googleBusinessList)throws
	 * RuntimeException;
	 */

}
