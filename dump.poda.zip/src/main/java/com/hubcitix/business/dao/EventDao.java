package com.hubcitix.business.dao;

import java.util.List;

import com.hubcitix.business.model.BusinessAccount;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.business.model.PublicEvent;
import com.hubcitix.common.model.BusinessCategory;

/**
 * This interface contains all event Dao methods.
 * @author shyamsundara_hm
 *
 */
public interface EventDao {

	public BusinessResponse createEvent(PublicEvent publicEvent, String userId)
			throws RuntimeException;

	public List<PublicEvent> GetAllEvents(PublicEvent publicEvent)
			throws RuntimeException;

	public BusinessResponse GetEventInfo(PublicEvent publicEvent)
			throws RuntimeException;

	public List<BusinessCategory> GetBusinessCategories(PublicEvent publicEvent)
			throws RuntimeException;
	
	public List<BusinessLocation> GetBusinessLocationList(BusinessAccount publicEvent)
			throws RuntimeException;
}
