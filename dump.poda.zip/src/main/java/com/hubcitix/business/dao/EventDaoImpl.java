package com.hubcitix.business.dao;

import java.util.HashMap;
import java.util.List;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.InternalServerErrorException;
import com.hubcitix.business.model.BusinessAccount;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.business.model.PublicEvent;
import com.hubcitix.common.DBConnection;
import com.hubcitix.common.TableNames;
import com.hubcitix.common.Utility;
import com.hubcitix.common.model.BusinessCategory;

/**
 * This class is used to implement all event Dao implementation methods.
 * 
 * @author shyamsundara_hm
 *
 */
public class EventDaoImpl implements EventDao {

	private static DynamoDBMapper dynamoDBMapper;

	private static EventDaoImpl instance = null;

	public static EventDao getInstance() {
		if (instance == null) {
			instance = new EventDaoImpl();
		}
		return instance;
	}

	/**
	 * This method is used to create event and event details will be saved into
	 * dynamo db.
	 */
	@Override
	public BusinessResponse createEvent(PublicEvent publicEvent, String userId) throws RuntimeException {
		BusinessResponse businessResponse = null;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			businessResponse = new BusinessResponse();
			if (null != publicEvent) {
				publicEvent.setAccountId(userId);
				publicEvent.setIdtoken(null);

			}

			dynamoDBMapper.save(publicEvent, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PUBLICEVENT).config());
			businessResponse.setPublicEvent(publicEvent);

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}

		return businessResponse;
	}

	/**
	 * Below method is used to fetch all created events from dynamodb.
	 */
	@Override
	public List<PublicEvent> GetAllEvents(PublicEvent publicEvent) throws RuntimeException {
		List<PublicEvent> publicEventList = null;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			if (null != publicEvent) {

				publicEvent.setIdtoken(null);

			}

			HashMap<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
			eav.put(":accountId", new AttributeValue().withS(publicEvent.getAccountId()));

			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression().withFilterExpression("accountId = :accountId").withExpressionAttributeValues(eav);

			publicEventList = dynamoDBMapper.scan(PublicEvent.class, scanExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PUBLICEVENT).config());

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return publicEventList;
	}

	/**
	 * Below method is used to get particular event information.
	 */
	@Override
	public BusinessResponse GetEventInfo(PublicEvent publicEvent) throws RuntimeException {
		BusinessResponse businessResponse = null;
		try {

			dynamoDBMapper = DBConnection.getDynamoConnection();
			if (null != publicEvent) {
				publicEvent.setIdtoken(null);

				PublicEvent publicEventObj = dynamoDBMapper.load(PublicEvent.class, publicEvent.getEventId(), new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE
						+ TableNames.PUBLICEVENT).config());
				businessResponse = new BusinessResponse();
				businessResponse.setPublicEvent(publicEventObj);
			}

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return businessResponse;
	}

	/**
	 * Below method is used to get all business categories.
	 */
	@Override
	public List<BusinessCategory> GetBusinessCategories(PublicEvent publicEvent) throws RuntimeException {
		List<BusinessCategory> businessCategoryList = null;
		try {

			dynamoDBMapper = DBConnection.getDynamoConnection();
			if (null != publicEvent) {

				publicEvent.setIdtoken(null);

			}
			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
			businessCategoryList = dynamoDBMapper.scan(BusinessCategory.class, scanExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE
					+ TableNames.BUSINESSCATEGORY).config());

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return businessCategoryList;
	}

	/**
	 * Below method is used to fetch business location details based on business
	 * searck key.
	 */
	@Override
	public List<BusinessLocation> GetBusinessLocationList(BusinessAccount publicEvent) throws RuntimeException {
		List<BusinessLocation> publicEventList = null;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			HashMap<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
			eav.put(":accountId", new AttributeValue().withS(publicEvent.getAccountId()));

			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression().withFilterExpression("accountId = :accountId").withExpressionAttributeValues(eav);

			publicEventList = dynamoDBMapper.scan(BusinessLocation.class, scanExpression,
					new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSLOCATION).config());

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return publicEventList;
	}

}
