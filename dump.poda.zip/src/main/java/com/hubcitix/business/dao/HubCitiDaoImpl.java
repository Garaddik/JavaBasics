package com.hubcitix.business.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.InternalServerErrorException;
import com.hubcitix.business.model.BusinessAccount;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.business.model.LatLngBounds;
import com.hubcitix.common.DBConnection;
import com.hubcitix.common.TableNames;
import com.hubcitix.common.Utility;
import com.hubcitix.common.model.BusinessCategory;

public class HubCitiDaoImpl implements HubCitiDao {

	private static DynamoDBMapper dynamoDBMapper;

	private static HubCitiDaoImpl instance = null;

	public static HubCitiDao getInstance() {
		if (instance == null) {
			instance = new HubCitiDaoImpl();
		}
		return instance;
	}

	@Override
	public BusinessResponse saveMyBusinessInfo(BusinessLocation location, BusinessAccount account) throws RuntimeException {
		BusinessResponse businessResponse = null;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			businessResponse = new BusinessResponse();
			List<BusinessAccount> accountList = null;

			Map<String, AttributeValue> eav1 = new HashMap<String, AttributeValue>();
			eav1.put(":userId", new AttributeValue().withS(account.getUserId()));
			DynamoDBScanExpression queryExpression1 = new DynamoDBScanExpression().withFilterExpression("userId = :userId").withExpressionAttributeValues(eav1);

			accountList = dynamoDBMapper.scan(BusinessAccount.class, queryExpression1,
					new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSACCOUNT).config());

			if (null == accountList || accountList.isEmpty()) {
				dynamoDBMapper.save(account, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSACCOUNT).config());
				if (null != account) {
					location.setAccountId(account.getAccountId());
				}
			} else {
				location.setAccountId(accountList.get(0).getAccountId());
			}

			dynamoDBMapper.save(location, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSLOCATION).config());
			businessResponse.setBusinessLocation(location);

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}

		return businessResponse;
	}

	@Override
	public BusinessResponse fetchBusinessInfo(BusinessLocation business) throws RuntimeException {
		BusinessResponse businessResponse = null;
		try {

			dynamoDBMapper = DBConnection.getDynamoConnection();
			if (null != business) {

				business.setIdtoken(null);

			}

			BusinessLocation businessObj = null;
			businessObj = dynamoDBMapper.load(BusinessLocation.class, business.getLocationId(), new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE
					+ TableNames.BUSINESSLOCATION).config());
			businessResponse = new BusinessResponse();
			businessResponse.setBusinessLocation(businessObj);

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return businessResponse;

	}

	@Override
	public List<BusinessLocation> fetchAllBusiness(String userId) throws RuntimeException {
		List<BusinessLocation> businesslst = null;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();

			Map<String, AttributeValue> eav1 = new HashMap<String, AttributeValue>();
			eav1.put(":userId", new AttributeValue().withS(userId));
			DynamoDBScanExpression queryExpression1 = new DynamoDBScanExpression().withFilterExpression("userId = :userId").withExpressionAttributeValues(eav1);

			List<BusinessAccount> accounts = null;
			accounts = dynamoDBMapper
					.scan(BusinessAccount.class, queryExpression1, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSACCOUNT).config());

			if (null != accounts && !accounts.isEmpty()) {
				Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
				eav.put(":accountId", new AttributeValue().withS(accounts.get(0).getAccountId()));
				//
				// DynamoDBQueryExpression<BusinessLocation> queryExpression =
				// new DynamoDBQueryExpression<BusinessLocation>()
				// .withConsistentRead(false)
				// .withKeyConditionExpression("accountId = :accountId ")
				// .withExpressionAttributeValues(eav);

				DynamoDBScanExpression queryExpression = new DynamoDBScanExpression().withFilterExpression("accountId = :accountId").withExpressionAttributeValues(eav);
				businesslst = dynamoDBMapper.scan(BusinessLocation.class, queryExpression,
						new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSLOCATION).config());

			}

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return businesslst;

	}

	/**
	 * Method to fetch business locations within particular southwest and
	 * northeast lat long of Map.
	 * 
	 * @param southwest
	 * @param northeast
	 * @return businessList.
	 * 
	 * @throws RuntimeException
	 */
	@Override
	public List<BusinessLocation> fetchAllMapLocations(LatLngBounds latlongbounds) throws RuntimeException {
		List<BusinessLocation> businessList = null;
		double minLattitude = 0;
		double maxLatitude = 0;
		double minLongitude = 0;
		double maxLongitude = 0;
		List<BusinessLocation> truncateBusinessloc = new ArrayList<BusinessLocation>();

		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();

			int latDiffrence = Double.compare(latlongbounds.getSouthwest().getLatitude(), latlongbounds.getNortheast().getLatitude());
			if (latDiffrence > 0) {
				minLattitude = latlongbounds.getNortheast().getLatitude();
				maxLatitude = latlongbounds.getSouthwest().getLatitude();
			} else {
				minLattitude = latlongbounds.getSouthwest().getLatitude();
				maxLatitude = latlongbounds.getNortheast().getLatitude();
			}

			int lngDiffrence = Double.compare(latlongbounds.getSouthwest().getLongitude(), latlongbounds.getNortheast().getLongitude());
			if (lngDiffrence > 0) {
				minLongitude = latlongbounds.getNortheast().getLongitude();
				maxLongitude = latlongbounds.getSouthwest().getLongitude();
			} else {
				minLongitude = latlongbounds.getSouthwest().getLongitude();
				maxLongitude = latlongbounds.getNortheast().getLongitude();
			}

			eav.put(":minLattitude", new AttributeValue().withN(String.valueOf(minLattitude)));
			eav.put(":maxLatitude", new AttributeValue().withN(String.valueOf(maxLatitude)));
			eav.put(":minLongitude", new AttributeValue().withN(String.valueOf(minLongitude)));
			eav.put(":maxLongitude", new AttributeValue().withN(String.valueOf(maxLongitude)));

			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression().withFilterExpression(
					"geo.latitude between :minLattitude and :maxLatitude AND geo.longitude between :minLongitude and :maxLongitude AND attribute_exists(photos)").withExpressionAttributeValues(eav);

			businessList = dynamoDBMapper.scan(BusinessLocation.class, scanExpression,
					new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSLOCATION).config());

			if (null != businessList && !businessList.isEmpty()) {
				// businessList = new ArrayList<BusinessLocation>();
				truncateBusinessloc = businessList.stream().limit(15).collect(Collectors.toList());
			}
		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return truncateBusinessloc;
	}

	/**
	 * Method to fetch all the Business Categories.
	 * 
	 * @return businessCategoryLst.
	 * 
	 * @throws RuntimeException
	 */
	@Override
	public List<BusinessCategory> getActivityTypeForCatgry() throws RuntimeException {
		List<BusinessCategory> businessCategoryLst = null;

		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
			businessCategoryLst = dynamoDBMapper.scan(BusinessCategory.class, scanExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE
					+ TableNames.BUSINESSCATEGORY).config());

		} catch (BadRequestException exception) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}

		return businessCategoryLst;

	}
}
