package com.hubcitix.business.action;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.dao.HubCitiDao;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.business.model.LatLng;
import com.hubcitix.business.model.LatLngBounds;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.model.BusinessCategory;

/**
 * To fetch the business locations to drop in the map, based on the map
 * southwest and northeast lat, longs of map viewport.
 * 
 * @author vaidehi.ne
 *
 */
public class FetchAllMapLocations {

	public BusinessResponse handle(String northeast, String southwest, Context context) throws RuntimeException {
		BusinessResponse businessResponse = new BusinessResponse();
		List<BusinessCategory> businessCategory = null;
		List<BusinessLocation> businessLocationList = null;
		List<BusinessLocation> mapBusinessLctnLst = new ArrayList<BusinessLocation>();
		LatLngBounds latlngbounds = new LatLngBounds();

		try {
			HubCitiDao hubCitiDao = DAOFactory.getHubCitiDao();
			if (null != southwest && null != northeast) {

				String[] splitValue = northeast.split(",");
				latlngbounds.setNortheast(new LatLng());
				latlngbounds.getNortheast().setLatitude(Double.parseDouble(splitValue[0]));
				latlngbounds.getNortheast().setLongitude(Double.parseDouble(splitValue[1]));

				splitValue = southwest.split(",");
				latlngbounds.setSouthwest(new LatLng());
				latlngbounds.getSouthwest().setLatitude(Double.parseDouble(splitValue[0]));
				latlngbounds.getSouthwest().setLongitude(Double.parseDouble(splitValue[1]));

				businessLocationList = hubCitiDao.fetchAllMapLocations(latlngbounds);

				if (null != businessLocationList) {
					businessCategory = hubCitiDao.getActivityTypeForCatgry();

					if (null != businessCategory) {
						for (BusinessLocation mapLocations : businessLocationList) {
							for (BusinessCategory category : businessCategory) {
								if (category.getCategory().equals(mapLocations.getCategories().get(0))) {

									mapLocations.setActivityType(category.getType());
									mapBusinessLctnLst.add(mapLocations);
								}
							}
						}
					}
				}
			}

			if (null != mapBusinessLctnLst && !mapBusinessLctnLst.isEmpty()) {
				businessResponse.setBusinessLocationList(mapBusinessLctnLst);
				businessResponse.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
			} else {
				businessResponse.setStatusCode(ApplicationConstants.FAILURECODE);
				businessResponse.setResponse(ApplicationConstants.ERROROCCURED);
			}
		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
		return businessResponse;
	}
}
