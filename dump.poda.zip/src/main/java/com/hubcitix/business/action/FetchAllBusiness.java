package com.hubcitix.business.action;

import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.dao.HubCitiDao;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.helper.Helper;

public class FetchAllBusiness implements MyBusinessAction {

	@Override
	public BusinessResponse handle(BusinessLocation business, Context context) throws RuntimeException {
		BusinessResponse myBusinessResponse = null;
		try {
			HubCitiDao hubCitiDao = DAOFactory.getHubCitiDao();
			myBusinessResponse = new BusinessResponse();
			List<BusinessLocation> businessList = null;
			Helper helper = HelperFactory.getNewsHelper();
			String userId = helper.getUserUniqueId(business.getIdtoken());
			if (null != business) {

				businessList = hubCitiDao.fetchAllBusiness(userId);

			}

			if (null != businessList && !businessList.isEmpty()) {
				myBusinessResponse.setBusinessLocationList(businessList);
				myBusinessResponse.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
			} else {

				myBusinessResponse.setStatusCode(ApplicationConstants.FAILURECODE);
				myBusinessResponse.setResponse(ApplicationConstants.ERROROCCURED);
			}

		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
		return myBusinessResponse;
	}
}
