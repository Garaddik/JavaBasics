package com.hubcitix.business.action;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.dao.HubCitiDao;
import com.hubcitix.business.model.BusinessAccount;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.business.model.LatLng;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.Utility;
import com.hubcitix.common.helper.Helper;

public class SaveBusinessInfoAction implements MyBusinessAction {

	@Override
	public BusinessResponse handle(BusinessLocation location, Context context) throws RuntimeException {

		Helper helper = HelperFactory.getNewsHelper();
		String userId = helper.getUserUniqueId(location.getIdtoken());
		BusinessResponse businessResponse = null;
		String[] latlongposition = null;
		try {
			HubCitiDao hubCitiDao = DAOFactory.getHubCitiDao();

			BusinessAccount account = new BusinessAccount();

			account.setUserId(userId);
			account.setAccountName(location.getLocationName());

			location.setIdtoken(null);
			if (null != location.getAddress()) {

				StringBuffer address = new StringBuffer();

				if (null != location.getAddress().getAddressLines()) {
					address.append(location.getAddress().getAddressLines());
				}
				if (null != location.getAddress().getCity()) {
					address.append(" " + location.getAddress().getCity());
				}
				if (null != " " + location.getAddress().getState()) {
					address.append(" " + location.getAddress().getState());
				}
				if (null != location.getAddress().getPostalCode()) {
					address.append(" " + location.getAddress().getPostalCode());
				}
				latlongposition = Utility.getLatLongPositions(address.toString());

				if (null != latlongposition) {
					location.setGeo(new LatLng());
					location.getGeo().setLatitude(Double.parseDouble(latlongposition[0]));
					location.getGeo().setLongitude(Double.parseDouble(latlongposition[1]));
				}
			}

			businessResponse = hubCitiDao.saveMyBusinessInfo(location, account);

			if (null != businessResponse) {
				if (null == businessResponse.getBusinessLocation()) {
					businessResponse.setResponse(ApplicationConstants.ERROROCCURED);
					businessResponse.setStatusCode(ApplicationConstants.FAILURECODE);
				} else {

					businessResponse.setStatusCode(ApplicationConstants.BUSINESSCREATIONSUCCESSCODE);
				}
			}

		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return businessResponse;
	}
}
