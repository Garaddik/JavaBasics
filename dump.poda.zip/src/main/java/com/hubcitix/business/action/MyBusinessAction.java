package com.hubcitix.business.action;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.business.model.BusinessResponse;


public interface MyBusinessAction {

	public BusinessResponse handle(BusinessLocation request, Context context)
			throws RuntimeException;

}
