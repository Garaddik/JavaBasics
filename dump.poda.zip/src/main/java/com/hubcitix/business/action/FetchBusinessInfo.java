package com.hubcitix.business.action;

import java.io.File;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.dao.HubCitiDao;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;

public class FetchBusinessInfo implements MyBusinessAction {

	@Override
	public BusinessResponse handle(BusinessLocation business, Context context)
			throws RuntimeException {
		BusinessResponse myBusinessResponse = null;
		String accountId = null;
		String locationId = null;
		String profilePhotoPath = null;

		try {

			HubCitiDao hubCitiDao = DAOFactory.getHubCitiDao();

			myBusinessResponse = (BusinessResponse) hubCitiDao
					.fetchBusinessInfo(business);

			if (null != myBusinessResponse) {
				if (null == myBusinessResponse.getBusinessLocation()) {
					myBusinessResponse
							.setResponse(ApplicationConstants.ERROROCCURED);
					myBusinessResponse
							.setStatusCode(ApplicationConstants.FAILURECODE);
				} else {

					if (null != myBusinessResponse.getBusinessLocation()
							.getPhotos()) {

						if (null != myBusinessResponse.getBusinessLocation()
								.getPhotos().getProfilePhotoUrl()) {
							accountId = myBusinessResponse
									.getBusinessLocation().getAccountId();
							locationId = myBusinessResponse
									.getBusinessLocation().getLocationId();
							profilePhotoPath = ApplicationConstants.QAAWSS3BUCKETPATH
									+ accountId
									+ ApplicationConstants.FILESEPERATOR
									+ locationId
									+ ApplicationConstants.FILESEPERATOR
									+ ApplicationConstants.PROFILEPHOTO;
							System.out.println(profilePhotoPath);
							myBusinessResponse.getBusinessLocation()
									.getPhotos()
									.setProfilePhotoUrl(profilePhotoPath);
						}
					}
					myBusinessResponse
							.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
				}
			}

		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
		return myBusinessResponse;
	}

}
