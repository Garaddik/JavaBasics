/*
 * Copyright 2010-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.hubcitix.products.model;

import java.util.List;

public class ProductResponse {
    
    private Integer statusCode ;
    
    private Product product ;
   
    private List<Product> products ;
    
    private ProductOffer productOffer ;
    
    private List<ProductOffer> productOffers ;
    
    private List<ProductCategories> productCategories;

    /**
     * Gets statusCode
     *
     * @return statusCode
     **/


    /**
     * Gets product
     *
     * @return product
     **/
    public Product getProduct() {
        return product;
    }

    /**
     * Sets the value of product.
     *
     * @param product the new value
     */
    public void setProduct(Product product) {
        this.product = product;
    }

    /**
     * Gets products
     *
     * @return products
     **/
    public List<Product> getProducts() {
        return products;
    }

    /**
     * Sets the value of products.
     *
     * @param products the new value
     */
    public void setProducts(List<Product> products) {
        this.products = products;
    }

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public ProductOffer getProductOffer() {
		return productOffer;
	}

	public void setProductOffer(ProductOffer productOffer) {
		this.productOffer = productOffer;
	}

	public List<ProductOffer> getProductOffers() {
		return productOffers;
	}

	public void setProductOffers(List<ProductOffer> productOffers) {
		this.productOffers = productOffers;
	}

	public List<ProductCategories> getProductCategories() {
		return productCategories;
	}

	public void setProductCategories(List<ProductCategories> productCategories) {
		this.productCategories = productCategories;
	}

}
