/*
 * Copyright 2010-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.hubcitix.products.model;

import java.math.BigDecimal;
import java.util.*;
import com.hubcitix.products.model.ProductOffer;

public class ProductOfferResponse {
   
    private BigDecimal statusCode = null;
  
    private ProductOffer productOffer = null;
   
    private List<ProductOffer> productOffers = null;

    /**
     * Gets statusCode
     *
     * @return statusCode
     **/
    public BigDecimal getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the value of statusCode.
     *
     * @param statusCode the new value
     */
    public void setStatusCode(BigDecimal statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Gets productOffer
     *
     * @return productOffer
     **/
    public ProductOffer getProductOffer() {
        return productOffer;
    }

    /**
     * Sets the value of productOffer.
     *
     * @param productOffer the new value
     */
    public void setProductOffer(ProductOffer productOffer) {
        this.productOffer = productOffer;
    }

    /**
     * Gets productOffers
     *
     * @return productOffers
     **/
    public List<ProductOffer> getProductOffers() {
        return productOffers;
    }

    /**
     * Sets the value of productOffers.
     *
     * @param productOffers the new value
     */
    public void setProductOffers(List<ProductOffer> productOffers) {
        this.productOffers = productOffers;
    }

}
