package com.hubcitix.products.action;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.products.model.ProductRequest;
import com.hubcitix.products.model.ProductResponse;

public interface ProductAction {

	
	public ProductResponse handle(ProductRequest productRequest, Context context)throws RuntimeException;
}
