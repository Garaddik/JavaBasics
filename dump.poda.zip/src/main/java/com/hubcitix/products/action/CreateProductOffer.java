package com.hubcitix.products.action;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.Utility;
import com.hubcitix.common.helper.Helper;
import com.hubcitix.products.dao.ProductDao;
import com.hubcitix.products.dao.ProductDaoImpl;
import com.hubcitix.products.model.Product;
import com.hubcitix.products.model.ProductRequest;
import com.hubcitix.products.model.ProductResponse;

public class CreateProductOffer implements ProductAction {

	@Override
	public ProductResponse handle(ProductRequest productRequest, Context context)
			throws RuntimeException {
		ProductResponse productResponse = null;
		try {

			Helper helper = HelperFactory.getNewsHelper();
			String userId = helper.getUserUniqueId(productRequest.getIdtoken());
			ProductDao productDao = new ProductDaoImpl();

			productResponse = productDao.CreateProductOffer(productRequest.getProductOffer(),userId);

			if (null != productResponse) {
				if (null == productResponse.getProductOffer()) {

					productResponse
							.setStatusCode(ApplicationConstants.FAILURECODE);
				} else {

					if(null !=productResponse.getProductOffer().getAdditionalImageUrls() && !productResponse.getProductOffer().getAdditionalImageUrls().isEmpty() )
					{
					Utility.getProductimagePath(productResponse.getProductOffer().getImageType(), productResponse.getProductOffer().getAdditionalImageUrls().get(0),productResponse.getProductOffer().getOfferId(),"offer");
					}
					productResponse
							.setStatusCode(ApplicationConstants.CREATIONSUCCESSCODE);
				}
			}

		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
		return productResponse;

	}
	
	
	
	
	
	

}
