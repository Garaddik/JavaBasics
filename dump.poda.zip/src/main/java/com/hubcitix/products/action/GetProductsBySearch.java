package com.hubcitix.products.action;

import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.model.BusinessAccount;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.BusinessCloudSearch;
import com.hubcitix.common.cloudsearch.ProductCloudSearch;
import com.hubcitix.products.dao.ProductDao;
import com.hubcitix.products.dao.ProductDaoImpl;
import com.hubcitix.products.model.Product;
import com.hubcitix.products.model.ProductRequest;
import com.hubcitix.products.model.ProductResponse;

public class GetProductsBySearch implements ProductAction {

	@Override
	public ProductResponse handle(ProductRequest productRequest, Context context)
			throws RuntimeException {
		ProductResponse productResponse = new ProductResponse();
		List<Product> products = null;
		try {

			products = ProductCloudSearch.getProductSearchResult(productRequest.getTitle());
				
			if (null != products && !products.isEmpty()) {
				
					productResponse.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
					productResponse.setProducts(products);
					
				} else {
					productResponse.setStatusCode(ApplicationConstants.FAILURECODE);
					
				}
			

		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
		return productResponse;
		
		
		
	}

}
