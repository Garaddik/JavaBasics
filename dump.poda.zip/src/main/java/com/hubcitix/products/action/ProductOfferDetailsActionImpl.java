/*
 *  Copyright hubcitix.com to Present
 *  All right reserved
 */

package com.hubcitix.products.action;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.model.BusinessAccount;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.products.dao.ProductDao;
import com.hubcitix.products.model.Product;
import com.hubcitix.products.model.ProductOffer;
import com.hubcitix.products.model.ProductRequest;
import com.hubcitix.products.model.ProductResponse;

public class ProductOfferDetailsActionImpl implements ProductAction {

	@Override
	public ProductResponse handle(ProductRequest productRequest, Context context) throws RuntimeException {
		ProductResponse response = null;
		String finalOfferImage = null;
		List<String> offerImageUrls = null;

		if (null == productRequest.getOfferId()) {
			System.err.println("Invalid inputObj, could not find ProductId parameter");
			throw new BadRequestException("Insufficient Request!");
		}

		ProductDao productDAO = DAOFactory.getProductDao();

		ProductOffer productOffer = productDAO.getProductOfferDetails(productRequest.getOfferId());

		if (null != productOffer) {

			Product product = productDAO.getProductDetails(productOffer.getProductId());
			if (null != product) {
				productOffer.setBrand(product.getBrand());
				productOffer.setTitle(product.getTitle());
				BusinessAccount account = productDAO.getAccountDetails(product.getAccountId());
				if (null != account) {
					productOffer.setAccountName(account.getAccountName());
				}
			}

			if (null != productOffer.getAdditionalImageUrls() && !productOffer.getAdditionalImageUrls().isEmpty()) {
				finalOfferImage = ApplicationConstants.AWSS3IMAGEPATH + ApplicationConstants.OFFERS3BUCKETPATH + ApplicationConstants.FILESEPERATOR + productOffer.getOfferId()
						+ ApplicationConstants.FILESEPERATOR + "1";
				offerImageUrls = new ArrayList<String>();
				offerImageUrls.add(finalOfferImage);
				productOffer.setAdditionalImageUrls(offerImageUrls);

			}
		}
		response = new ProductResponse();
		response.setStatusCode(200);
		response.setProductOffer(productOffer);
		return response;
	}
}
