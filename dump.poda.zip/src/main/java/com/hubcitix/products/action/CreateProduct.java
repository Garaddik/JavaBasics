package com.hubcitix.products.action;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.Utility;
import com.hubcitix.common.helper.Helper;
import com.hubcitix.products.dao.ProductDao;
import com.hubcitix.products.dao.ProductDaoImpl;
import com.hubcitix.products.model.ProductRequest;
import com.hubcitix.products.model.ProductResponse;

public class CreateProduct implements ProductAction {

	@Override
	public ProductResponse handle(ProductRequest productRequest, Context context)
			throws RuntimeException {

		ProductResponse productResponse = null;
		
		try {

			Helper helper = HelperFactory.getNewsHelper();
			String userId = helper.getUserUniqueId(productRequest.getIdtoken());
			ProductDao productDao = new ProductDaoImpl();
				
			productResponse = productDao.CreateProduct(productRequest.getProduct(),userId);

			if (null != productResponse) {
				if (null == productResponse.getProduct()) {
					
					productResponse
							.setStatusCode(ApplicationConstants.FAILURECODE);
				} else {
					if(null != productResponse.getProduct().getImageUrl())
					{
					Utility.getProductimagePath(productResponse.getProduct().getImageType(), productResponse.getProduct().getImageUrl(),productResponse.getProduct().getProductId(),"product");
					}
					productResponse.setStatusCode(ApplicationConstants.CREATIONSUCCESSCODE);
				}
			}

		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
		return productResponse;

	}
	

}
