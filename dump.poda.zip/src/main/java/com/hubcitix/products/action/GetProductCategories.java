package com.hubcitix.products.action;

import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.products.dao.ProductDao;
import com.hubcitix.products.dao.ProductDaoImpl;
import com.hubcitix.products.model.ProductCategories;
import com.hubcitix.products.model.ProductRequest;
import com.hubcitix.products.model.ProductResponse;

public class GetProductCategories implements ProductAction{

	@Override
	public ProductResponse handle(ProductRequest productRequest, Context context)
			throws RuntimeException {
		
		List<ProductCategories> productCategories = null;
		ProductResponse productResponse = new ProductResponse();
		ProductDao productDao = new ProductDaoImpl();
		productCategories= 	productDao.GetProductCategoires();

		if (null != productCategories && !productCategories.isEmpty()) {
			productResponse
					.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
			productResponse.setProductCategories(productCategories);
		} else {

			productResponse.setStatusCode(ApplicationConstants.FAILURECODE);
		}

		return productResponse;
	
	

}
}