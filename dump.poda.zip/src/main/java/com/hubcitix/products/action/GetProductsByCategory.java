package com.hubcitix.products.action;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.products.dao.ProductDao;
import com.hubcitix.products.dao.ProductDaoImpl;
import com.hubcitix.products.model.Product;
import com.hubcitix.products.model.ProductOffer;
import com.hubcitix.products.model.ProductRequest;
import com.hubcitix.products.model.ProductResponse;

public class GetProductsByCategory implements ProductAction {

	@Override
	public ProductResponse handle(ProductRequest productRequest, Context context)
			throws RuntimeException {
		ProductResponse productResponse = new ProductResponse();
		List<Product> products = null;
		String finalProductImage = null;
		try {

			ProductDao productDao = new ProductDaoImpl();

			products = productDao.GetProductsByCategory(productRequest.getProduct());
					
			if (null != products && !products.isEmpty()) {				
				
				for (Product product : products) {
					
					if(null != product.getImageUrl())
					{
						finalProductImage=ApplicationConstants.AWSS3IMAGEPATH +ApplicationConstants.PRODUCTS3BUCKETPATH+
								ApplicationConstants.FILESEPERATOR+product.getProductId()+ApplicationConstants.FILESEPERATOR+"1";
						System.out.println(finalProductImage);
						product.setImageUrl(finalProductImage);
						
					
						
					}
					
				}			
					productResponse.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
					productResponse.setProducts(products);
					
				} else {
					productResponse.setStatusCode(ApplicationConstants.FAILURECODE);
					
				}
			

		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
		return productResponse;
	}
	

}
