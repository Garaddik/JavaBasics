package com.hubcitix.products.action;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.helper.Helper;
import com.hubcitix.products.dao.ProductDao;
import com.hubcitix.products.dao.ProductDaoImpl;
import com.hubcitix.products.model.ProductOffer;
import com.hubcitix.products.model.ProductRequest;
import com.hubcitix.products.model.ProductResponse;

public class GetProductOffers implements ProductAction {

	@Override
	public ProductResponse handle(ProductRequest productRequest, Context context)
			throws RuntimeException {
		ProductResponse productResponse = new ProductResponse();
		try {

			ProductDao productDao = new ProductDaoImpl();

			Helper helper = HelperFactory.getNewsHelper();
			String userId = helper.getUserUniqueId(productRequest.getIdtoken());	
			List<ProductOffer> offerlist = null;
			List<String> offerImageUrls = null;
			offerlist = productDao.GetProductOffers(productRequest.getProductOffer(),userId);
			String finalOfferImage = null;
			if(null != offerlist && !offerlist.isEmpty())
			{
				
			
				for (ProductOffer productOffer : offerlist) {
					
					if(null != productOffer.getAdditionalImageUrls() && !productOffer.getAdditionalImageUrls().isEmpty())
					{
						finalOfferImage=ApplicationConstants.AWSS3IMAGEPATH +ApplicationConstants.OFFERS3BUCKETPATH+
								ApplicationConstants.FILESEPERATOR+productOffer.getOfferId()+ApplicationConstants.FILESEPERATOR+"1";
						System.out.println(finalOfferImage);
						
						offerImageUrls = new ArrayList<String>();
						offerImageUrls.add(finalOfferImage);
						productOffer.setAdditionalImageUrls(offerImageUrls);
						
					}
					
				}
				
				productResponse.setProductOffers(offerlist);
				
				productResponse.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
			}else{

			

					productResponse
							.setStatusCode(ApplicationConstants.FAILURECODE);
				
			}

		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
		return productResponse;
	}

}
