package com.hubcitix.products.action;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.products.dao.ProductDao;
import com.hubcitix.products.dao.ProductDaoImpl;
import com.hubcitix.products.model.ProductRequest;
import com.hubcitix.products.model.ProductResponse;

public class DeleteProductOffer implements ProductAction {

	@Override
	public ProductResponse handle(ProductRequest productRequest, Context context) throws RuntimeException {
		ProductResponse productResponse = null;
		
		try {

			ProductDao productdao = new ProductDaoImpl();
			productResponse = productdao.deleteProductOffer(productRequest.getOfferId());

			if (null != productResponse && productResponse.getStatusCode() == 200) {
				productResponse.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
			} else {
				productResponse.setStatusCode(ApplicationConstants.FAILURECODE);
			}

		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
		return productResponse;
	}

}
