/*
 *  Copyright hubcitix.com to Present
 *  All right reserved
 */

package com.hubcitix.products.action;

import java.util.ArrayList;
import java.util.List;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.products.dao.ProductDao;
import com.hubcitix.products.model.Product;
import com.hubcitix.products.model.ProductOffer;
import com.hubcitix.products.model.ProductRequest;
import com.hubcitix.products.model.ProductResponse;

public class ProductOfferSearchActionImpl implements ProductAction {

	@Override
	public ProductResponse handle(ProductRequest productRequest, Context context) throws RuntimeException {
		ProductResponse response = null;
		List<ProductOffer> productOffers = new ArrayList<ProductOffer>();

		if (null == productRequest.getSearchKey()) {
			System.err.println("Invalid inputObj, could not find SearchKey parameter");
			throw new BadRequestException("Insufficient Request!");
		}

		ProductDao productDAO = DAOFactory.getProductDao();
		List<Product> products = productDAO.getProductList(productRequest.getSearchKey());

		if (null != products && !products.isEmpty()) {
			productOffers = productDAO.getProductOffers(products);
		}
		response = new ProductResponse();
		response.setStatusCode(200);
		response.setProductOffers(productOffers);

		return response;
	}
}
