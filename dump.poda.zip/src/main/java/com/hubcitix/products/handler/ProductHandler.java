package com.hubcitix.products.handler;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.hubcitix.common.Utility;
import com.hubcitix.products.action.CreateProduct;
import com.hubcitix.products.action.CreateProductOffer;
import com.hubcitix.products.action.DeleteProductOffer;
import com.hubcitix.products.action.GetProductCategories;
import com.hubcitix.products.action.GetProductOffers;
import com.hubcitix.products.action.GetProductsByCategory;
import com.hubcitix.products.action.GetProductsBySearch;
import com.hubcitix.products.action.ProductAction;
import com.hubcitix.products.action.ProductOfferDetailsActionImpl;
import com.hubcitix.products.action.ProductOfferSearchActionImpl;
import com.hubcitix.products.model.ProductRequest;
import com.hubcitix.products.model.ProductResponse;

/**
 * This is lambda handler class contains the all product operations. It will
 * invoke appropriate methods based on action.
 * 
 * @author shyamsundara_hm
 *
 */
public class ProductHandler implements RequestHandler<ProductRequest, ProductResponse> {

	@Override
	public ProductResponse handleRequest(ProductRequest input, Context context) {

		ProductResponse productResponse = null;
		ProductAction productAction = null;
		if (null == context) {
			Utility.STAGE = "Dev_";
		} else {
			Utility.STAGE = Utility.getCurrentStage(context.getInvokedFunctionArn());
		}
		try {
			if (input == null || input.getAction() == null || input.getAction().trim().equals("")) {

				context.getLogger().log("Invald inputObj, could not find action parameter");
				throw new BadRequestException("Could not find action value in request");
			} else {
				switch (input.getAction()) {
				case "createproduct":
					productAction = new CreateProduct();
					break;

				case "createproductoffer":
					productAction = new CreateProductOffer();
					break;
				case "getalloffers":
					productAction = new GetProductOffers();
					input.getProductOffer().setAccountId(input.getAccountId());
					input.getProductOffer().setProductId(input.getProductId());
					break;

				case "getprodcategories":
					productAction = new GetProductCategories();
					break;

				case "getprodsbycategory":
					if (null == input.getCategory()) {
						System.err.println("Invald inputObj, could not find category key parameter");
						throw new BadRequestException("Could not find category value in request");
					} else {
						input.getProduct().setCategory(input.getCategory());
						productAction = new GetProductsByCategory();
						break;
					}
				case "searchproductoffers":
					productAction = new ProductOfferSearchActionImpl();
					break;
				case "searchproduct":
					if (null == input.getTitle()) {
						System.err.println("Invald inputObj, could not find title parameter");
						throw new BadRequestException("Could not find action value in request");
					}
					productAction = new GetProductsBySearch();
					break;
				case "getproductofferdetails":
					productAction = new ProductOfferDetailsActionImpl();
					break;
				case "deleteproductoffer":
					productAction = new DeleteProductOffer();
					break;
				default:
					context.getLogger().log("Invald inputObj, could not find action parameters");

				}
			}
			productResponse = productAction.handle(input, context);

		} catch (RuntimeException exception) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			throw new RuntimeException(exception);

		}
		return productResponse;
	}
}
