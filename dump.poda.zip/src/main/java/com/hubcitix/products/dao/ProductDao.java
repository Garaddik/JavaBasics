package com.hubcitix.products.dao;

import java.util.List;

import com.hubcitix.business.model.BusinessAccount;
import com.hubcitix.products.model.Product;
import com.hubcitix.products.model.ProductCategories;
import com.hubcitix.products.model.ProductOffer;
import com.hubcitix.products.model.ProductResponse;

/**
 * This class contains methods of product operations.
 * 
 * @author shyamsundara_hm
 *
 */
public interface ProductDao {

	public ProductResponse CreateProduct(Product product, String userId) throws RuntimeException;

	public ProductResponse CreateProductOffer(ProductOffer productOffer, String userId) throws RuntimeException;

	public List<ProductOffer> GetProductOffers(ProductOffer productOffer, String userId) throws RuntimeException;

	public List<ProductCategories> GetProductCategoires() throws RuntimeException;

	public List<Product> GetProductsByCategory(Product product) throws RuntimeException;

	public List<Product> getProductList(String searchKey) throws RuntimeException;

	public ProductOffer getProductOfferDetails(String offerId) throws RuntimeException;

	public List<ProductOffer> getProductOffers(List<Product> products) throws RuntimeException;

	public ProductResponse deleteProductOffer(String offerId) throws RuntimeException;

	public Product getProductDetails(String offerId);

	public BusinessAccount getAccountDetails(String accountId);

}
