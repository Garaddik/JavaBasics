package com.hubcitix.products.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.InternalServerErrorException;
import com.hubcitix.business.model.BusinessAccount;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DBConnection;
import com.hubcitix.common.TableNames;
import com.hubcitix.common.Utility;
import com.hubcitix.products.model.Product;
import com.hubcitix.products.model.ProductCategories;
import com.hubcitix.products.model.ProductOffer;
import com.hubcitix.products.model.ProductResponse;

/**
 * This class contains the methods for product operations like create
 * product,offer and list offers,categories etc.
 * 
 * @author shyamsundara_hm
 *
 */
public class ProductDaoImpl implements ProductDao {

	private static DynamoDBMapper dynamoDBMapper;

	private static ProductDaoImpl instance = null;

	public static ProductDao getInstance() {
		if (instance == null) {
			instance = new ProductDaoImpl();
		}
		return instance;
	}

	@Override
	public ProductResponse CreateProduct(Product product, String userId) throws RuntimeException {

		ProductResponse productResponse = null;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();

			productResponse = new ProductResponse();

			Map<String, AttributeValue> eav1 = new HashMap<String, AttributeValue>();
			eav1.put(":userId", new AttributeValue().withS(userId));
			DynamoDBScanExpression queryExpression1 = new DynamoDBScanExpression().withFilterExpression("userId = :userId").withExpressionAttributeValues(eav1);
			List<BusinessAccount> accountList = dynamoDBMapper.scan(BusinessAccount.class, queryExpression1, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE
					+ TableNames.BUSINESSACCOUNT).config());

			if (null == accountList || accountList.isEmpty()) {

			} else {

				if (product.getAccountId().equalsIgnoreCase(ApplicationConstants.PRIMARY)) {
					product.setAccountId(accountList.get(0).getAccountId());
					dynamoDBMapper.save(product, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PRODUCT).config());
					productResponse.setProduct(product);

				}

			}

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}

		return productResponse;

	}

	@Override
	public ProductResponse CreateProductOffer(ProductOffer productOffer, String userId) throws RuntimeException {
		ProductResponse productResponse = null;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			List<String> locations = null;
			ProductOffer productOffer2 = null;
			List<ProductOffer> productOffers = null;
			productResponse = new ProductResponse();

			Map<String, AttributeValue> eav1 = new HashMap<String, AttributeValue>();
			eav1.put(":userId", new AttributeValue().withS(userId));
			DynamoDBScanExpression queryExpression1 = new DynamoDBScanExpression().withFilterExpression("userId = :userId").withExpressionAttributeValues(eav1);
			List<BusinessAccount> accountList = dynamoDBMapper.scan(BusinessAccount.class, queryExpression1, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE
					+ TableNames.BUSINESSACCOUNT).config());

			if (null == accountList || accountList.isEmpty()) {

			} else {

				if (productOffer.getAccountId().equalsIgnoreCase(ApplicationConstants.PRIMARY)) {
					productOffer.setAccountId(accountList.get(0).getAccountId());
					dynamoDBMapper.save(productOffer, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PRODUCTOFFER).config());

				}

			}

			locations = productOffer.getBusinessLocations();

			if (null != locations && !locations.isEmpty()) {
				for (String loc : locations) {

					BusinessLocation businessLocation = dynamoDBMapper.load(BusinessLocation.class, loc, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE
							+ TableNames.BUSINESSLOCATION).config());

					if (null != businessLocation) {
						productOffer2 = new ProductOffer();
						productOffer2.setOfferId(productOffer.getOfferId());
						if (null != businessLocation.getProductOffers() && !businessLocation.getProductOffers().isEmpty()) {
							productOffers = businessLocation.getProductOffers();
							productOffers.add(productOffer2);

						} else {
							productOffers = new ArrayList<ProductOffer>();
							productOffers.add(productOffer2);
							businessLocation.setProductOffers(productOffers);

						}

						dynamoDBMapper.save(businessLocation, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSLOCATION).config());

					}

				}

			}

			productResponse.setProductOffer(productOffer);

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}

		return productResponse;
	}

	@Override
	public List<ProductOffer> GetProductOffers(ProductOffer productOffer, String userId) throws RuntimeException {
		List<ProductOffer> productOffers = null;

		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			DynamoDBScanExpression scanExpression = null;
			HashMap<String, AttributeValue> eav = new HashMap<String, AttributeValue>();

			if (null != productOffer.getProductId() && !productOffer.getProductId().equals("")) {

				eav.put(":productId", new AttributeValue().withS(productOffer.getProductId()));

				scanExpression = new DynamoDBScanExpression().withFilterExpression("productId = :productId").withExpressionAttributeValues(eav);
				productOffers = dynamoDBMapper.scan(ProductOffer.class, scanExpression,
						new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PRODUCTOFFER).config());
				if (null != productOffers && !productOffers.isEmpty()) {

					for (ProductOffer productOffer2 : productOffers) {

						Product product = dynamoDBMapper.load(Product.class, productOffer2.getProductId(), new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE
								+ TableNames.PRODUCT).config());

						if (null != product) {
							productOffer2.setTitle(product.getTitle());
							productOffer2.setBrand(product.getBrand());
						}

						BusinessAccount businessAccount = dynamoDBMapper.load(BusinessAccount.class, userId, productOffer2.getAccountId(),
								new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSACCOUNT).config());

						if (null != businessAccount) {
							productOffer2.setAccountName(businessAccount.getAccountName());

						}

					}

					// productResponse.setProductOffers(productOffers);

				}

			} else {

				Map<String, AttributeValue> eav1 = new HashMap<String, AttributeValue>();
				eav1.put(":userId", new AttributeValue().withS(userId));
				DynamoDBScanExpression queryExpression1 = new DynamoDBScanExpression().withFilterExpression("userId = :userId").withExpressionAttributeValues(eav1);
				List<BusinessAccount> accountList = dynamoDBMapper.scan(BusinessAccount.class, queryExpression1, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE
						+ TableNames.BUSINESSACCOUNT).config());

				if (null == accountList || accountList.isEmpty()) {

				} else {

					if (productOffer.getAccountId().equalsIgnoreCase(ApplicationConstants.PRIMARY)) {

						eav.put(":accountId", new AttributeValue().withS(accountList.get(0).getAccountId()));

						scanExpression = new DynamoDBScanExpression().withFilterExpression("accountId = :accountId").withExpressionAttributeValues(eav);

						productOffers = dynamoDBMapper.scan(ProductOffer.class, scanExpression,
								new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PRODUCTOFFER).config());
						if (null != productOffers && !productOffers.isEmpty()) {

							for (ProductOffer productOffer3 : productOffers) {

								Product product = dynamoDBMapper.load(Product.class, productOffer3.getProductId(), new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE
										+ TableNames.PRODUCT).config());

								if (null != product) {
									productOffer3.setTitle(product.getTitle());
									productOffer3.setBrand(product.getBrand());
								}

								BusinessAccount businessAccount = dynamoDBMapper.load(BusinessAccount.class, userId, productOffer3.getAccountId(),
										new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSACCOUNT).config());

								if (null != businessAccount) {
									productOffer3.setAccountName(businessAccount.getAccountName());

								}

							}
							// productResponse.setProductOffers(productOffers);

						}

					}

				}

			}

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return productOffers;
	}

	@Override
	public List<ProductCategories> GetProductCategoires() throws RuntimeException {
		List<ProductCategories> productCategories = null;
		try {

			dynamoDBMapper = DBConnection.getDynamoConnection();
			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
			productCategories = dynamoDBMapper.scan(ProductCategories.class, scanExpression,
					new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PRODUCTCATEGORY).config());

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return productCategories;
	}

	@Override
	public List<Product> GetProductsByCategory(Product product) throws RuntimeException {
		List<Product> products = null;
		List<Product> finalproducts = new ArrayList<Product>();
		List<ProductOffer> productOffers = null;
		ArrayList<Double> PriceList = new ArrayList<Double>();

		Double maxSalePrice = null;
		Double minSalePrice = null;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			DynamoDBScanExpression scanExpression = null;
			HashMap<String, AttributeValue> eav = new HashMap<String, AttributeValue>();

			if (null != product.getCategory()) {

				String subCategory = product.getCategory();

				eav.put(":subCategory", new AttributeValue().withS(subCategory));

				scanExpression = new DynamoDBScanExpression().withFilterExpression("begins_with (category, :subCategory)").withExpressionAttributeValues(eav);

				products = dynamoDBMapper.scan(Product.class, scanExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PRODUCT).config());

				if (null != products && !products.isEmpty()) {
					DynamoDBScanExpression pricescanExpression = null;
					HashMap<String, AttributeValue> offeav = new HashMap<String, AttributeValue>();

					for (Product product2 : products) {

						offeav.put(":productId", new AttributeValue().withS(product2.getProductId()));

						pricescanExpression = new DynamoDBScanExpression().withFilterExpression("productId = :productId").withExpressionAttributeValues(offeav);

						productOffers = dynamoDBMapper.scan(ProductOffer.class, pricescanExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE
								+ TableNames.PRODUCTOFFER).config());

						if (null != productOffers && !productOffers.isEmpty()) {

							for (ProductOffer prodOffer : productOffers) {

								PriceList.add(prodOffer.getSalePrice());

							}
							if (product2.getProductId().equalsIgnoreCase(productOffers.get(0).getProductId())) {

								if (null != PriceList && !PriceList.isEmpty()) {
									maxSalePrice = Collections.max(PriceList);

									product2.setMaxPrice(maxSalePrice);

									minSalePrice = Collections.min(PriceList);

									product2.setMinPrice(minSalePrice);
								}

								finalproducts.add(product2);

							}

						}

					}
				}
			}

			// }

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		System.out.println(finalproducts.size());
		return finalproducts;
	}

	@Override
	public List<Product> getProductList(String searchKey) throws RuntimeException {
		List<Product> products = null;

		try {

			dynamoDBMapper = DBConnection.getDynamoConnection();
			Map<String, AttributeValue> eav1 = new HashMap<String, AttributeValue>();
			eav1.put(":title", new AttributeValue().withS(searchKey));
			DynamoDBScanExpression queryExpression = new DynamoDBScanExpression().withFilterExpression("begins_with(title,:title)").withExpressionAttributeValues(eav1);
			products = dynamoDBMapper.scan(Product.class, queryExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PRODUCT).config());

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return products;
	}

	@Override
	public ProductOffer getProductOfferDetails(String offerId) throws RuntimeException {
		ProductOffer productOffer = null;

		try {

			dynamoDBMapper = DBConnection.getDynamoConnection();
			productOffer = dynamoDBMapper.load(ProductOffer.class, offerId, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PRODUCTOFFER).config());

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return productOffer;
	}

	@Override
	public List<ProductOffer> getProductOffers(List<Product> products) throws RuntimeException {
		List<ProductOffer> productoffers = new ArrayList<ProductOffer>();

		try {

			dynamoDBMapper = DBConnection.getDynamoConnection();
			Map<String, AttributeValue> eav1 = new HashMap<String, AttributeValue>();

			for (Product product : products) {
				eav1.put(":productId", new AttributeValue().withS(product.getProductId()));

				DynamoDBScanExpression queryExpression = new DynamoDBScanExpression().withFilterExpression("productId = :productId").withExpressionAttributeValues(eav1);

				List<ProductOffer> productOffersList = dynamoDBMapper.scan(ProductOffer.class, queryExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE
						+ TableNames.PRODUCTOFFER).config());

				for (ProductOffer offer : productOffersList) {
					ProductOffer offerObj = new ProductOffer();
					offerObj.setProductId(product.getProductId());
					offerObj.setTitle(product.getTitle());
					offerObj.setOfferId(offer.getOfferId());
					offerObj.setDescription(offer.getDescription());
					productoffers.add(offerObj);
				}
			}
		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return productoffers;
	}

	/**
	 * Method to delete the product offer.
	 * 
	 * @param offerId
	 * 
	 * @throws RuntimeException
	 */

	@Override
	public ProductResponse deleteProductOffer(String offerId) throws RuntimeException {
		ProductResponse producResponse = new ProductResponse();
		BusinessLocation locationObj = new BusinessLocation();

		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();

			Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
			eav.put(":offerId", new AttributeValue().withS(offerId));

			ProductOffer offerObj = null;
			offerObj = dynamoDBMapper.load(ProductOffer.class, offerId, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PRODUCTOFFER).config());

			if (null != offerObj && null != offerObj.getBusinessLocations()) {
				for (String loctn : offerObj.getBusinessLocations()) {

					locationObj = dynamoDBMapper.load(BusinessLocation.class, loctn,
							new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSLOCATION).config());

					if (null != locationObj && null != locationObj.getProductOffers()) {
						BusinessLocation loc = new BusinessLocation();
						List<ProductOffer> ofr = new ArrayList<ProductOffer>();
						for (ProductOffer Prodoffer : locationObj.getProductOffers()) {

							if (Prodoffer.getOfferId().equals(offerId)) {

							} else {
								ofr.add(Prodoffer);
								loc.setProductOffers(ofr);
							}
						}
						locationObj.setProductOffers(loc.getProductOffers());
						dynamoDBMapper.save(locationObj, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSLOCATION).config());
					}
				}
			}

			ProductOffer offer = new ProductOffer();
			offer.setHashKey(offerId);
			dynamoDBMapper.delete(offer);

			producResponse.setStatusCode(200);

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return producResponse;
	}

	@Override
	public Product getProductDetails(String offerId) {
		Product product = null;

		try {

			dynamoDBMapper = DBConnection.getDynamoConnection();
			product = dynamoDBMapper.load(Product.class, offerId, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.PRODUCT).config());

		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return product;
	}

	@Override
	public BusinessAccount getAccountDetails(String accountId) {

		List<BusinessAccount> accountList = null;
		BusinessAccount account = null;
		Map<String, AttributeValue> eav1 = new HashMap<String, AttributeValue>();
		eav1.put(":accountId", new AttributeValue().withS(accountId));
		DynamoDBScanExpression queryExpression1 = new DynamoDBScanExpression().withFilterExpression("accountId = :accountId").withExpressionAttributeValues(eav1);
		accountList = dynamoDBMapper.scan(BusinessAccount.class, queryExpression1, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSACCOUNT).config());
		if (null != accountList && !accountList.isEmpty()) {
			account = accountList.get(0);
		}
		return account;
	}
}
