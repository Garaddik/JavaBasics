package com.hubcitix.user.handler;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.hubcitix.common.Utility;
import com.hubcitix.user.action.DisableCategoriesAction;
import com.hubcitix.user.action.GetUserPreferences;
import com.hubcitix.user.action.UserAction;
import com.hubcitix.user.model.UserPreferenceResponse;
import com.hubcitix.user.model.UserRequest;

public class UserHandler implements RequestHandler<UserRequest, UserPreferenceResponse> {

	@Override
	public UserPreferenceResponse handleRequest(UserRequest input, Context context) {
		UserPreferenceResponse userPreferenceResponse = null;
		UserAction userAction = null;
		if (null == context) {
			Utility.STAGE = "Dev_";
		} else {
			Utility.STAGE = Utility.getCurrentStage(context.getInvokedFunctionArn());
		}
		try {
			if (input == null || input.getAction() == null || input.getAction().trim().equals("")) {

				context.getLogger().log("Invald inputObj, could not find action parameter");
				throw new BadRequestException("Could not find action value in request");
			} else {

				context.getLogger().log("Input: " + input.getAction());
				switch (input.getAction()) {
				case "getuserpreferences":
					userAction = new GetUserPreferences();
					break;

				case "setusereventpreferences":
					userAction = new DisableCategoriesAction();
					break;
				default:
					context.getLogger().log("Invald inputObj, could not find action parameters");

				}
			}

			userPreferenceResponse = userAction.handle(input, context);
		} catch (RuntimeException exception) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			throw new RuntimeException(exception);

		}
		return userPreferenceResponse;
	}

}
