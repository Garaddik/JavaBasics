package com.hubcitix.user.dao;

import java.util.List;

import com.hubcitix.common.model.BusinessCategory;
import com.hubcitix.common.model.User;
import com.hubcitix.user.model.UserRequest;

public interface UserDao {

	public List<BusinessCategory> GetUserPreferences(UserRequest userRequest)
			throws RuntimeException;
	
	public User getUserPreferences(String email) throws RuntimeException;
	public boolean setUserPreferences(User user) throws RuntimeException;
}
