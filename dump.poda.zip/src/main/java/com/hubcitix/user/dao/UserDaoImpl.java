package com.hubcitix.user.dao;

import java.util.List;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMappingException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.InternalServerErrorException;
import com.hubcitix.common.DBConnection;
import com.hubcitix.common.TableNames;
import com.hubcitix.common.Utility;
import com.hubcitix.common.model.BusinessCategory;
import com.hubcitix.common.model.User;
import com.hubcitix.common.model.UserPreferences;
import com.hubcitix.user.model.UserRequest;

public class UserDaoImpl implements UserDao {

	private static DynamoDBMapper dynamoDBMapper;

	private static UserDaoImpl instance = null;

	public static UserDao getInstance() {
		if (instance == null) {
			instance = new UserDaoImpl();
		}
		return instance;
	}


	@Override
	public List<BusinessCategory> GetUserPreferences(UserRequest userRequest)
			throws RuntimeException {
		List<BusinessCategory> businessCategoryList = null;
		try {

			dynamoDBMapper = DBConnection.getDynamoConnection();

			DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
			businessCategoryList = dynamoDBMapper.scan(BusinessCategory.class,scanExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.BUSINESSCATEGORY).config());
			
		} catch (BadRequestException exception) {

			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + exception.getMessage());
			System.err.println("HTTP Status:    " + exception.getStatusCode());
			System.err.println("AWS Error Code: " + exception.getErrorCode());
			System.err.println("Error Type:     " + exception.getErrorType());
			System.err.println("Request ID:     " + exception.getRequestId());
			throw new RuntimeException(exception.getMessage());
		} catch (InternalServerErrorException except) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + except.getMessage());
			System.err.println("HTTP Status:    " + except.getStatusCode());
			System.err.println("AWS Error Code: " + except.getErrorCode());
			System.err.println("Error Type:     " + except.getErrorType());
			System.err.println("Request ID:     " + except.getRequestId());
			throw new RuntimeException(except.getMessage());
		} catch (AmazonServiceException ase) {
			System.err.println("Could not complete operation");
			System.err.println("Error Message:  " + ase.getMessage());
			System.err.println("HTTP Status:    " + ase.getStatusCode());
			System.err.println("AWS Error Code: " + ase.getErrorCode());
			System.err.println("Error Type:     " + ase.getErrorType());
			System.err.println("Request ID:     " + ase.getRequestId());
			throw new RuntimeException(ase.getMessage());
		} catch (AmazonClientException ace) {
			System.err
					.println("Internal error occured communicating with DynamoDB");
			System.out.println("Error Message:  " + ace.getMessage());
			throw new RuntimeException(ace.getMessage());
		}
		return businessCategoryList;
	}

	@Override
	public User getUserPreferences(String email) throws RuntimeException {
		User user = null;
		dynamoDBMapper = DBConnection.getDynamoConnection();
		user =dynamoDBMapper.load(User.class, email, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.USER).config());
	
		return user;
	}

	
	@Override
	public boolean setUserPreferences(User user) {

		boolean status = false;
		User userresponse ;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			userresponse =dynamoDBMapper.load(User.class, user.getEmail(), new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.USER).config());
			
			if (null != userresponse) {
				if (null == userresponse.getUserPreferences()) {
					userresponse.setUserPreferences(new UserPreferences());
				}
				userresponse.getUserPreferences().setDisabledEventCategories(
						user.getUserPreferences().getDisabledEventCategories());
					dynamoDBMapper.save(userresponse, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.USER).config());
					
				if (null != userresponse && null != userresponse.getEmail()) {
					status = true;
				}
			} else {
				dynamoDBMapper.save(user, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.USER).config());
				if (null != user && null != user.getEmail()) {
					status = true;
				}
			}
		} catch (DynamoDBMappingException e) {
			System.err.println("Error occured while setting User Preferences!");
			throw new RuntimeException(e.getMessage());
		}
		return status;
	}
}
