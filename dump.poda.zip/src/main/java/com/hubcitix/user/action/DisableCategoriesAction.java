package com.hubcitix.user.action;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.Utility;
import com.hubcitix.common.helper.Helper;
import com.hubcitix.common.model.User;
import com.hubcitix.common.model.UserPreferences;
import com.hubcitix.user.dao.UserDao;
import com.hubcitix.user.model.UserPreferenceResponse;
import com.hubcitix.user.model.UserRequest;

public class DisableCategoriesAction implements UserAction{

	@Override
	public UserPreferenceResponse handle(UserRequest request, Context context)
			throws RuntimeException {
		boolean status = false;
		UserPreferenceResponse userPreferenceResponse = null;
		try {
			userPreferenceResponse = new UserPreferenceResponse();
			UserDao userDao = DAOFactory.getUserDao();
			Helper helper = HelperFactory.getNewsHelper();
			String userId = helper.getUserUniqueId(request.getIdtoken());
			if (null == userId) {
				userPreferenceResponse.setStatusCode(404);
			}
			User user = new User();
			user.setEmail(userId);
			UserPreferences preferences = new UserPreferences();
			preferences.setDisabledEventCategories(request.getEventCategories().getDisabledCategories());
			user.setUserPreferences(preferences);
			status = userDao.setUserPreferences(user);

			if (status) {
				userPreferenceResponse.setStatusCode(200);
			} else {
				userPreferenceResponse.setStatusCode(404);
			}

		} catch (RuntimeException exception) {
			throw new RuntimeException(exception.getMessage());
		}
		return userPreferenceResponse;
	}

}
