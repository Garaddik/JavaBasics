package com.hubcitix.user.action;

import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.Utility;
import com.hubcitix.common.helper.Helper;
import com.hubcitix.common.model.BusinessCategory;
import com.hubcitix.common.model.User;
import com.hubcitix.user.dao.UserDao;
import com.hubcitix.user.model.UserPreferenceResponse;
import com.hubcitix.user.model.UserRequest;

public class GetUserPreferences implements UserAction {

	@Override
	public UserPreferenceResponse handle(UserRequest request, Context context)
			throws RuntimeException {
		List<BusinessCategory> userPreferenceList = null;
		UserPreferenceResponse userPreferenceResponse = new UserPreferenceResponse();
		UserDao userDao = DAOFactory.getUserDao();
		userPreferenceList = userDao.GetUserPreferences(request);
		
		
		Helper helper = HelperFactory.getNewsHelper();
		String userId = helper.getUserUniqueId(request.getIdtoken());
		User user = userDao.getUserPreferences(userId);
		if (null != user
				&& null != user.getUserPreferences()
				&& null != user.getUserPreferences()
						.getDisabledEventCategories()
				&& !user.getUserPreferences().getDisabledEventCategories()
						.isEmpty())
			for (BusinessCategory category : userPreferenceList) {
				for (String disCategory : user.getUserPreferences().getDisabledEventCategories())
					if (disCategory.equalsIgnoreCase(category.getCategory()))
					{
						System.out.println("inside if");
						System.out.println(disCategory);
						System.out.println(category.getCategory());						
						category.setInterested(false);
					}/*else{
						System.out.println("inside else");
						category.setInterested(true);
					}*/
			}/*else{
				for (BusinessCategory category : userPreferenceList) {
					
					category.setInterested(true);
				}*/
				
				
		//	}

		if (null != userPreferenceList && !userPreferenceList.isEmpty()) {

			userPreferenceResponse
					.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
			userPreferenceResponse.setUserPreferenceList(userPreferenceList);
		} else {

			userPreferenceResponse
					.setStatusCode(ApplicationConstants.FAILURECODE);
		}

		return userPreferenceResponse;
	}

}
