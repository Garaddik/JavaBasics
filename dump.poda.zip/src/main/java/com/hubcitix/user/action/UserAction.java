package com.hubcitix.user.action;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.business.model.PublicEvent;
import com.hubcitix.user.model.UserPreferenceResponse;
import com.hubcitix.user.model.UserRequest;

public interface UserAction {
	
	public UserPreferenceResponse handle(UserRequest request, Context context)
			throws RuntimeException;

}
