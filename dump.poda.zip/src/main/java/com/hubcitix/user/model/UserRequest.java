package com.hubcitix.user.model;

public class UserRequest {
	
	private String action;

	private String idtoken;
	
	private EventCategories eventCategories;
	
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getIdtoken() {
		return idtoken;
	}

	public void setIdtoken(String idtoken) {
		this.idtoken = idtoken;
	}

	public EventCategories getEventCategories() {
		return eventCategories;
	}

	public void setEventCategories(EventCategories eventCategories) {
		this.eventCategories = eventCategories;
	}

}
