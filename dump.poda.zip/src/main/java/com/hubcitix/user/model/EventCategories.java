package com.hubcitix.user.model;

import java.util.List;

public class EventCategories {

	private List<String> disabledCategories;


	public List<String> getDisabledCategories() {
		return disabledCategories;
	}

	public void setDisabledCategories(List<String> disabledCategories) {
		this.disabledCategories = disabledCategories;
	}
}
