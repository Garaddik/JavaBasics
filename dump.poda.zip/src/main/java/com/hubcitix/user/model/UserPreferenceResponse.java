package com.hubcitix.user.model;

import java.util.List;

import com.hubcitix.common.model.BusinessCategory;

public class UserPreferenceResponse {

	private Integer statusCode;
	private List<BusinessCategory> userPreferenceList = null;

	public List<BusinessCategory> getUserPreferenceList() {
		return userPreferenceList;
	}

	public void setUserPreferenceList(List<BusinessCategory> userPreferenceList) {
		this.userPreferenceList = userPreferenceList;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

}
