package com.hubcitix.news.action;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.jdom2.Element;

import com.hubcitix.common.Utility;
import com.hubcitix.news.model.NewsCategory;
import com.hubcitix.news.model.NewsItem;
import com.hubcitix.news.model.NewsMedia;
import com.rometools.fetcher.FeedFetcher;
import com.rometools.fetcher.FetcherException;
import com.rometools.fetcher.impl.FeedFetcherCache;
import com.rometools.fetcher.impl.HashMapFeedInfoCache;
import com.rometools.fetcher.impl.HttpURLFeedFetcher;
import com.rometools.rome.feed.synd.SyndContent;
import com.rometools.rome.feed.synd.SyndEnclosure;
import com.rometools.rome.feed.synd.SyndEntry;
import com.rometools.rome.feed.synd.SyndFeed;
import com.rometools.rome.io.FeedException;

public class NewsRssParserimpl implements NewsRssParser {

	private NewsCategory category = null;
	private List<NewsItem> batchitemList = null;

	public NewsRssParserimpl(NewsCategory category, List<NewsItem> batchitemList) {

		this.category = category;
		this.batchitemList = batchitemList;
	}

	@Override
	public void run() {

		List<NewsItem> itemList = new ArrayList<NewsItem>();
		SyndFeed feed = null;

		try {

			FeedFetcherCache feedInfoCache = HashMapFeedInfoCache.getInstance();
			FeedFetcher feedFetcher = new HttpURLFeedFetcher(feedInfoCache);
			feed = feedFetcher.retrieveFeed(new URL(category.getLink().trim()));

			for (Object entryObject : feed.getEntries()) {
				List<NewsMedia> mediaList = new ArrayList<NewsMedia>();
				NewsItem item = new NewsItem();
				SyndEntry entry = (SyndEntry) entryObject;
				item.setCategory(this.category.getCategory());
				item.setTitle(entry.getTitle());
				item.setLink(entry.getLink());
				item.setAuthor(entry.getAuthor());
				item.setPubDate(Utility.convertDateTOUTC(entry.getPublishedDate()));
				item.setDescription(entry.getDescription().getValue());
				item.setGuid(entry.getLink());

				if (null != entry.getContents() && !entry.getContents().isEmpty()) {
					for (SyndContent content : entry.getContents()) {
						NewsMedia media = new NewsMedia();
						media.setType("text");
						media.setText(content.getValue());
						mediaList.add(media);
					}
				}
				for (SyndEnclosure closure : entry.getEnclosures()) {
					NewsMedia media = new NewsMedia();
					if (null != closure.getUrl()) {
						media.setType("image");
						media.setUrl(closure.getUrl());
						mediaList.add(media);
					}
				}

				if (null != entry.getForeignMarkup() && !entry.getForeignMarkup().isEmpty()) {
					for (Element element : entry.getForeignMarkup()) {
						boolean imageNotExist = true;
						NewsMedia media = new NewsMedia();
						switch (element.getName().toLowerCase()) {
						case "text":
							media.setType("text");
							media.setText(element.getValue());
							mediaList.add(media);
							break;
						case "thumbnail":
							if (imageNotExist) {
								item.setImageUrl(element.getAttributeValue("url"));
								imageNotExist = false;
							}
							/*
							 * media.setType("image"); if (null !=
							 * element.getAttributeValue("height"))
							 * media.setHeight
							 * (Integer.parseInt(element.getAttributeValue
							 * ("height"))); if (null !=
							 * element.getAttributeValue("width"))
							 * media.setWidth
							 * (Integer.parseInt(element.getAttributeValue
							 * ("width")));
							 * media.setUrl(element.getAttributeValue("url"));
							 * mediaList.add(media);
							 */
							break;
						case "content":
							if (null != element.getAttributeValue("url")) {
								if (imageNotExist) {
									item.setImageUrl(element.getAttributeValue("url"));
									imageNotExist = false;
								}
								media.setType("image");
								if (null != element.getAttributeValue("height") && !element.getAttributeValue("height").isEmpty())
									media.setHeight(Integer.parseInt(element.getAttributeValue("height")));
								if (null != element.getAttributeValue("width") && !element.getAttributeValue("width").isEmpty())
									media.setWidth(Integer.parseInt(element.getAttributeValue("width")));
								media.setUrl(element.getAttributeValue("url"));
								mediaList.add(media);
							}
							break;
						default:
							break;
						}
					}
					if (!mediaList.isEmpty())
						item.setMedia(mediaList);
				}
				itemList.add(item);
			}
			synchronized (this.batchitemList) {
				System.out.println(category.getCategory() + "\t  count: " + itemList.size());
				this.batchitemList.addAll(itemList);
			}

		} catch (FetcherException e) {
			System.err.println("Empty URL" + "\t" + category.getCategory() + "\t" + this.category.getLink() + e.getMessage());
		} catch (IllegalArgumentException | IOException | FeedException e) {
			System.err.println("Error Occurred while Parsing Feeds" + "\t" + category.getCategory() + "\t" + this.category.getLink() + "\t" + e.getMessage());
		}
		System.out.println(Thread.currentThread().getName() + " (End)");
	}

	public static void main(String[] args) {

		List<NewsItem> itemList = new ArrayList<NewsItem>();
		SyndFeed feed = null;

		try {

			FeedFetcherCache feedInfoCache = HashMapFeedInfoCache.getInstance();
			FeedFetcher feedFetcher = new HttpURLFeedFetcher(feedInfoCache);
			feed = feedFetcher.retrieveFeed(new URL("http://www.tylerpaper.com/rss/custom/type/health/hours/192"));

			for (Object entryObject : feed.getEntries()) {
				List<NewsMedia> mediaList = new ArrayList<NewsMedia>();
				NewsItem item = new NewsItem();
				SyndEntry entry = (SyndEntry) entryObject;
				item.setCategory("");
				System.out.println(entry.getTitle());
				item.setTitle(entry.getTitle());
				item.setLink(entry.getLink());
				item.setAuthor(entry.getAuthor());
				item.setPubDate(Utility.convertDateTOUTC(entry.getPublishedDate()));
				item.setDescription(entry.getDescription().getValue());
				item.setGuid(entry.getLink());

				if (null != entry.getContents() && !entry.getContents().isEmpty()) {
					for (SyndContent content : entry.getContents()) {
						NewsMedia media = new NewsMedia();
						media.setType("text");
						media.setText(content.getValue());
						mediaList.add(media);
					}
				}
				for (SyndEnclosure closure : entry.getEnclosures()) {
					NewsMedia media = new NewsMedia();
					if (null != closure.getUrl()) {
						media.setType("image");
						media.setUrl(closure.getUrl());
						mediaList.add(media);
					}
				}

				if (null != entry.getForeignMarkup() && !entry.getForeignMarkup().isEmpty()) {
					for (Element element : entry.getForeignMarkup()) {
						boolean imageNotExist = true;
						NewsMedia media = new NewsMedia();
						switch (element.getName().toLowerCase()) {
						case "text":
							media.setType("text");
							media.setText(element.getValue());
							mediaList.add(media);
							break;
						case "thumbnail":
							if (imageNotExist) {
								item.setImageUrl(element.getAttributeValue("url"));
								imageNotExist = false;
							}
							break;
						case "content":
							if (null != element.getAttributeValue("url") && !element.getAttributeValue("url").isEmpty()) {
								if (imageNotExist) {
									item.setImageUrl(element.getAttributeValue("url"));
									imageNotExist = false;
								}
								media.setType("image");
								if (null != element.getAttributeValue("height") && !element.getAttributeValue("height").isEmpty())
									media.setHeight(Integer.parseInt(element.getAttributeValue("height")));
								if (null != element.getAttributeValue("width") && !element.getAttributeValue("width").isEmpty())
									media.setWidth(Integer.parseInt(element.getAttributeValue("width")));
								media.setUrl(element.getAttributeValue("url"));
								mediaList.add(media);
							}
							break;
						default:
							break;
						}
					}
					if (!mediaList.isEmpty())
						item.setMedia(mediaList);
				}
				itemList.add(item);
				System.out.println(entry.getTitle());
			}

		} catch (FetcherException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException | IOException | FeedException e) {
			e.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName() + " (End)");

	}
}
