package com.hubcitix.news.action;

import com.amazonaws.services.lambda.runtime.Context;

public interface BatchProcess {

	/**
	 * RSS Feed process
	 * 
	 * @param context
	 * @return
	 * @throws RuntimeException
	 */
	String handler(Context context) throws RuntimeException;

}
