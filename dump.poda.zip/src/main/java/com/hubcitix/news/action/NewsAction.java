package com.hubcitix.news.action;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.news.model.NewsRequest;
import com.hubcitix.news.model.NewsResponse;

public interface NewsAction {
	public NewsResponse handle(NewsRequest input, Context context) throws RuntimeException;
}
