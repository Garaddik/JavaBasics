package com.hubcitix.news.action;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.helper.Helper;
import com.hubcitix.common.model.User;
import com.hubcitix.common.model.UserPreferences;
import com.hubcitix.news.dao.NewsDao;
import com.hubcitix.news.model.NewsRequest;
import com.hubcitix.news.model.NewsResponse;

public class UserPreferencesAction implements NewsAction {

	@Override
	public NewsResponse handle(NewsRequest input, Context context) throws RuntimeException {

		boolean status = false;
		NewsResponse response = null;
		try {
			response = new NewsResponse();
			NewsDao dao = DAOFactory.getNewsDao();
			Helper helper = HelperFactory.getNewsHelper();
			String userId = helper.getUserUniqueId(input.getIdtoken());
			if (null == userId) {
				response.setStatusCode(404);
			}
			User user = new User();
			user.setEmail(userId);
			UserPreferences preferences = new UserPreferences();
			preferences.setDisabledNewsCategories(input.getCategoryRequest().getDisabledCategories());
			user.setUserPreferences(preferences);
			status = dao.setUserPreferences(user);

			if (status) {
				response.setStatusCode(200);
			} else {
				response.setStatusCode(404);
			}

		} catch (RuntimeException exception) {
			throw new RuntimeException(exception.getMessage());
		}
		return response;
	}
}
