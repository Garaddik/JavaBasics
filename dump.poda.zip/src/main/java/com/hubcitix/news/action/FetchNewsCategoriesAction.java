package com.hubcitix.news.action;

import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.helper.Helper;
import com.hubcitix.common.model.User;
import com.hubcitix.news.dao.NewsDao;
import com.hubcitix.news.model.NewsCategory;
import com.hubcitix.news.model.NewsRequest;
import com.hubcitix.news.model.NewsResponse;

public class FetchNewsCategoriesAction implements NewsAction {

	@Override
	public NewsResponse handle(NewsRequest input, Context context) throws RuntimeException {

		List<NewsCategory> newsCategories = null;
		NewsResponse response = null;
		try {

			NewsDao dao = DAOFactory.getNewsDao();
			newsCategories = dao.getCategories();
			Helper helper = HelperFactory.getNewsHelper();
			String userId = helper.getUserUniqueId(input.getIdtoken());
			User user = dao.getUserPreferences(userId);
			if (null != user && null != user.getUserPreferences() && null != user.getUserPreferences().getDisabledNewsCategories()
					&& !user.getUserPreferences().getDisabledNewsCategories().isEmpty())
				for (NewsCategory category : newsCategories) {
					for (String disCategory : user.getUserPreferences().getDisabledNewsCategories())
						if (disCategory.equalsIgnoreCase(category.getCategory()))
							category.setInterested(false);
				}
			response = new NewsResponse();
			response.setStatusCode(200);
			response.setNewsCategories(newsCategories);

		} catch (RuntimeException exception) {
			throw new RuntimeException(exception.getMessage());
		}
		return response;

	}
}
