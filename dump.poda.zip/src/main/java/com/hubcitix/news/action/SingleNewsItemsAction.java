package com.hubcitix.news.action;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.news.dao.NewsDao;
import com.hubcitix.news.model.NewsItem;
import com.hubcitix.news.model.NewsRequest;
import com.hubcitix.news.model.NewsResponse;

public class SingleNewsItemsAction implements NewsAction {

	@Override
	public NewsResponse handle(NewsRequest input, Context context) throws RuntimeException {
		System.out.println(ApplicationConstants.METHODSTART + "Get News Article:Action");
		NewsItem item = null;
		NewsResponse response = null;
		try {
			System.out.println("Category name: " + input.getCategory());
			System.out.println("Before DecodeItemId: " + input.getItemId());
			input.setItemId(URLDecoder.decode(input.getItemId(), "UTF-8"));
			System.out.println("After Decoding ItemId: " + input.getItemId());
			NewsDao dao = DAOFactory.getNewsDao();
			item = dao.getsignleItem(input.getCategory(), input.getItemId());
			response = new NewsResponse();
			if (null != item) {
				response.setStatusCode(200);
				response.setNewsItem(item);
			} else {
				response.setStatusCode(204);
			}

		} catch (UnsupportedEncodingException exception) {
			System.err.println(exception.getMessage());
			throw new RuntimeException(exception.getMessage());
		} catch (RuntimeException exception) {
			System.err.println(exception.getMessage());
			throw new RuntimeException(exception.getMessage());
		}
		System.out.println(ApplicationConstants.METHODEND + "Get News Article:Action");
		return response;
	}
}
