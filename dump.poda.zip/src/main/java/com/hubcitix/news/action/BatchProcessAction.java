package com.hubcitix.news.action;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.news.dao.NewsDao;
import com.hubcitix.news.model.NewsCategory;
import com.hubcitix.news.model.NewsItem;

/**
 * RSS Feed processor
 * 
 * @author kirankumar.garaddi
 *
 */
public class BatchProcessAction implements BatchProcess {

	/*
	 * RSS Feed processor
	 * 
	 * @see
	 * com.hubcitix.news.action.BatchProcess#handler(com.amazonaws.services.
	 * lambda.runtime.Context)
	 */
	@Override
	public String handler(Context context) throws RuntimeException {

		List<NewsCategory> newsCategories = null;
		String response = "FAILURE";
		List<NewsItem> batchitemList = new ArrayList<NewsItem>();
		boolean status = false;
		try {

			NewsDao dao = DAOFactory.getNewsDao();
			// Fetch All categories from Database
			newsCategories = dao.getCategories();

			if (null != newsCategories && !newsCategories.isEmpty()) {
				ExecutorService executor = Executors.newFixedThreadPool(5);
				// Create a threads to Invoke Parser to Parse RSS Feeds
				for (int i = 0; i < newsCategories.size(); i++) {
					Runnable thread = new NewsRssParserimpl(newsCategories.get(i), batchitemList);
					executor.execute(thread);
				}

				/**
				 * 
				 * Wait for all URL thread to complete parsing process
				 * 
				 */
				executor.shutdown();
				while (!executor.isTerminated()) {
				}
				// Store new items in database
				if (null != batchitemList && !batchitemList.isEmpty())
					status = dao.insertbatchCategoryImtes(batchitemList);
			}
			if (status) {
				response = "SUCCESS";
			}
		} catch (RuntimeException exception) {
			throw new RuntimeException(exception.getMessage());
		}
		return response;
	}
}
