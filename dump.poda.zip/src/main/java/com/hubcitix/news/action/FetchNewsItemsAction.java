package com.hubcitix.news.action;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.news.dao.NewsDao;
import com.hubcitix.news.model.NewsItem;
import com.hubcitix.news.model.NewsRequest;
import com.hubcitix.news.model.NewsResponse;

public class FetchNewsItemsAction implements NewsAction {

	@Override
	public NewsResponse handle(NewsRequest input, Context context) throws RuntimeException {

		List<NewsItem> newsItems = null;
		NewsResponse response = null;
		try {

			NewsDao dao = DAOFactory.getNewsDao();
			newsItems = dao.getNewsItems(input.getCategory());
			if (null != newsItems) {
				newsItems = new ArrayList<NewsItem>(newsItems);
				Collections.sort(newsItems);
			}
			response = new NewsResponse();
			if (null != newsItems) {
				response.setStatusCode(200);
				response.setNewsItems(newsItems);
			} else {
				response.setStatusCode(200);
			}

		} catch (RuntimeException exception) {
			throw new RuntimeException(exception.getMessage());
		}
		return response;
	}

}
