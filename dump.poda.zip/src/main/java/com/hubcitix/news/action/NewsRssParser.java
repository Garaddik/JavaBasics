package com.hubcitix.news.action;

public interface NewsRssParser extends Runnable {

}
