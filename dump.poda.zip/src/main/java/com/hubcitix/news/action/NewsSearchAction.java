package com.hubcitix.news.action;

import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.cloudsearch.NewsCloudSearch;
import com.hubcitix.news.model.NewsItem;
import com.hubcitix.news.model.NewsRequest;
import com.hubcitix.news.model.NewsResponse;

public class NewsSearchAction implements NewsAction {

	@Override
	public NewsResponse handle(NewsRequest input, Context context)
			throws RuntimeException {
		NewsResponse newsResponse = new NewsResponse();
		List<NewsItem> newsItems = null;
		try {

			newsItems = NewsCloudSearch.getNewsSearchResult(input.getSearchKey());
				
			if (null != newsItems && !newsItems.isEmpty()) {
				
				newsResponse.setStatusCode(ApplicationConstants.SUCCESSSTATUSCODE);
				newsResponse.setNewsItems(newsItems);
					
				} else {
					newsResponse.setStatusCode(ApplicationConstants.FAILURECODE);
					
				}
			

		} catch (RuntimeException e) {
			throw new RuntimeException(e);
		}
		return newsResponse;
	}
	

}
