package com.hubcitix.news.model;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "NewsItem")
public class NewsItem implements Comparable<NewsItem> {

	@DynamoDBHashKey(attributeName = "category")
	private String category;
	@DynamoDBRangeKey(attributeName = "guid")
	private String guid;
	private String title;
	private String link;
	private String pubDate;
	private String author;
	private String description;
	private List<NewsMedia> media;
	private String thumbnail;
	private String imageUrl;

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getPubDate() {
		return pubDate;
	}

	public void setPubDate(String pubDate) {
		this.pubDate = pubDate;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<NewsMedia> getMedia() {
		return media;
	}

	public void setMedia(List<NewsMedia> media) {
		this.media = media;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	@Override
	public int compareTo(NewsItem newsItem) {
		try {
			return newsItem.getPubDate().compareTo(getPubDate());
		} catch (Exception e) {
			return -1;
		}
	}
}
