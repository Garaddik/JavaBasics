package com.hubcitix.news.model;

import java.util.List;

public class CategoryRequest {

	private List<String> disabledCategories;

	public List<String> getDisabledCategories() {
		return disabledCategories;
	}

	public void setDisabledCategories(List<String> disabledCategories) {
		this.disabledCategories = disabledCategories;
	}
}
