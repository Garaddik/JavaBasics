package com.hubcitix.news.model;

import java.util.List;

public class NewsResponse {

	private int statusCode;

	private List<NewsCategory> newsCategories;

	private List<NewsItem> newsItems;

	private NewsItem newsItem;

	public NewsItem getNewsItem() {
		return newsItem;
	}

	public void setNewsItem(NewsItem newsItem) {
		this.newsItem = newsItem;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public List<NewsCategory> getNewsCategories() {
		return newsCategories;
	}

	public void setNewsCategories(List<NewsCategory> newsCategories) {
		this.newsCategories = newsCategories;
	}

	public List<NewsItem> getNewsItems() {
		return newsItems;
	}

	public void setNewsItems(List<NewsItem> newsItems) {
		this.newsItems = newsItems;
	}

}
