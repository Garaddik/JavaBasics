package com.hubcitix.news.model;

public class NewsRequest {

	private String action;

	private String idtoken;

	private String category;

	private String itemId;
	
	private String searchKey;

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	private CategoryRequest categoryRequest;

	public CategoryRequest getCategoryRequest() {
		return categoryRequest;
	}

	public void setCategoryRequest(CategoryRequest categoryRequest) {
		this.categoryRequest = categoryRequest;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getIdtoken() {
		return idtoken;
	}

	public void setIdtoken(String idtoken) {
		this.idtoken = idtoken;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getSearchKey() {
		return searchKey;
	}

	public void setSearchKey(String searchKey) {
		this.searchKey = searchKey;
	}
}
