package com.hubcitix.news.handler;

import com.amazonaws.services.apigateway.model.BadRequestException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.hubcitix.common.Utility;
import com.hubcitix.business.eventaction.SearchBusinessAction;
import com.hubcitix.news.action.FetchNewsCategoriesAction;
import com.hubcitix.news.action.FetchNewsItemsAction;
import com.hubcitix.news.action.NewsAction;
import com.hubcitix.news.action.NewsSearchAction;
import com.hubcitix.news.action.SingleNewsItemsAction;
import com.hubcitix.news.action.UserPreferencesAction;
import com.hubcitix.news.model.NewsRequest;
import com.hubcitix.news.model.NewsResponse;

public class NewsHandler implements RequestHandler<NewsRequest, NewsResponse> {
	/**
	 * This method is used to get calendar events...
	 */
	@Override
	public NewsResponse handleRequest(NewsRequest input, Context context) {

		NewsAction action = null;
		NewsResponse newsResponse = null;
		if (null == context) {
			Utility.STAGE = "Dev_";
		} else {
			Utility.STAGE = Utility.getCurrentStage(context.getInvokedFunctionArn());
		}
		try {
			if (input == null || input.getAction() == null || input.getAction().trim().equals("") ) {
				System.err.println("Invald inputObj, could not find action parameter");
				throw new BadRequestException("Could not find action value in request");
			} else {
				System.err.println("Input: " + input.getAction());
				switch (input.getAction()) {

				case "fetchcategories":
					action = new FetchNewsCategoriesAction();
					break;
				case "fetchitems":
					if (null == input.getCategory()) {
						System.err.println("Invald inputObj, could not find category parameter");
						throw new BadRequestException("Could not find action value in request");
					}
					action = new FetchNewsItemsAction();
					break;
				case "swingleitem":
					if (null == input.getCategory() || null == input.getItemId()) {
						System.err.println("Invald inputObj, could not find category parameter");
						throw new BadRequestException("Could not find action value in request");
					}
					action = new SingleNewsItemsAction();
					break;
				
				case "newssearch":				
					if (null == input.getSearchKey()) {
						System.err.println("Invald inputObj, could not find  search key parameter in the request.");
						throw new BadRequestException("Could not find search key in request");
					}					
					action = new NewsSearchAction();
					break;
				case "setpreferences":
					if (null == input.getCategoryRequest() && null == input.getCategoryRequest().getDisabledCategories()) {
						System.err.println("Invald inputObj, could not find category parameter");
						throw new BadRequestException("Could not find action value in request");
					}
					action = new UserPreferencesAction();
					break;
					
				
					
				default:
					System.err.println("Invald inputObj, could not find action parameters");
				}
			}
			newsResponse = action.handle(input, context);
		} catch (RuntimeException exception) {
			context.getLogger().log("Error occurred while Consuming News APIs!" + exception.getMessage());
			throw new RuntimeException(exception);
		}
		return newsResponse;
	}
}
