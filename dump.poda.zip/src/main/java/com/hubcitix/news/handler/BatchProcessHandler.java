package com.hubcitix.news.handler;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.hubcitix.common.Utility;
import com.hubcitix.news.action.BatchProcess;
import com.hubcitix.news.action.BatchProcessAction;

/**
 * 
 * @author kirankumar.garaddi
 * @Date: April 4th 2017 Batch Process Implementation.
 * 
 */
public class BatchProcessHandler implements RequestHandler<Object, String> {

	@Override
	public String handleRequest(Object input, Context context) {
		System.out.println("called batch process!");
		if (null == context) {
			Utility.STAGE = "Dev_";
		} else {
			Utility.STAGE = Utility.getCurrentStage(context.getInvokedFunctionArn());
		}
		BatchProcess action = null;
		String response = null;
		try {
			action = new BatchProcessAction();
			// Parser RSS Feed based on master categories.
			response = action.handler(context);
		} catch (RuntimeException exception) {
			context.getLogger().log("Unable to import!");
			throw new RuntimeException(exception);
		}
		return response;
	}
}
