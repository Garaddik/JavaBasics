package com.hubcitix.news.dao;

import java.util.List;

import com.hubcitix.common.model.User;
import com.hubcitix.news.model.NewsCategory;
import com.hubcitix.news.model.NewsItem;

public interface NewsDao {

	List<NewsCategory> getCategories() throws RuntimeException;

	List<NewsItem> getNewsItems(String category) throws RuntimeException;

	boolean setUserPreferences(User user) throws RuntimeException;

	User getUserPreferences(String email) throws RuntimeException;

	/**
	 * Called Insertion method to store all articles into database using Batch
	 * Insert
	 * 
	 * @param batchitemList
	 * @return failure or success message status
	 * @throws RuntimeException
	 */
	boolean insertbatchCategoryImtes(List<NewsItem> batchitemList) throws RuntimeException;

	NewsItem getsignleItem(String category, String itemId) throws RuntimeException;

}
