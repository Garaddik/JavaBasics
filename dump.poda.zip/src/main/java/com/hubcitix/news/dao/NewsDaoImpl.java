package com.hubcitix.news.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper.FailedBatch;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMappingException;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.hubcitix.common.ApplicationConstants;
import com.hubcitix.common.DBConnection;
import com.hubcitix.common.TableNames;
import com.hubcitix.common.Utility;
import com.hubcitix.common.model.User;
import com.hubcitix.common.model.UserPreferences;
import com.hubcitix.news.model.NewsCategory;
import com.hubcitix.news.model.NewsItem;

public class NewsDaoImpl implements NewsDao {

	private static DynamoDBMapper dynamoDBMapper;

	private static NewsDaoImpl instance = null;
	

	public static NewsDao getInstance() {
		if (instance == null) {
			instance = new NewsDaoImpl();
		}
		return instance;
	}

	@Override
	public List<NewsCategory> getCategories() throws RuntimeException {

		List<NewsCategory> categories = null;

		dynamoDBMapper = DBConnection.getDynamoConnection();
		DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
		categories = dynamoDBMapper.scan(NewsCategory.class, scanExpression,
					new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.NEWSCATEGORY).config());
		
		return categories;
	}

	@Override
	public List<NewsItem> getNewsItems(String category) throws RuntimeException {
		List<NewsItem> items = null;

		dynamoDBMapper = DBConnection.getDynamoConnection();
		Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
		eav.put(":category", new AttributeValue().withS(category));

		DynamoDBQueryExpression<NewsItem> queryExpression = new DynamoDBQueryExpression<NewsItem>().withConsistentRead(false).withKeyConditionExpression("category = :category ")
				.withExpressionAttributeValues(eav);
		items = dynamoDBMapper.query(NewsItem.class, queryExpression, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE+ TableNames.NEWSITEM).config());
		
		return items;
	}

	@Override
	public boolean setUserPreferences(User user) {

		boolean status = false;
		try {
			dynamoDBMapper = DBConnection.getDynamoConnection();
			User userresponse = dynamoDBMapper.load(User.class, user.getEmail(),new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE+ TableNames.USER).config() );
			if (null != userresponse) {
				if (null == userresponse.getUserPreferences()) {
					userresponse.setUserPreferences(new UserPreferences());
				}
				userresponse.getUserPreferences().setDisabledNewsCategories(user.getUserPreferences().getDisabledNewsCategories());
				dynamoDBMapper.save(userresponse, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.USER).config());
				
				if (null != userresponse && null != userresponse.getEmail()) {
					status = true;
				}
			} else {
				dynamoDBMapper.save(user, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.USER).config());
				
				if (null != user && null != user.getEmail()) {
					status = true;
				}
			}
		} catch (DynamoDBMappingException e) {
			System.err.println("Error occured while setting User Preferences!");
			throw new RuntimeException(e.getMessage());
		}
		return status;
	}

	@Override
	public User getUserPreferences(String email) throws RuntimeException {
		User user = null;

		dynamoDBMapper = DBConnection.getDynamoConnection();
		user = dynamoDBMapper.load(User.class, email, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.USER).config());
		
		return user;
	}

	/**
	 * Called Insertion method to store all articles into database using Batch
	 * Insert
	 * 
	 * @param batchitemList
	 * @return failure or success message status
	 * @throws RuntimeException
	 */
	@Override
	public boolean insertbatchCategoryImtes(List<NewsItem> batchitemList) throws RuntimeException {

		System.out.println("Articles Counts : " + batchitemList.size());

		boolean status = false;
		List<FailedBatch> faileditems = null;
		dynamoDBMapper = DBConnection.getDynamoConnection();

		faileditems = dynamoDBMapper.batchWrite(batchitemList, new ArrayList<NewsItem>(),
					new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.NEWSITEM).config());

		if (null != faileditems && !faileditems.isEmpty()) {
			for (FailedBatch failed : faileditems) {
				System.err.println(failed.getException().getMessage());
			}
		} else {
			status = true;
		}
		return status;
	}

	/**
	 * Called Insertion method to store all articles into database using Batch
	 * Insert
	 * 
	 * @param batchitemList
	 * @return failure or success message status
	 * @throws RuntimeException
	 */
	@Override
	public NewsItem getsignleItem(String category, String itemId) throws RuntimeException {
		System.out.println(ApplicationConstants.METHODSTART + "Get News Article:DAO");
		NewsItem item = null;
		dynamoDBMapper = DBConnection.getDynamoConnection();
		item = dynamoDBMapper.load(NewsItem.class, category, itemId, new DynamoDBMapperConfig.TableNameOverride(Utility.STAGE + TableNames.NEWSITEM).config());
		System.out.println(ApplicationConstants.METHODSTART + "Get News Article:DAO");
		return item;
	}
}
