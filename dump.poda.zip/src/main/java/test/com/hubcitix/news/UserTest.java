package test.com.hubcitix.news;

import com.hubcitix.user.action.GetUserPreferences;
import com.hubcitix.user.action.UserAction;
import com.hubcitix.user.model.UserRequest;

public class UserTest {
	public static void main(String a[])
	{
		UserAction u = new GetUserPreferences();
		UserRequest ur = new UserRequest();
		ur.setIdtoken("eyJhbGciOiJSUzI1NiIsImtpZCI6IjAyNDhiOTE4MDQ0ZjU0NDVkMDc0ZDk3YjhiYmM1ZGQ4NmY0Y2IwZDcifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTMyNjEwNzI5NzU4NjI0MDE2MTkiLCJlbWFpbCI6ImV0ZWFtaGN4QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDkxNTU1NDAxLCJleHAiOjE0OTE1NTkwMDF9.V5lYRSzbE0j_vdJwdeaOEjL4H0QAWYsTKa1HkGOz2BOQF2rdMg1APjMN1xySSJvh7vWJRF-hIS62w-J-pB0avqUqjULaewpf3-IA8BCyOaBM2l4NYN3fPTU_SQWVNCjq3n83wNmaiIlm2weuD0yRJFXBj0X4u_JNZ-deVNeGMu-XW9l9EVD7WviazcuzqQo94weNKn8Zw-bvbeibMJYU2rKfbmr6nu2TXtuy6O4jGaw0JSiazGH7rbUL8kcds6kTuKtUscwKmlHGxqDcC-dz7EcqodC-ksKKkiNMojWuoGQaliNraXFLnO6v1AgW5ghGiwpsUHy2zHv0_9Qchi_Cfg");
		u.handle(ur, null);
		
		
		/*UserAction u = new DisableCategoriesAction();
		UserRequest ur = new UserRequest();
		ur.setIdtoken("eyJhbGciOiJSUzI1NiIsImtpZCI6IjAyNDhiOTE4MDQ0ZjU0NDVkMDc0ZDk3YjhiYmM1ZGQ4NmY0Y2IwZDcifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTMyNjEwNzI5NzU4NjI0MDE2MTkiLCJlbWFpbCI6ImV0ZWFtaGN4QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDkxNTU1NDAxLCJleHAiOjE0OTE1NTkwMDF9.V5lYRSzbE0j_vdJwdeaOEjL4H0QAWYsTKa1HkGOz2BOQF2rdMg1APjMN1xySSJvh7vWJRF-hIS62w-J-pB0avqUqjULaewpf3-IA8BCyOaBM2l4NYN3fPTU_SQWVNCjq3n83wNmaiIlm2weuD0yRJFXBj0X4u_JNZ-deVNeGMu-XW9l9EVD7WviazcuzqQo94weNKn8Zw-bvbeibMJYU2rKfbmr6nu2TXtuy6O4jGaw0JSiazGH7rbUL8kcds6kTuKtUscwKmlHGxqDcC-dz7EcqodC-ksKKkiNMojWuoGQaliNraXFLnO6v1AgW5ghGiwpsUHy2zHv0_9Qchi_Cfg");
		EventCategories e = new EventCategories();
		List<String> s = new ArrayList<String>();
		s.add("Apartment Complex");
		//s.add("Lawyer");
		e.setDisabledCategories(s);
		ur.setEventCategories(e);
		u.handle(ur, null);*/
	}
}
