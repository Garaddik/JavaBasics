package test.com.hubcitix.news;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.google.gson.Gson;
import com.hubcitix.business.eventaction.CreateEvent;
import com.hubcitix.business.eventaction.EventAction;
import com.hubcitix.business.eventaction.GetBusinessCategories;
import com.hubcitix.business.eventaction.GetEventInfo;
import com.hubcitix.business.eventaction.SearchBusinessAction;
import com.hubcitix.business.model.Address;
import com.hubcitix.business.model.BusinessAccount;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.business.model.BusinessResponse;
import com.hubcitix.business.model.Photos;
import com.hubcitix.business.model.PublicEvent;
import com.hubcitix.common.Utility;

public class EventTest {
	public static void main(String a[])
	{
		
	/*	HashMap<String,String> h = new HashMap<String,String>();
		h.put("sdf", "sdfsd");
		h.put("773", "dfd");
		Gson g = new Gson();
		String s = g.toJson(h);
		System.out.println(s);*/
		
		//for creating event..
/*	EventAction eventAction  = new CreateEvent();	
		PublicEvent pb = new PublicEvent();
		ArrayList<String> ar = new ArrayList<String>();
		ar.add("Sports Store");
		ar.add("Lawyer");
		pb.setCategories(ar);
		pb.setIdtoken("eyJhbGciOiJSUzI1NiIsImtpZCI6IjAyNDhiOTE4MDQ0ZjU0NDVkMDc0ZDk3YjhiYmM1ZGQ4NmY0Y2IwZDcifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTMyNjEwNzI5NzU4NjI0MDE2MTkiLCJlbWFpbCI6ImV0ZWFtaGN4QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDkxNTU1NDAxLCJleHAiOjE0OTE1NTkwMDF9.V5lYRSzbE0j_vdJwdeaOEjL4H0QAWYsTKa1HkGOz2BOQF2rdMg1APjMN1xySSJvh7vWJRF-hIS62w-J-pB0avqUqjULaewpf3-IA8BCyOaBM2l4NYN3fPTU_SQWVNCjq3n83wNmaiIlm2weuD0yRJFXBj0X4u_JNZ-deVNeGMu-XW9l9EVD7WviazcuzqQo94weNKn8Zw-bvbeibMJYU2rKfbmr6nu2TXtuy6O4jGaw0JSiazGH7rbUL8kcds6kTuKtUscwKmlHGxqDcC-dz7EcqodC-ksKKkiNMojWuoGQaliNraXFLnO6v1AgW5ghGiwpsUHy2zHv0_9Qchi_Cfg");
		pb.setDescription("Arts event show at Austin");
		pb.setDtEnd("20170418T171000Z");
		pb.setDtStart("20170419T171000Z");
		pb.setSummary("Sports event show at Tyler");
		pb.setImageUrl("https://s3-us-west-2.amazonaws.com/hcxbusinessimages/profilephoto");
		
		Gson g = new Gson();
		String s = g.toJson(pb);
		System.out.println(s);*/
		//eventAction.handle(pb, null);
		
		
		/*List<BusinessAccount> businessAccountList = new ArrayList<BusinessAccount>();
		
		BusinessAccount businessAccount = new BusinessAccount();
		businessAccount.setAccountId("e2d1ce58-0ea2-4eb7-bb4f-7b3772213bcc");
		businessAccount.setAccountName("The Album Leaf");
		
		List<BusinessLocation> businessLocationList = new ArrayList<BusinessLocation>();
		BusinessLocation businessLocation = new BusinessLocation();
		businessLocation.setLocationId("ce479dc7-0e38-4108-aecf-cacb8699bc05");
		businessLocation.setLocationName("ALBUM Austin");
		businessLocation.setAccountId("e2d1ce58-0ea2-4eb7-bb4f-7b3772213bcc");
		Address address = new Address();
		address.setCity("Austin");
		address.setState("TX");
		address.setPostalCode("78758");
		List<String> addressLines = new ArrayList<String>();
		addressLines.add("9233 Waterford Centre Blvd Ste 200");
		address.setAddressLines(addressLines);
		businessLocation.setAddress(address);		
		Photos p = new Photos();
		p.setProfilePhotoUrl("whitebackground.png");
		businessLocation.setPhotos(p);
	
	
		BusinessLocation businessLocation2 = new BusinessLocation();
		businessLocation2.setLocationId("ce479dc7-0e38-4108-aecf-cacb8699bc05");
		businessLocation2.setLocationName("Waterford Centre Blvd");
		businessLocation2.setAccountId("e2d1ce58-0ea2-4eb7-bb4f-7b3772213bcc");
		Address address2 = new Address();
		address2.setCity("Austin");
		address2.setState("TX");
		address2.setPostalCode("78758");
		List<String> addressLines2 = new ArrayList<String>();
		addressLines2.add("9233 Waterford Centre Blvd Ste 200");
		address2.setAddressLines(addressLines2);
		businessLocation2.setAddress(address2);		
		Photos p1 = new Photos();
		p1.setProfilePhotoUrl("whitebackground.png");
		businessLocation2.setPhotos(p1);
		
		businessLocationList.add(businessLocation2);
		businessLocationList.add(businessLocation);
		businessAccount.setBusinessLocationList(businessLocationList);
		
		
		
		
		BusinessAccount businessAccount2 = new BusinessAccount();
		businessAccount2.setAccountId("97be113e-d405-4f7d-aae6-9fb959d2ca2c");
		businessAccount2.setAccountName("H-E-B Pharmacy");
		
		
		List<BusinessLocation> businessLocationList2 = new ArrayList<BusinessLocation>();
		BusinessLocation businessLocation3 = new BusinessLocation();
		businessLocation3.setLocationId("ce479dc7-0e38-4108-aecf-cacb8699bc05");
		businessLocation3.setLocationName("24th Cross, 4th main");
		businessLocation3.setAccountId("97be113e-d405-4f7d-aae6-9fb959d2ca2c");
		Address address3 = new Address();
		address3.setCity("Austin");
		address3.setState("TX");
		address3.setPostalCode("78758");
		List<String> addressLines3 = new ArrayList<String>();
		addressLines3.add("9233 Waterford Centre Blvd Ste 200");
		address3.setAddressLines(addressLines3);
	//	address3.setAddressLines(addressLines3);
		businessLocation3.setAddress(address3);		
		Photos p3 = new Photos();
		p3.setProfilePhotoUrl("whitebackground.png");
		businessLocation.setPhotos(p3);
		
		
		BusinessLocation businessLocation4 = new BusinessLocation();
		businessLocation4.setLocationId("ce479dc7-0e38-4108-aecf-cacb8699bc05");
		businessLocation4.setLocationName("down town branch");
		businessLocation4.setAccountId("97be113e-d405-4f7d-aae6-9fb959d2ca2c");
		Address address4 = new Address();
		address4.setCity("Austin");
		address4.setState("TX");
		address4.setPostalCode("78758");
		List<String> addressLines5 = new ArrayList<String>();
		addressLines5.add("9233 Waterford Centre Blvd Ste 200");
		address4.setAddressLines(addressLines5);
		businessLocation4.setAddress(address4);		
		Photos p4 = new Photos();
		p4.setProfilePhotoUrl("whitebackground.png");
		businessLocation4.setPhotos(p4);
		
		businessLocationList2.add(businessLocation3);
		businessLocationList2.add(businessLocation4);
		businessAccount2.setBusinessLocationList(businessLocationList2);
		businessAccountList.add(businessAccount);
		businessAccountList.add(businessAccount2);
		
		BusinessResponse res = new BusinessResponse();
		
		res.setStatusCode(200);
		res.setBusinessAccountList(businessAccountList);
		Gson g2 = new Gson();
		String s2 = g2.toJson(res);
		System.out.println(s2);*/
		//for listing events..
		
		/*EventAction eventAction  = new GetAllEvents();
		PublicEvent pb = new PublicEvent();
		pb.setAccountId("primary");
		pb.setIdtoken("eyJhbGciOiJSUzI1NiIsImtpZCI6IjAyNDhiOTE4MDQ0ZjU0NDVkMDc0ZDk3YjhiYmM1ZGQ4NmY0Y2IwZDcifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTMyNjEwNzI5NzU4NjI0MDE2MTkiLCJlbWFpbCI6ImV0ZWFtaGN4QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDkxNTU1NDAxLCJleHAiOjE0OTE1NTkwMDF9.V5lYRSzbE0j_vdJwdeaOEjL4H0QAWYsTKa1HkGOz2BOQF2rdMg1APjMN1xySSJvh7vWJRF-hIS62w-J-pB0avqUqjULaewpf3-IA8BCyOaBM2l4NYN3fPTU_SQWVNCjq3n83wNmaiIlm2weuD0yRJFXBj0X4u_JNZ-deVNeGMu-XW9l9EVD7WviazcuzqQo94weNKn8Zw-bvbeibMJYU2rKfbmr6nu2TXtuy6O4jGaw0JSiazGH7rbUL8kcds6kTuKtUscwKmlHGxqDcC-dz7EcqodC-ksKKkiNMojWuoGQaliNraXFLnO6v1AgW5ghGiwpsUHy2zHv0_9Qchi_Cfg");
		eventAction.handle(pb, null);*/
		
		//for event details
		/*EventAction eventAction  = new GetEventInfo();
		PublicEvent pb = new PublicEvent();
		pb.setAccountId("primary");
		pb.setEventId("127fb60b-73c7-44ed-8725-0c765bc106af");
		//pb.setIdtoken("eyJhbGciOiJSUzI1NiIsImtpZCI6IjAyNDhiOTE4MDQ0ZjU0NDVkMDc0ZDk3YjhiYmM1ZGQ4NmY0Y2IwZDcifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTMyNjEwNzI5NzU4NjI0MDE2MTkiLCJlbWFpbCI6ImV0ZWFtaGN4QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDkxNTU1NDAxLCJleHAiOjE0OTE1NTkwMDF9.V5lYRSzbE0j_vdJwdeaOEjL4H0QAWYsTKa1HkGOz2BOQF2rdMg1APjMN1xySSJvh7vWJRF-hIS62w-J-pB0avqUqjULaewpf3-IA8BCyOaBM2l4NYN3fPTU_SQWVNCjq3n83wNmaiIlm2weuD0yRJFXBj0X4u_JNZ-deVNeGMu-XW9l9EVD7WviazcuzqQo94weNKn8Zw-bvbeibMJYU2rKfbmr6nu2TXtuy6O4jGaw0JSiazGH7rbUL8kcds6kTuKtUscwKmlHGxqDcC-dz7EcqodC-ksKKkiNMojWuoGQaliNraXFLnO6v1AgW5ghGiwpsUHy2zHv0_9Qchi_Cfg");
		eventAction.handle(pb, null);*/
		
		//for business category
		EventAction eventAction  = new GetBusinessCategories();
		PublicEvent pb = new PublicEvent();
		BusinessLocation l = new BusinessLocation();
		Utility.STAGE="Dev_";
		//l.setLocationId(locationId);
		//pb.setAccountId("primary");
		//pb.setEventId("127fb60b-73c7-44ed-8725-0c765bc106af");
		//pb.setIdtoken("eyJhbGciOiJSUzI1NiIsImtpZCI6IjAyNDhiOTE4MDQ0ZjU0NDVkMDc0ZDk3YjhiYmM1ZGQ4NmY0Y2IwZDcifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTMyNjEwNzI5NzU4NjI0MDE2MTkiLCJlbWFpbCI6ImV0ZWFtaGN4QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDkxNTU1NDAxLCJleHAiOjE0OTE1NTkwMDF9.V5lYRSzbE0j_vdJwdeaOEjL4H0QAWYsTKa1HkGOz2BOQF2rdMg1APjMN1xySSJvh7vWJRF-hIS62w-J-pB0avqUqjULaewpf3-IA8BCyOaBM2l4NYN3fPTU_SQWVNCjq3n83wNmaiIlm2weuD0yRJFXBj0X4u_JNZ-deVNeGMu-XW9l9EVD7WviazcuzqQo94weNKn8Zw-bvbeibMJYU2rKfbmr6nu2TXtuy6O4jGaw0JSiazGH7rbUL8kcds6kTuKtUscwKmlHGxqDcC-dz7EcqodC-ksKKkiNMojWuoGQaliNraXFLnO6v1AgW5ghGiwpsUHy2zHv0_9Qchi_Cfg");
		eventAction.handle(pb, null);
		
		/*EventAction eventAction  = new SearchBusinessAction();
		PublicEvent pb = new PublicEvent();
		pb.setSearchKey("austin");
		Utility.STAGE="QA_";
		
		//pb.setAccountId("primary");
		//pb.setEventId("127fb60b-73c7-44ed-8725-0c765bc106af");
		//pb.setIdtoken("eyJhbGciOiJSUzI1NiIsImtpZCI6IjAyNDhiOTE4MDQ0ZjU0NDVkMDc0ZDk3YjhiYmM1ZGQ4NmY0Y2IwZDcifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTMyNjEwNzI5NzU4NjI0MDE2MTkiLCJlbWFpbCI6ImV0ZWFtaGN4QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDkxNTU1NDAxLCJleHAiOjE0OTE1NTkwMDF9.V5lYRSzbE0j_vdJwdeaOEjL4H0QAWYsTKa1HkGOz2BOQF2rdMg1APjMN1xySSJvh7vWJRF-hIS62w-J-pB0avqUqjULaewpf3-IA8BCyOaBM2l4NYN3fPTU_SQWVNCjq3n83wNmaiIlm2weuD0yRJFXBj0X4u_JNZ-deVNeGMu-XW9l9EVD7WviazcuzqQo94weNKn8Zw-bvbeibMJYU2rKfbmr6nu2TXtuy6O4jGaw0JSiazGH7rbUL8kcds6kTuKtUscwKmlHGxqDcC-dz7EcqodC-ksKKkiNMojWuoGQaliNraXFLnO6v1AgW5ghGiwpsUHy2zHv0_9Qchi_Cfg");
		eventAction.handle(pb, null);*/
	}
}
