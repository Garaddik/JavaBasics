package test.com.hubcitix.lambda;

import com.google.gson.Gson;
import com.hubcitix.calendar.handler.CalendarHandler;
import com.hubcitix.calendar.model.AuthconfigRequest;
import com.hubcitix.calendar.model.CalendarRequest;
import com.hubcitix.calendar.model.CalendarResponse;

public class CalendarTest {

	public static void main(String[] args) {
		// importCalendar();
		getActivities();
	}

	private static void getActivities() {
		CalendarHandler handler = new CalendarHandler();
		CalendarRequest input = new CalendarRequest();
		input.setAction("getallevents");
		input.setIdtoken("eyJhbGciOiJSUzI1NiIsImtpZCI6IjdhOWY5Yzc5ZGYzMDU5MzhlMjY4ODk3Y2JkNDc1ZDQ3MjY4MWI0ZWEifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTgyMDU0NTIyMzY4MDY0MDQ1MTUiLCJlbWFpbCI6Im1hbGxpa2FiaGF0MTAwQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDk1MDg3NTUxLCJleHAiOjE0OTUwOTExNTEsIm5hbWUiOiJNYWxsaWthIEJoYXQiLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDQuZ29vZ2xldXNlcmNvbnRlbnQuY29tLy1oUkwxVnl2TkJaRS9BQUFBQUFBQUFBSS9BQUFBQUFBQUUtRS9nZEpYaUJaeXZPay9zOTYtYy9waG90by5qcGciLCJnaXZlbl9uYW1lIjoiTWFsbGlrYSIsImZhbWlseV9uYW1lIjoiQmhhdCJ9.qdfcYV66cj1rEmNjKIaWAKIJuWMpEsdAJA463TAlZ-bX9qik3oH-2bAJelpSCIun4mjRFTO5czfW1sAu5AVQWUC0RG5EiLeXg-FeUrR73-acwNVquXVSqCOXv_Cv8icKYo2WRhCAu2wRJ9ug73Du1-D26he7cQoeJXIxj3hWYyBOZBbPwXhhehHZZFzkjF_8MrIqMuKItbU7GU0JYIDfVL4idM62noTSamMc8jt5oSUhbMX1669E1Mx-_ioPPtYcD_cXWp_Vw74oeH-rTSwFJfCYAmRH1vIdchLtlg2_IIg2sBdgKivmjvYqCXSHz_tz9TiUED9jM7IIBees3R9HQQ");
		input.setDtStart("2017-05-10T00:00:00.000Z");
		input.setDtEnd("2017-05-10T23:59:00.000Z");
		CalendarResponse response = handler.handleRequest(input, null);

		Gson gson = new Gson();
		
		System.out.println(gson.toJson(response));
	}

	private static void importCalendar() {
		CalendarHandler handler = new CalendarHandler();
		CalendarRequest input = new CalendarRequest();
		AuthconfigRequest authConfig = new AuthconfigRequest();
		authConfig.setAuthCode("4/bo_x69GwtKzBms56-5NZOK8qUOuQ0hg08lYsjQJXxbo");
		input.setAction("authconfig");
		input.setIdtoken("eyJhbGciOiJSUzI1NiIsImtpZCI6IjQzN2FhYTAxNGM3YWY3OTI4NjI0YWI1MmZmNjQ0ZDg5ZGVlYjJhYWYifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTgyMDU0NTIyMzY4MDY0MDQ1MTUiLCJlbWFpbCI6Im1hbGxpa2FiaGF0MTAwQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJpYXQiOjE0OTEzODM4NjUsImV4cCI6MTQ5MTM4NzQ2NSwibmFtZSI6Ik1hbGxpa2EgQmhhdCIsInBpY3R1cmUiOiJodHRwczovL2xoNC5nb29nbGV1c2VyY29udGVudC5jb20vLWhSTDFWeXZOQlpFL0FBQUFBQUFBQUFJL0FBQUFBQUFBRS1FL2dkSlhpQlp5dk9rL3M5Ni1jL3Bob3RvLmpwZyIsImdpdmVuX25hbWUiOiJNYWxsaWthIiwiZmFtaWx5X25hbWUiOiJCaGF0IiwibG9jYWxlIjoiZW4ifQ.PsH6WjbPpPJHLnhxuV-h1E972Hi7ceNbRBw2bn8fZFWGUPJf2QEjCGiTHUPGvJM0QTZuYsjioPZhfNrJITE3xK26coQUJScdXsyheuYUCiZL3RI2kBYb9c0imzYH2etuf_fqFwGgGkgUZ5I4AnpNaFluPtPi9umSY0tVLXExHTWsz1EvZ5Q1fOfW5I83Csd3TvkANgZtiEhtYpH14W9zYNzshB3_cME90aI3Ad4_sp3ZT4In2V0PNNWdV_KdmFhRAYdnxbFdyfJd5RHmYag3Rlu3UGpy2O6ra_4bJvG3GVXs8b2kk4gKIF3VHsSDSW3ml5GCISenjP3F9CE5SUtuTg");
		input.setAuthConfig(authConfig);
		CalendarResponse response = handler.handleRequest(input, null);
		System.out.println(response.getStatusCode());
	}
}
