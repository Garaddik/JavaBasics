package test.com.hubcitix.lambda;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.jdom2.Element;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.google.gson.Gson;
import com.hubcitix.common.DAOFactory;
import com.hubcitix.common.DBConnection;
import com.hubcitix.common.HelperFactory;
import com.hubcitix.common.helper.Helper;
import com.hubcitix.news.dao.NewsDao;
import com.hubcitix.news.handler.BatchProcessHandler;
import com.hubcitix.news.handler.NewsHandler;
import com.hubcitix.news.model.CategoryRequest;
import com.hubcitix.news.model.NewsCategory;
import com.hubcitix.news.model.NewsItem;
import com.hubcitix.news.model.NewsMedia;
import com.hubcitix.news.model.NewsRequest;
import com.hubcitix.news.model.NewsResponse;
import com.rometools.fetcher.FeedFetcher;
import com.rometools.fetcher.FetcherException;
import com.rometools.fetcher.impl.FeedFetcherCache;
import com.rometools.fetcher.impl.HashMapFeedInfoCache;
import com.rometools.fetcher.impl.HttpURLFeedFetcher;
import com.rometools.rome.feed.synd.SyndContent;
import com.rometools.rome.feed.synd.SyndEnclosure;
import com.rometools.rome.feed.synd.SyndEntry;
import com.rometools.rome.feed.synd.SyndFeed;
import com.rometools.rome.io.FeedException;

public class NewsTest {

	static NewsHandler handler = new NewsHandler();
	private static DynamoDBMapper dynamoDBMapper;

	public static void main(String[] args) {
//		setPreferences();
		 getCategories();
		// getItems();
		// saveArticle();
		// getUniqueId();
		// rssFeedReader();
//		batchProcess();

		// getArticle();
	}

	private static void getArticle() {

		List<NewsItem> newsItems = null;
		NewsDao dao = DAOFactory.getNewsDao();
		newsItems = dao.getNewsItems("tyler-health");

		newsItems.forEach(s -> s.getTitle());

	}

	private static void batchProcess() {
		BatchProcessHandler handler = new BatchProcessHandler();
		handler.handleRequest(null, null);
	}

	private static void rssFeedReader() {
		SyndFeed feed = null;

		try {

			FeedFetcherCache feedInfoCache = HashMapFeedInfoCache.getInstance();
			FeedFetcher feedFetcher = new HttpURLFeedFetcher(feedInfoCache);
			feed = feedFetcher.retrieveFeed(new URL("https://www.texastribune.org/feeds/top-stories/"));

			for (Object entryObject : feed.getEntries()) {
				List<NewsMedia> mediaList = new ArrayList<NewsMedia>();
				NewsItem item = new NewsItem();
				SyndEntry entry = (SyndEntry) entryObject;
				item.setTitle(entry.getTitle());
				item.setLink(entry.getLink());
				item.setAuthor(entry.getAuthor());
				// item.setPubDate(entry.getPublishedDate());
				item.setDescription(entry.getDescription().getValue());
				item.setGuid(entry.getLink());

				if (null != entry.getContents() && !entry.getContents().isEmpty()) {
					for (SyndContent content : entry.getContents()) {
						NewsMedia media = new NewsMedia();
						media.setType("text");
						media.setText(content.getValue());
						mediaList.add(media);
					}
				}
				for (SyndEnclosure closure : entry.getEnclosures()) {
					NewsMedia media = new NewsMedia();
					if (null != closure.getUrl()) {
						media.setType("image");
						media.setUrl(closure.getUrl());
						mediaList.add(media);
					}
				}

				if (null != entry.getForeignMarkup() && !entry.getForeignMarkup().isEmpty()) {
					boolean imageExist = true;
					for (Element element : entry.getForeignMarkup()) {
						NewsMedia media = new NewsMedia();
						switch (element.getName().toLowerCase()) {
						case "text":
							media.setType("text");
							media.setText(element.getValue());
							mediaList.add(media);
							break;
						case "thumbnail":
							if (imageExist) {
								item.setImageUrl(element.getAttributeValue("url"));
								imageExist = false;
							}
							media.setType("image");
							if (null != element.getAttributeValue("height"))
								media.setHeight(Integer.parseInt(element.getAttributeValue("height")));
							if (null != element.getAttributeValue("width"))
								media.setWidth(Integer.parseInt(element.getAttributeValue("width")));
							media.setUrl(element.getAttributeValue("url"));
							mediaList.add(media);
							break;
						case "content":
							if (null != element.getAttributeValue("url")) {
								if (imageExist) {
									item.setImageUrl(element.getAttributeValue("url"));
									imageExist = false;
								}
								media.setType("image");
								if (null != element.getAttributeValue("height"))
									media.setHeight(Integer.parseInt(element.getAttributeValue("height")));
								if (null != element.getAttributeValue("width"))
									media.setWidth(Integer.parseInt(element.getAttributeValue("width")));
								media.setUrl(element.getAttributeValue("url"));
								mediaList.add(media);
							}
							break;
						default:
							break;
						}
					}
					if (!mediaList.isEmpty())
						item.setMedia(mediaList);
				}

			}
		} catch (IllegalArgumentException e) {
			System.out.println("1");
		} catch (IOException e2) {
			System.out.println("2");
		} catch (FeedException e) {
			System.out.println("3");
		} catch (FetcherException e2) {
			System.out.println("4");
		}

	}

	private static void getUniqueId() {

		String token = "eyJhbGcssOiJSUzI1NiIsImtpZCI6IjZiZjVlYTM1MWJiMzJjNmZlNjE5ZWM5YTBmOGU4MDMyOWJjZGFkNTEifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTgyMDU0NTIyMzY4MDY0MDQ1MTUiLCJlbWFpbCI6Im1hbGxpa2FiaGF0MTAwQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDkwNjg2NjUzLCJleHAiOjE0OTA2OTAyNTMsIm5hbWUiOiJNYWxsaWthIEJoYXQiLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDQuZ29vZ2xldXNlcmNvbnRlbnQuY29tLy1oUkwxVnl2TkJaRS9BQUFBQUFBQUFBSS9BQUFBQUFBQUUtRS9nZEpYaUJaeXZPay9zOTYtYy9waG90by5qcGciLCJnaXZlbl9uYW1lIjoiTWFsbGlrYSIsImZhbWlseV9uYW1lIjoiQmhhdCJ9.HT_trSNwQ2ey3UaaBKQsiRB4hOnyu7nEtnTYrvKrEZZlHCMbqRnGaDHPdrR6r-6qh8E_W39_aoJYJ5aKcdSMrriBdI-wnds1fFmFZZue9ZK9KFhd_pbY0SYZoY0C5ISlm3wLZ8mh05Sm2qdZmlRwluoROdkzu34S40DFNea0rDji7xFWc3IYK5uoCpy8ekMI9lRehcjC8HcHX7pUCYFfxlfPBqETVeFyiyDF5EnTJCDvrL_TVkCg_NcFlXua8D0f2Tq-DYfw1GXvcRA_CaePgYLif8OFYBVhJLjoqnOoPa_M83v_ZnNELfhAijcUe5Lmgxitv57EgQZxMFeK2xitMQ";
		try {

			Helper helper = HelperFactory.getNewsHelper();
			String id = helper.getUserUniqueId(token);
			System.out.println(id);

		} catch (JWTDecodeException exception) {
			exception.printStackTrace();
		}
	}

	private static void saveArticle() {
		dynamoDBMapper = DBConnection.getDynamoConnection();
		NewsCategory category = new NewsCategory();
		category.setCategory("Ent");
		category.setLastBuildDate("2017-03-30T13:01:26.853Z");
		Gson gson = new Gson();

		dynamoDBMapper.save(category);

	}

	private static void getItems() {
		String action = "fetchitems";
		String idtoken = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjZiZjVlYTM1MWJiMzJjNmZlNjE5ZWM5YTBmOGU4MDMyOWJjZGFkNTEifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTgyMDU0NTIyMzY4MDY0MDQ1MTUiLCJlbWFpbCI6Im1hbGxpa2FiaGF0MTAwQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDkwNjg2NjUzLCJleHAiOjE0OTA2OTAyNTMsIm5hbWUiOiJNYWxsaWthIEJoYXQiLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDQuZ29vZ2xldXNlcmNvbnRlbnQuY29tLy1oUkwxVnl2TkJaRS9BQUFBQUFBQUFBSS9BQUFBQUFBQUUtRS9nZEpYaUJaeXZPay9zOTYtYy9waG90by5qcGciLCJnaXZlbl9uYW1lIjoiTWFsbGlrYSIsImZhbWlseV9uYW1lIjoiQmhhdCJ9.HT_trSNwQ2ey3UaaBKQsiRB4hOnyu7nEtnTYrvKrEZZlHCMbqRnGaDHPdrR6r-6qh8E_W39_aoJYJ5aKcdSMrriBdI-wnds1fFmFZZue9ZK9KFhd_pbY0SYZoY0C5ISlm3wLZ8mh05Sm2qdZmlRwluoROdkzu34S40DFNea0rDji7xFWc3IYK5uoCpy8ekMI9lRehcjC8HcHX7pUCYFfxlfPBqETVeFyiyDF5EnTJCDvrL_TVkCg_NcFlXua8D0f2Tq-DYfw1GXvcRA_CaePgYLif8OFYBVhJLjoqnOoPa_M83v_ZnNELfhAijcUe5Lmgxitv57EgQZxMFeK2xitMQ";
		String category = "tyler-sports";
		NewsRequest request = new NewsRequest();
		request.setAction(action);
		request.setIdtoken(idtoken);
		request.setCategory(category);

		NewsResponse response = handler.handleRequest(request, null);

		System.out.println("After Sort");
		for (NewsItem item : response.getNewsItems()) {
			System.out.println(item.getPubDate());
		}
	}

	private static void setPreferences() {
		String action = "setpreferences";
		String idtoken = "9964269233333333333";
		NewsRequest request = new NewsRequest();
		request.setAction(action);
		request.setIdtoken(idtoken);
		List<String> categories = new ArrayList<String>();
		categories.add("lifestyle");
		categories.add("sports");
		CategoryRequest catrequest = new CategoryRequest();
		catrequest.setDisabledCategories(categories);
		request.setCategoryRequest(catrequest);

		NewsResponse response = handler.handleRequest(request, null);
		if (null != response)
			System.out.println(response.getStatusCode());

	}

	private static void getCategories() {
		String action = "fetchcategories";
		String idtoken = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjZiZjVlYTM1MWJiMzJjNmZlNjE5ZWM5YTBmOGU4MDMyOWJjZGFkNTEifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTgyMDU0NTIyMzY4MDY0MDQ1MTUiLCJlbWFpbCI6Im1hbGxpa2FiaGF0MTAwQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDkwNjg2NjUzLCJleHAiOjE0OTA2OTAyNTMsIm5hbWUiOiJNYWxsaWthIEJoYXQiLCJwaWN0dXJlIjoiaHR0cHM6Ly9saDQuZ29vZ2xldXNlcmNvbnRlbnQuY29tLy1oUkwxVnl2TkJaRS9BQUFBQUFBQUFBSS9BQUFBQUFBQUUtRS9nZEpYaUJaeXZPay9zOTYtYy9waG90by5qcGciLCJnaXZlbl9uYW1lIjoiTWFsbGlrYSIsImZhbWlseV9uYW1lIjoiQmhhdCJ9.HT_trSNwQ2ey3UaaBKQsiRB4hOnyu7nEtnTYrvKrEZZlHCMbqRnGaDHPdrR6r-6qh8E_W39_aoJYJ5aKcdSMrriBdI-wnds1fFmFZZue9ZK9KFhd_pbY0SYZoY0C5ISlm3wLZ8mh05Sm2qdZmlRwluoROdkzu34S40DFNea0rDji7xFWc3IYK5uoCpy8ekMI9lRehcjC8HcHX7pUCYFfxlfPBqETVeFyiyDF5EnTJCDvrL_TVkCg_NcFlXua8D0f2Tq-DYfw1GXvcRA_CaePgYLif8OFYBVhJLjoqnOoPa_M83v_ZnNELfhAijcUe5Lmgxitv57EgQZxMFeK2xitMQ";
		NewsRequest request = new NewsRequest();
		request.setAction(action);
		request.setIdtoken(idtoken);

		NewsResponse response = handler.handleRequest(request, null);
		Gson gson = new Gson();
		if (null != response) {
			String json = gson.toJson(response.getNewsCategories());
			System.out.println(json);
		}

	}
}
