
package test.com.hubcitix.lambda;

import java.util.ArrayList;

//import com.hubcitix.business.action.FetchAllBusiness;

//import java.util.ArrayList;


import com.hubcitix.business.action.FetchAllBusiness;
//import com.hubcitix.business.action.FetchBusinessInfo;
import com.hubcitix.business.handler.MyBusinessHandler;
import com.hubcitix.business.model.Address;
//import com.hubcitix.business.action.FetchAllBusiness;
//import com.hubcitix.business.handler.MyBusinessHandler;
//import com.hubcitix.business.model.Address;
//import com.hubcitix.business.action.FetchBusinessInfo;
import com.hubcitix.business.model.BusinessLocation;
import com.hubcitix.business.model.BusinessRequest;
//import com.hubcitix.business.model.BusinessRequest;
import com.hubcitix.business.model.BusinessResponse;
//import com.hubcitix.business.model.SocialMedia;
//import com.hubcitix.business.model.SocialMedia;
import com.hubcitix.business.model.SocialMedia;

public class BusinessTest {

	public static void main(String args[]) {

	temp();

		// saveBusines();

	}

	 private static void saveBusines() {
	 MyBusinessHandler handler = new MyBusinessHandler();
	 BusinessRequest input = new BusinessRequest();
	 input.setAction("createbusiness");
	 input.setAccountId("primary");
	 input.setIdtoken("eyJhbGciOiJSUzI1NiIsImtpZCI6IjczZDNjYTZmNGE2ZTUzYWEzZWIxMWUyNzhlYzIwM2RlZWIyMDAzMDMifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTMyNjEwNzI5NzU4NjI0MDE2MTkiLCJlbWFpbCI6ImV0ZWFtaGN4QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDkyNjcxMTEwLCJleHAiOjE0OTI2NzQ3MTB9.UC7VJzZTiUHPYEBJhwHP_TrYCQeC51Evbw61Tj-1_h4LhKhC7PWKodeyUdK0kmpF4UyxPGfgPM8R4rg0rlf_kr-cnKeSQJGTT1KxLBPBPT06ilIMo6xSung7lT8xM-iJZoRqYKeISH4Lr-9yMRY6LYoNbm3WITRTXtWTOt7Udz0uSh6u0b6cgEfzJes5VQOit-iwAxi9GjJnGGZPF6OU4cHHEvVMznsNFiSRBmUimS0igNJejlZo9HitbeRzEhKpZsjSR_CrKik_PRl_n-2hzT28ZtJOhoFL84Az7YuoOm3twrl61e2bCqhyXNHQeyztdtOgngyQbv0EQE3FcfNMHA");
	
	 BusinessLocation location = new BusinessLocation();
	
	 location.setEmail("eteamhcx@gmail.com");
	 location.setLocationName("Bandprimaryaccount");
	 location.setWebsiteUrl("www.testp.com");
	
	
	 Address address = new Address();
	 address.setCity("Austinp");
	 address.setState("TX");
	 address.setPostalCode("78701");
	 location.setAddress(address);
	
	 SocialMedia socialMedia1 = new SocialMedia();
	 socialMedia1.setNetwork("Twitter");
	 socialMedia1.setUrl("Twitter.png");
	
	 SocialMedia socialMedia2 = new SocialMedia();
	 socialMedia2.setNetwork("Spotify");
	 socialMedia2.setUrl("Spotify.png");
	
	 ArrayList<SocialMedia> socialarray = new ArrayList<SocialMedia>();
	 socialarray.add(socialMedia1);
	 socialarray.add(socialMedia2);
	 location.setSocialLinks(socialarray);
	
	 input.setBusinessLocation(location);
	
	 BusinessResponse response = handler.handleRequest(input, null);
	 if(null != response){
	 if( response.getStatusCode() == 201){
	 System.out.println(response.getBusinessLocation().getAccount());
	 System.out.println(response.getBusinessLocation().getEmail());
	 System.out.println(response.getBusinessLocation().getLocationName());
	 System.out.println(response.getBusinessLocation().getWebsiteUrl());
	 System.out.println(response.getBusinessLocation().getAddress().getCity());
	 System.out.println(response.getBusinessLocation().getAddress().getState());
	 System.out.println(response.getBusinessLocation().getAddress().getPostalCode());
	 System.out.println(response.getBusinessLocation().getSocialLinks());
	 }
	 }
	
	 }

	private static void temp() {
		FetchAllBusiness handler = new FetchAllBusiness();
		BusinessLocation input = new BusinessLocation();

		input.setAccountId("primary");
		//input.setIdtoken("eyJhbGciOiJSUzI1NiIsImtpZCI6IjczZDNjYTZmNGE2ZTUzYWEzZWIxMWUyNzhlYzIwM2RlZWIyMDAzMDMifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdnFhczVuNXRrYnN1aHJoYmNzYXJiMmRycGJiMjEzNGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtbXI2aTRzanZudnQwb2M5MXEwMjkxbGFoa2dmbXZzYWUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTMyNjEwNzI5NzU4NjI0MDE2MTkiLCJlbWFpbCI6ImV0ZWFtaGN4QGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDkyNjcxMTEwLCJleHAiOjE0OTI2NzQ3MTB9.UC7VJzZTiUHPYEBJhwHP_TrYCQeC51Evbw61Tj-1_h4LhKhC7PWKodeyUdK0kmpF4UyxPGfgPM8R4rg0rlf_kr-cnKeSQJGTT1KxLBPBPT06ilIMo6xSung7lT8xM-iJZoRqYKeISH4Lr-9yMRY6LYoNbm3WITRTXtWTOt7Udz0uSh6u0b6cgEfzJes5VQOit-iwAxi9GjJnGGZPF6OU4cHHEvVMznsNFiSRBmUimS0igNJejlZo9HitbeRzEhKpZsjSR_CrKik_PRl_n-2hzT28ZtJOhoFL84Az7YuoOm3twrl61e2bCqhyXNHQeyztdtOgngyQbv0EQE3FcfNMHA");
		input.setIdtoken("eyJhbGciOiJSUzI1NiIsImtpZCI6IjIwZTAwOThhNTJjZGZiZDkxZGM3ZGM3YThkZDg1ZjdkYTUyNWZlZDUifQ.eyJhenAiOiI3MzMzNjQ3NTM2NDUtdm9ydW4wODFrY3V2NjltOWVwNWs5dXBwcTRzNGFxdW4uYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3MzMzNjQ3NTM2NDUtdm9ydW4wODFrY3V2NjltOWVwNWs5dXBwcTRzNGFxdW4uYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTYyNDExNjk5NzQwMzE1NzI0NzMiLCJlbWFpbCI6InNjYW4uaHViYXBwQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhdF9oYXNoIjoiUDcyZ0NLd0FvTmdCRm44Y2MwVWFkZyIsImlzcyI6Imh0dHBzOi8vYWNjb3VudHMuZ29vZ2xlLmNvbSIsImlhdCI6MTQ5MzgwNzk5MSwiZXhwIjoxNDkzODExNTkxLCJuYW1lIjoiSHViIEFwcCIsInBpY3R1cmUiOiJodHRwczovL2xoNS5nb29nbGV1c2VyY29udGVudC5jb20vLTJHVVV4QnVhaU8wL0FBQUFBQUFBQUFJL0FBQUFBQUFBQUFBL0FIYWxHaG84UWNDYmtMV2tQZnhPd2JkbGUwN2tmMTNCNUEvczk2LWMvcGhvdG8uanBnIiwiZ2l2ZW5fbmFtZSI6Ikh1YiIsImZhbWlseV9uYW1lIjoiQXBwIiwibG9jYWxlIjoiZW4ifQ.Qb-Y4d5ffm99NcbLJxU8LLq-GxA1Yms8PnVLVT27I2YVMiC4y6VbumWKXgM2uwQPzj6vvM3LTwuh9__mlSh6uPqL53PbDAadHOqNYE-tg2dQzEzyv2CRPJafNrJ0aA01o8KwG8V71psqJxuttROwjD0SQXA4WGJRuhbHtwuvBe0H9eGN7NPP9JPgqvOfDGJs194__qbsQr2RdYFEP82xvQfBZzcNeD5Q4Lq3zckjvHxlrAYYOPCYC1sLWVrTEk6E2wg0G7efSJdqsGjkpiK-w8Q_1QsJAiL6Rstw4E873gMLH-P7TAHJK1JhvfUdhXbvUi5mljf9ofLN8m8JZx8wfg");
		BusinessResponse response = handler.handle(input, null);
		response.getBusinessLocationList().forEach(s -> System.out.println(s.getLocationId()));
	response.getBusinessLocationList().forEach(s -> System.out.println(s.getLocationName()));
	}

}

// FetchBusinessInfo handler = new FetchBusinessInfo();
// BusinessLocation input = new BusinessLocation();
//
// input.setLocationId("6ad0f3b1-824c-4340-b3c1-8263e5cf17ae");
// input.setAccountId("4af0427a-7956-4341-b42c-a32b281537e7");
//
// BusinessResponse response = handler.handle(input, null);
// System.out.println(response.getBusinessLocation().getAccount());
// System.out.println(response.getBusinessLocation().getEmail());
// System.out.println(response.getBusinessLocation().getLocationName());
// System.out.println(response.getBusinessLocation().getLocationType());
// System.out.println(response.getBusinessLocation().getWebsiteUrl());
// System.out.println(response.getBusinessLocation().getAddress());
// System.out.println(response.getBusinessLocation().getCategories());
// System.out.println(response.getBusinessLocation().getSocialLinks());
// System.out.println(response.getBusinessLocation().getPhotos());
// }
// }