package test.com.hubcitix.lambda;

import com.hubcitix.media.handler.MediaHandler;
import com.hubcitix.media.model.NewsItemsResponse;
import com.hubcitix.media.model.NewsRequest;

public class MediaTest {

	public static void main(String[] args) {
		playListItems();
	}

	private static void playListItems() {
		MediaHandler handler = new MediaHandler();
		NewsRequest input = new NewsRequest();
		input.setAction("playlistitems");
		input.setMaxResults(new Long(50));
		input.setPlayListId("PLQqvr5WFHRfBONMqws8AzlFdUizWz7Mpl");

		NewsItemsResponse response = handler.handleRequest(input, null);
		if (null != response && response.getStatusCode() == 200 && null != response.getNewsItems()) {

			System.out.println("Size: " + response.getNewsItems().size());
			System.out.println(response.getNewsItems().get(0).getPubDate());
		} else {
			System.out.println("Empty");
		}
	}
}
